﻿# NX 1872
# Journal created by user on Fri Jun 14 14:43:48 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "F:\\本體12.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    theSession.SetUndoMarkName(markId4, "Create Sketch Dialog")
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = -0.64922636365304087
    rotMatrix1.Xy = 0.65837725643489342
    rotMatrix1.Xz = -0.3808471044226433
    rotMatrix1.Yx = -0.74032349393360053
    rotMatrix1.Yy = -0.43216417279977359
    rotMatrix1.Yz = 0.51493227911855899
    rotMatrix1.Zx = 0.17443122732984287
    rotMatrix1.Zy = 0.61625767010038113
    rotMatrix1.Zz = 0.76798452521821992
    translation1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.92331013267960604)
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    direction1 = workPart.Directions.CreateDirection(datumAxis1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane1 = workPart.Datums.FindObject("DATUM_CSYS(0) XY plane")
    datumCsys1 = workPart.Features.FindObject("DATUM_CSYS(0)")
    point1 = datumCsys1.FindObject("POINT 1")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction1, point1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.Csystem = cartesianCoordinateSystem1
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin2, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane2.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom1 = [NXOpen.NXObject.Null] * 1 
    geom1[0] = datumPlane1
    plane2.SetGeometry(geom1)
    
    plane2.SetFlip(False)
    
    plane2.SetExpression(None)
    
    plane2.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane2.Evaluate()
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane3.SynchronizeToPlane(plane2)
    
    plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = datumPlane1
    plane3.SetGeometry(geom2)
    
    plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane3.Evaluate()
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId5, None)
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject2 = sketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId7)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId6, None)
    
    theSession.SetUndoMarkName(markId4, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression4)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression3)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane3.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    expression5 = workPart.Expressions.CreateSystemExpression("70")
    
    expression6 = workPart.Expressions.CreateSystemExpression("500")
    
    expression7 = workPart.Expressions.CreateSystemExpression("90")
    
    workPart.Expressions.Edit(expression5, "70")
    
    workPart.Expressions.Edit(expression6, "50")
    
    workPart.Expressions.Edit(expression7, "90")
    
    theSession.SetUndoMarkVisibility(markId9, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using From Center method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(24.999999999999961, -35.000000000000057, 0.0)
    endPoint1 = NXOpen.Point3d(25.000000000000043, 34.999999999999943, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(25.000000000000043, 34.999999999999943, 0.0)
    endPoint2 = NXOpen.Point3d(-24.999999999999957, 35.000000000000057, 0.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(-24.999999999999957, 35.000000000000057, 0.0)
    endPoint3 = NXOpen.Point3d(-25.000000000000039, -34.999999999999943, 0.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(-25.000000000000039, -34.999999999999943, 0.0)
    endPoint4 = NXOpen.Point3d(24.999999999999961, -35.000000000000057, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_1.Geometry = line1
    geom1_1.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_1.SplineDefiningPointIndex = 0
    geom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_1.Geometry = line2
    geom2_1.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_1, geom2_1)
    
    geom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_2.Geometry = line2
    geom1_2.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_2.SplineDefiningPointIndex = 0
    geom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_2.Geometry = line3
    geom2_2.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_2, geom2_2)
    
    geom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_3.Geometry = line3
    geom1_3.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_3.SplineDefiningPointIndex = 0
    geom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_3.Geometry = line4
    geom2_3.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_3, geom2_3)
    
    geom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_4.Geometry = line4
    geom1_4.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_4.SplineDefiningPointIndex = 0
    geom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_4.Geometry = line1
    geom2_4.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_4, geom2_4)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys2 = workPart.Features.FindObject("SKETCH(1:1B)")
    point2 = datumCsys2.FindObject("POINT 1")
    conGeom1_5.Geometry = point2
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line1
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreateMidpointConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = point2
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line2
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateMidpointConstraint(conGeom1_6, conGeom2_6)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = line1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimObject2_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_1.Geometry = line1
    dimObject2_1.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_1.AssocValue = 0
    dimObject2_1.HelpPoint.X = 0.0
    dimObject2_1.HelpPoint.Y = 0.0
    dimObject2_1.HelpPoint.Z = 0.0
    dimObject2_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(34.747537345745833, -6.8221916190030137e-14, 0.0)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_1, dimObject2_1, dimOrigin1, expression5, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint1
    dimension1 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = line2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimObject2_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_2.Geometry = line2
    dimObject2_2.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_2.AssocValue = 0
    dimObject2_2.HelpPoint.X = 0.0
    dimObject2_2.HelpPoint.Y = 0.0
    dimObject2_2.HelpPoint.Z = 0.0
    dimObject2_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(6.4795898073829977e-14, 44.747537345745833, 0.0)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_2, dimObject2_2, dimOrigin2, expression6, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint2
    dimension2 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    datumAxis2 = workPart.Datums.FindObject("SKETCH(1:1B) X axis")
    dimObject1_3.Geometry = datumAxis2
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 28.574999999999999
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimObject2_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_3.Geometry = line1
    dimObject2_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_3.AssocValue = 0
    dimObject2_3.HelpPoint.X = 25.000000000000043
    dimObject2_3.HelpPoint.Y = 34.999999999999943
    dimObject2_3.HelpPoint.Z = 0.0
    dimObject2_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(22.0, -5.3341458234561807e-14, 0.0)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.AngularDim, dimObject1_3, dimObject2_3, dimOrigin3, expression7, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension3 = sketchDimensionalConstraint3.AssociatedDimension
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch2 = theSession.ActiveSketch
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId11, "Extrude Dialog")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features1 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature1 = feature1
    features1[0] = sketchFeature1
    curveFeatureRule1 = workPart.ScRuleFactory.CreateRuleCurveFeature(features1)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = curveFeatureRule1
    helpPoint1 = NXOpen.Point3d(17.743914672961008, 34.999999999999972, 7.1054273576010019e-15)
    section1.AddToSection(rules1, line2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId13, None)
    
    direction2 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction2
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId12, None)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.97337820646439499
    rotMatrix2.Xy = 0.19668243596820612
    rotMatrix2.Xz = -0.11768978953915202
    rotMatrix2.Yx = 0.042885881787825181
    rotMatrix2.Yy = 0.34811795920144961
    rotMatrix2.Yz = 0.93646926678065523
    rotMatrix2.Zx = 0.22515698595299671
    rotMatrix2.Zy = -0.91658600570979243
    rotMatrix2.Zz = 0.33041553506687793
    translation2 = NXOpen.Point3d(-9.5840880922610125, -14.014771677590179, 13.911655525780141)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 0.92331013267960604)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("40")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("40")
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId14, None)
    
    theSession.SetUndoMarkName(markId11, "Extrude")
    
    expression10 = extrudeBuilder1.Limits.StartExtend.Value
    expression11 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression8)
    
    workPart.Expressions.Delete(expression9)
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression12 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies2)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("40")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies3 = [NXOpen.Body.Null] * 1 
    targetBodies3[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies3)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId15, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder2.Destroy()
    
    section2.Destroy()
    
    workPart.Expressions.Delete(expression12)
    
    theSession.UndoToMark(markId15, None)
    
    theSession.DeleteUndoMark(markId15, None)
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = -0.29980399880819397
    rotMatrix3.Xy = -0.92144886433566475
    rotMatrix3.Xz = 0.24708207687554123
    rotMatrix3.Yx = -0.056705965564920295
    rotMatrix3.Yy = 0.27575006744292846
    rotMatrix3.Yz = 0.95955527916559857
    rotMatrix3.Zx = -0.95231402161680145
    rotMatrix3.Zy = 0.27366748202834645
    rotMatrix3.Zz = -0.13492262046187159
    translation3 = NXOpen.Point3d(-16.879525420554881, -14.476491925289046, 23.218418636355143)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 0.92331013267960604)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = -0.14333807905680604
    rotMatrix4.Xy = -0.98691171491170582
    rotMatrix4.Xz = 0.073888172682379752
    rotMatrix4.Yx = 0.39470797745585956
    rotMatrix4.Yy = 0.011456932769092367
    rotMatrix4.Yz = 0.91873519102308709
    rotMatrix4.Zx = -0.90755705474918136
    rotMatrix4.Zy = 0.16085398864050909
    rotMatrix4.Zz = 0.3878997121852889
    translation4 = NXOpen.Point3d(-13.415647336691647, -13.660090162438816, 12.761971983411932)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 0.92331013267960604)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin4, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId16, "Create Sketch Dialog")
    
    scalar1 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude1 = feature2
    edge1 = extrude1.FindObject("EDGE * 120 * 150 {(-25,35.0000000000001,0)(-25,0.0000000000001,0)(-25,-34.9999999999999,0) EXTRUDE(2)}")
    point3 = workPart.Points.CreatePoint(edge1, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction3 = workPart.Directions.CreateDirection(edge1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude1.FindObject("FACE 150 {(-25,0.0000000000001,20) EXTRUDE(2)}")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction3, point3, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem2
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane5 = workPart.Planes.CreatePlane(origin5, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane5.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom3 = [NXOpen.NXObject.Null] * 1 
    geom3[0] = face1
    plane5.SetGeometry(geom3)
    
    plane5.SetFlip(False)
    
    plane5.SetExpression(None)
    
    plane5.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane5.Evaluate()
    
    origin6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane6 = workPart.Planes.CreatePlane(origin6, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression16 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane6.SynchronizeToPlane(plane5)
    
    scalar2 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point4 = workPart.Points.CreatePoint(edge1, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane6.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom4 = [NXOpen.NXObject.Null] * 1 
    geom4[0] = face1
    plane6.SetGeometry(geom4)
    
    plane6.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane6.Evaluate()
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = -0.1629154362311403
    rotMatrix5.Xy = -0.98661727787404607
    rotMatrix5.Xz = -0.0067013161411611268
    rotMatrix5.Yx = 0.42082293889523065
    rotMatrix5.Yy = -0.075628556017665147
    rotMatrix5.Yz = 0.90398472089646675
    rotMatrix5.Zx = -0.89239375543377564
    rotMatrix5.Zy = 0.1444529975981447
    rotMatrix5.Zz = 0.42751224163491819
    translation5 = NXOpen.Point3d(-11.803857560220825, -13.365080759906409, 11.969721394419345)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 0.92331013267960604)
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId17, None)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject3 = sketchInPlaceBuilder2.Commit()
    
    sketch3 = nXObject3
    feature3 = sketch3.Feature
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId19)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId18, None)
    
    theSession.SetUndoMarkName(markId16, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point4)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression13)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression16)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression15)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane6.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Arc...
    # ----------------------------------------------
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scaleAboutPoint1 = NXOpen.Point3d(1.8626370553039742, 4.0118336575778084, 0.0)
    viewCenter1 = NXOpen.Point3d(-1.8626370553039742, -4.0118336575778084, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(1.4901096442431416, 3.2094669260622473, 0.0)
    viewCenter2 = NXOpen.Point3d(-1.4901096442432173, -3.2094669260622473, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(1.1920877153945133, 2.5675735408497977, 0.0)
    viewCenter3 = NXOpen.Point3d(-1.1920877153945737, -2.5675735408497977, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(0.95367017231561058, 2.0540588326798379, 0.0)
    viewCenter4 = NXOpen.Point3d(-0.95367017231565887, -2.0540588326798379, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(0.76293613785248837, 1.6432470661438605, 0.0)
    viewCenter5 = NXOpen.Point3d(-0.76293613785252701, -1.6432470661438701, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    theSession.SetUndoMarkVisibility(markId22, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(-24.999999999999954, 30.280387410842462, 33.032712971803925)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 31.071610036880546, ( 261.26325736163164 * math.pi/180.0 ), ( 372.95779258180778 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_5.Geometry = arc1
    geom1_5.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_5.SplineDefiningPointIndex = 0
    geom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    edge2 = extrude1.FindObject("EDGE * 130 * 150 {(-25,35.0000000000001,40)(-25,0.0000000000001,40)(-25,-34.9999999999999,40) EXTRUDE(2)}")
    geom2_5.Geometry = edge2
    geom2_5.PointType = NXOpen.Sketch.ConstraintPointType.MidVertex
    geom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_5, geom2_5)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = arc1
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    edge3 = extrude1.FindObject("EDGE * 140 * 150 {(-25,35.0000000000001,40)(-25,35.0000000000001,20)(-25,35.0000000000001,0) EXTRUDE(2)}")
    conGeom2_7.Geometry = edge3
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help1.Point.X = -24.999999999999954
    help1.Point.Y = 35.000000000000057
    help1.Point.Z = 2.3216366752583966
    help1.Parameter = 0.0
    sketchHelpedGeometricConstraint1 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_7, conGeom2_7, help1)
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = arc1
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(-24.999999999999954, 17.277586176686224, 24.464051198336339)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateRadialDimension(dimObject1_4, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension4 = sketchDimensionalConstraint4.AssociatedDimension
    
    expression17 = sketchDimensionalConstraint4.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Arc
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Radial...
    # ----------------------------------------------
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRadialDimensionBuilder1 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    sketchRadialDimensionBuilder1.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    lines1 = []
    sketchRadialDimensionBuilder1.AppendedText.SetBefore(lines1)
    
    lines2 = []
    sketchRadialDimensionBuilder1.AppendedText.SetAfter(lines2)
    
    lines3 = []
    sketchRadialDimensionBuilder1.AppendedText.SetAbove(lines3)
    
    lines4 = []
    sketchRadialDimensionBuilder1.AppendedText.SetBelow(lines4)
    
    theSession.SetUndoMarkName(markId23, "Radial Dimension Dialog")
    
    sketchRadialDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    dimensionlinearunits1 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits3 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits7 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRadialDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRadialDimensionBuilder1.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits11 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits19 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    point5 = NXOpen.Point3d(-24.999999999999954, 12.296695532932333, 7.7007575871330047)
    sketchRadialDimensionBuilder1.FirstAssociativity.SetValue(arc1, workPart.ModelingViews.WorkView, point5)
    
    point1_1 = NXOpen.Point3d(-24.999999999999954, 12.296695532932333, 7.7007575871330047)
    point2_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRadialDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_1, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_1)
    
    dimensionlinearunits21 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits25 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits27 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin1 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin1.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin1.View = NXOpen.View.Null
    assocOrigin1.ViewOfGeometry = workPart.ModelingViews.WorkView
    point6 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin1.PointOnGeometry = point6
    assocOrigin1.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.DimensionLine = 0
    assocOrigin1.AssociatedView = NXOpen.View.Null
    assocOrigin1.AssociatedPoint = NXOpen.Point.Null
    assocOrigin1.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.XOffsetFactor = 0.0
    assocOrigin1.YOffsetFactor = 0.0
    assocOrigin1.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRadialDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin1)
    
    point7 = NXOpen.Point3d(-24.999999999999954, 11.258702006894953, -14.955932477339957)
    sketchRadialDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point7)
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRadialDimensionBuilder1.Style.DimensionStyle.TextCentered = False
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    nXObject4 = sketchRadialDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId24, None)
    
    theSession.SetUndoMarkName(markId23, "Radial Dimension")
    
    theSession.SetUndoMarkVisibility(markId23, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRadialDimensionBuilder1.Destroy()
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRadialDimensionBuilder2 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    lines5 = []
    sketchRadialDimensionBuilder2.AppendedText.SetBefore(lines5)
    
    lines6 = []
    sketchRadialDimensionBuilder2.AppendedText.SetAfter(lines6)
    
    lines7 = []
    sketchRadialDimensionBuilder2.AppendedText.SetAbove(lines7)
    
    lines8 = []
    sketchRadialDimensionBuilder2.AppendedText.SetBelow(lines8)
    
    sketchRadialDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder2.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRadialDimensionBuilder2.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRadialDimensionBuilder2.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    parameters1 = [None] * 9 
    parameters1[0] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.PatternFeatureCount
    parameters1[1] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Diameter
    parameters1[2] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Depth
    parameters1[3] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.LineBreak
    parameters1[4] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.CounterBoreDiameter
    parameters1[5] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.CounterBoreDepth
    parameters1[6] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.CounterSinkDiameter
    parameters1[7] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.CounterSinkAngle
    parameters1[8] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.TaperAngle
    orderischanged1 = sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.ReorderParameters(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, parameters1)
    
    lines9 = [None] * 1 
    lines9[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 0, lines9)
    
    lines10 = [None] * 1 
    lines10[0] = " X"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 0, lines10)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 0, True)
    
    lines11 = [None] * 1 
    lines11[0] = "<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 1, lines11)
    
    lines12 = [None] * 1 
    lines12[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 1, lines12)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 1, True)
    
    lines13 = [None] * 1 
    lines13[0] = " - "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 2, lines13)
    
    lines14 = [None] * 1 
    lines14[0] = " DEEP"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 2, lines14)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 2, True)
    
    lines15 = [None] * 1 
    lines15[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 3, lines15)
    
    lines16 = [None] * 1 
    lines16[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 3, lines16)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 3, False)
    
    lines17 = [None] * 1 
    lines17[0] = "CBORE<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 4, lines17)
    
    lines18 = [None] * 1 
    lines18[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 4, lines18)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 4, True)
    
    lines19 = [None] * 1 
    lines19[0] = " - "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 5, lines19)
    
    lines20 = [None] * 1 
    lines20[0] = " DEEP"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 5, lines20)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 5, True)
    
    lines21 = [None] * 1 
    lines21[0] = "CSINK<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 6, lines21)
    
    lines22 = [None] * 1 
    lines22[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 6, lines22)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 6, True)
    
    lines23 = [None] * 1 
    lines23[0] = " X "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 7, lines23)
    
    lines24 = [None] * 1 
    lines24[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 7, lines24)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 7, True)
    
    lines25 = [None] * 1 
    lines25[0] = "TAPER "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 8, lines25)
    
    lines26 = [None] * 1 
    lines26[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 8, lines26)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, 8, True)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetThroughHoleTextOfType(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.GeneralHole, "THRU")
    
    parameters2 = [None] * 15 
    parameters2[0] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.PatternFeatureCount
    parameters2[1] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.ThreadSize
    parameters2[2] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.ThreadPitch
    parameters2[3] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.ThreadForm
    parameters2[4] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.ThreadInternalExternalSymbol
    parameters2[5] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.ThreadDepth
    parameters2[6] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Depth
    parameters2[7] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.LineBreak
    parameters2[8] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Pitch
    parameters2[9] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Angle
    parameters2[10] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.LineBreak
    parameters2[11] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.MinorDiameter
    parameters2[12] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.LineBreak
    parameters2[13] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.MajorDiameter
    parameters2[14] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.TapDrillDiameter
    orderischanged2 = sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.ReorderParameters(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, parameters2)
    
    lines27 = [None] * 1 
    lines27[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 0, lines27)
    
    lines28 = [None] * 1 
    lines28[0] = " X"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 0, lines28)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 0, True)
    
    lines29 = [None] * 1 
    lines29[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 1, lines29)
    
    lines30 = [None] * 1 
    lines30[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 1, lines30)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 1, True)
    
    lines31 = [None] * 1 
    lines31[0] = "x"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 2, lines31)
    
    lines32 = [None] * 1 
    lines32[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 2, lines32)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 2, True)
    
    lines33 = [None] * 1 
    lines33[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 3, lines33)
    
    lines34 = [None] * 1 
    lines34[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 3, lines34)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 3, True)
    
    lines35 = [None] * 1 
    lines35[0] = "-2"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 4, lines35)
    
    lines36 = [None] * 1 
    lines36[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 4, lines36)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 4, True)
    
    lines37 = [None] * 1 
    lines37[0] = " - "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 5, lines37)
    
    lines38 = [None] * 1 
    lines38[0] = " DEEP"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 5, lines38)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 5, False)
    
    lines39 = [None] * 1 
    lines39[0] = " - "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 6, lines39)
    
    lines40 = [None] * 1 
    lines40[0] = " DEEP"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 6, lines40)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 6, True)
    
    lines41 = [None] * 1 
    lines41[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 7, lines41)
    
    lines42 = [None] * 1 
    lines42[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 7, lines42)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 7, False)
    
    lines43 = [None] * 1 
    lines43[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 8, lines43)
    
    lines44 = [None] * 1 
    lines44[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 8, lines44)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 8, False)
    
    lines45 = [None] * 1 
    lines45[0] = " X "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 9, lines45)
    
    lines46 = [None] * 1 
    lines46[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 9, lines46)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 9, False)
    
    lines47 = [None] * 1 
    lines47[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 10, lines47)
    
    lines48 = [None] * 1 
    lines48[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 10, lines48)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 10, False)
    
    lines49 = [None] * 1 
    lines49[0] = "Minor:<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 11, lines49)
    
    lines50 = [None] * 1 
    lines50[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 11, lines50)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 11, False)
    
    lines51 = [None] * 1 
    lines51[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 12, lines51)
    
    lines52 = [None] * 1 
    lines52[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 12, lines52)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 12, False)
    
    lines53 = [None] * 1 
    lines53[0] = "Major:<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 13, lines53)
    
    lines54 = [None] * 1 
    lines54[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 13, lines54)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 13, False)
    
    lines55 = [None] * 1 
    lines55[0] = "Tap Drill:<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 14, lines55)
    
    lines56 = [None] * 1 
    lines56[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 14, lines56)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, 14, False)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetThroughHoleTextOfType(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ThreadedHole, "THRU")
    
    parameters3 = [None] * 3 
    parameters3[0] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.PatternFeatureCount
    parameters3[1] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Diameter
    parameters3[2] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Depth
    orderischanged3 = sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.ReorderParameters(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.DrillSizeHole, parameters3)
    
    lines57 = [None] * 1 
    lines57[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.DrillSizeHole, 0, lines57)
    
    lines58 = [None] * 1 
    lines58[0] = " X"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.DrillSizeHole, 0, lines58)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.DrillSizeHole, 0, True)
    
    lines59 = [None] * 1 
    lines59[0] = "<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.DrillSizeHole, 1, lines59)
    
    lines60 = [None] * 1 
    lines60[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.DrillSizeHole, 1, lines60)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.DrillSizeHole, 1, True)
    
    lines61 = [None] * 1 
    lines61[0] = " - "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.DrillSizeHole, 2, lines61)
    
    lines62 = [None] * 1 
    lines62[0] = " DEEP"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.DrillSizeHole, 2, lines62)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.DrillSizeHole, 2, True)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetThroughHoleTextOfType(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.DrillSizeHole, "THRU")
    
    parameters4 = [None] * 15 
    parameters4[0] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.PatternFeatureCount
    parameters4[1] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Callout
    parameters4[2] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.SymbolicThreadPitch
    parameters4[3] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.SymbolicThreadForm
    parameters4[4] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.SymbolicThreadInternalExternalSymbol
    parameters4[5] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Length
    parameters4[6] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.LineBreak
    parameters4[7] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Pitch
    parameters4[8] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Angle
    parameters4[9] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.LineBreak
    parameters4[10] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.MinorDiameter
    parameters4[11] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.LineBreak
    parameters4[12] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.MajorDiameter
    parameters4[13] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.TapDrillDiameter
    parameters4[14] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.ShaftSize
    orderischanged4 = sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.ReorderParameters(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, parameters4)
    
    lines63 = [None] * 1 
    lines63[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 0, lines63)
    
    lines64 = [None] * 1 
    lines64[0] = " X"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 0, lines64)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 0, True)
    
    lines65 = [None] * 1 
    lines65[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 1, lines65)
    
    lines66 = [None] * 1 
    lines66[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 1, lines66)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 1, True)
    
    lines67 = [None] * 1 
    lines67[0] = "x"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 2, lines67)
    
    lines68 = [None] * 1 
    lines68[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 2, lines68)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 2, True)
    
    lines69 = [None] * 1 
    lines69[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 3, lines69)
    
    lines70 = [None] * 1 
    lines70[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 3, lines70)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 3, True)
    
    lines71 = [None] * 1 
    lines71[0] = "-2"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 4, lines71)
    
    lines72 = [None] * 1 
    lines72[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 4, lines72)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 4, True)
    
    lines73 = [None] * 1 
    lines73[0] = " - "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 5, lines73)
    
    lines74 = [None] * 1 
    lines74[0] = " DEEP"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 5, lines74)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 5, True)
    
    lines75 = [None] * 1 
    lines75[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 6, lines75)
    
    lines76 = [None] * 1 
    lines76[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 6, lines76)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 6, False)
    
    lines77 = [None] * 1 
    lines77[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 7, lines77)
    
    lines78 = [None] * 1 
    lines78[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 7, lines78)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 7, False)
    
    lines79 = [None] * 1 
    lines79[0] = " X "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 8, lines79)
    
    lines80 = [None] * 1 
    lines80[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 8, lines80)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 8, False)
    
    lines81 = [None] * 1 
    lines81[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 9, lines81)
    
    lines82 = [None] * 1 
    lines82[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 9, lines82)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 9, False)
    
    lines83 = [None] * 1 
    lines83[0] = "Minor:<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 10, lines83)
    
    lines84 = [None] * 1 
    lines84[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 10, lines84)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 10, False)
    
    lines85 = [None] * 1 
    lines85[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 11, lines85)
    
    lines86 = [None] * 1 
    lines86[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 11, lines86)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 11, False)
    
    lines87 = [None] * 1 
    lines87[0] = "Major:<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 12, lines87)
    
    lines88 = [None] * 1 
    lines88[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 12, lines88)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 12, False)
    
    lines89 = [None] * 1 
    lines89[0] = "Tap Drill:<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 13, lines89)
    
    lines90 = [None] * 1 
    lines90[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 13, lines90)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 13, False)
    
    lines91 = [None] * 1 
    lines91[0] = "Shaft Size:<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 14, lines91)
    
    lines92 = [None] * 1 
    lines92[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 14, lines92)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, 14, False)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetThroughHoleTextOfType(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.SymbolicThread, "")
    
    parameters5 = [None] * 10 
    parameters5[0] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.PatternFeatureCount
    parameters5[1] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.ScrewSize
    parameters5[2] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Diameter
    parameters5[3] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Fit
    parameters5[4] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.Depth
    parameters5[5] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.LineBreak
    parameters5[6] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.CounterBoreDiameter
    parameters5[7] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.CounterBoreDepth
    parameters5[8] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.CounterSinkDiameter
    parameters5[9] = NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype.CounterSinkAngle
    orderischanged5 = sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.ReorderParameters(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, parameters5)
    
    lines93 = [None] * 1 
    lines93[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 0, lines93)
    
    lines94 = [None] * 1 
    lines94[0] = " X"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 0, lines94)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 0, True)
    
    lines95 = [None] * 1 
    lines95[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 1, lines95)
    
    lines96 = [None] * 1 
    lines96[0] = " - "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 1, lines96)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 1, True)
    
    lines97 = [None] * 1 
    lines97[0] = "<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 2, lines97)
    
    lines98 = [None] * 1 
    lines98[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 2, lines98)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 2, True)
    
    lines99 = [None] * 1 
    lines99[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 3, lines99)
    
    lines100 = [None] * 1 
    lines100[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 3, lines100)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 3, True)
    
    lines101 = [None] * 1 
    lines101[0] = " - "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 4, lines101)
    
    lines102 = [None] * 1 
    lines102[0] = " DEEP"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 4, lines102)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 4, True)
    
    lines103 = [None] * 1 
    lines103[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 5, lines103)
    
    lines104 = [None] * 1 
    lines104[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 5, lines104)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 5, False)
    
    lines105 = [None] * 1 
    lines105[0] = "CBORE<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 6, lines105)
    
    lines106 = [None] * 1 
    lines106[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 6, lines106)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 6, True)
    
    lines107 = [None] * 1 
    lines107[0] = " - "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 7, lines107)
    
    lines108 = [None] * 1 
    lines108[0] = " DEEP"
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 7, lines108)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 7, True)
    
    lines109 = [None] * 1 
    lines109[0] = "CSINK<o> "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 8, lines109)
    
    lines110 = [None] * 1 
    lines110[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 8, lines110)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 8, True)
    
    lines111 = [None] * 1 
    lines111[0] = " X "
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterPrefix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 9, lines111)
    
    lines112 = [None] * 1 
    lines112[0] = ""
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterSuffix(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 9, lines112)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetNthParameterDisplay(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, 9, True)
    
    sketchRadialDimensionBuilder2.Style.HoleCalloutSettings.SetThroughHoleTextOfType(NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype.ScrewClearanceHole, "THRU")
    
    sketchRadialDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId25, "Radial Dimension Dialog")
    
    sketchRadialDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRadialDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits29 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits31 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits33 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits37 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRadialDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRadialDimensionBuilder2.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits39 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits41 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits43 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits47 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder2.Destroy()
    
    theSession.UndoToMark(markId25, None)
    
    theSession.DeleteUndoMark(markId25, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder1 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    sketchRapidDimensionBuilder1.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    lines113 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines113)
    
    lines114 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines114)
    
    lines115 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines115)
    
    lines116 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines116)
    
    theSession.SetUndoMarkName(markId26, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits49 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits51 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits53 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits55 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits57 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits59 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits61 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits63 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits65 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits67 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint6 = NXOpen.Point3d(0.23474958087768638, -4.4132921205006772, 0.0)
    viewCenter6 = NXOpen.Point3d(-0.23474958087771733, 4.4132921205006621, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(0.18779966470213671, -3.5306336964005416, 0.0)
    viewCenter7 = NXOpen.Point3d(-0.18779966470218623, 3.5306336964005229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    datumCsys3 = workPart.Features.FindObject("SKETCH(3:1B)")
    point8 = datumCsys3.FindObject("POINT 1")
    point1_2 = NXOpen.Point3d(-24.999999999999954, 35.000000000000057, 0.0)
    point2_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Exist, point8, workPart.ModelingViews.WorkView, point1_2, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_2)
    
    point1_3 = NXOpen.Point3d(-24.999999999999954, 35.000000000000092, 2.3216366752583966)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, arc1, workPart.ModelingViews.WorkView, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(-24.999999999999954, 35.000000000000057, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, point8, workPart.ModelingViews.WorkView, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    point1_5 = NXOpen.Point3d(-24.999999999999954, 35.000000000000092, 2.3216366752583966)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, arc1, workPart.ModelingViews.WorkView, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    dimensionlinearunits69 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits73 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin2 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin2.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin2.View = NXOpen.View.Null
    assocOrigin2.ViewOfGeometry = workPart.ModelingViews.WorkView
    point9 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin2.PointOnGeometry = point9
    assocOrigin2.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.DimensionLine = 0
    assocOrigin2.AssociatedView = NXOpen.View.Null
    assocOrigin2.AssociatedPoint = NXOpen.Point.Null
    assocOrigin2.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.XOffsetFactor = 0.0
    assocOrigin2.YOffsetFactor = 0.0
    assocOrigin2.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin2)
    
    point10 = NXOpen.Point3d(-24.999999999999954, 42.88792153603211, 1.1084508412824665)
    sketchRapidDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point10)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.TextCentered = True
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject5 = sketchRapidDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId27, None)
    
    theSession.SetUndoMarkName(markId26, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId26, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder1.Destroy()
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder2 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines117 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines117)
    
    lines118 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines118)
    
    lines119 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines119)
    
    lines120 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines120)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId28, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits75 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits77 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits79 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits81 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits83 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits85 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits87 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits89 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits91 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits93 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Destroy()
    
    theSession.UndoToMark(markId28, None)
    
    theSession.DeleteUndoMark(markId28, None)
    
    scaleAboutPoint8 = NXOpen.Point3d(12.349705950813759, -12.139370326347381, 0.0)
    viewCenter8 = NXOpen.Point3d(-12.349705950813819, 12.139370326347356, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(15.437132438517198, -15.174212907934225, 0.0)
    viewCenter9 = NXOpen.Point3d(-15.43713243851726, 15.174212907934194, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint9, viewCenter9)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId30, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint5 = NXOpen.Point3d(-24.999999999999954, 0.0, 39.999999999999986)
    endPoint5 = NXOpen.Point3d(-24.999999999999954, 35.000000000000057, 40.000000000000021)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = line5
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_6.SplineDefiningPointIndex = 0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_6.Geometry = arc1
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_6, geom2_6)
    
    geom5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom5.Geometry = line5
    geom5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreateHorizontalConstraint(geom5)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = line5
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_7.SplineDefiningPointIndex = 0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_7.Geometry = edge2
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_7, geom2_7)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId31, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint6 = NXOpen.Point3d(-24.999999999999954, 35.000000000000057, 40.000000000000021)
    endPoint6 = NXOpen.Point3d(-24.999999999999954, 35.000000000000128, 2.3216366752583966)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = line6
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_8.SplineDefiningPointIndex = 0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = line5
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_8, geom2_8)
    
    geom6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom6.Geometry = line6
    geom6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreateVerticalConstraint(geom6)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = line6
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_9.SplineDefiningPointIndex = 0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_9.Geometry = arc1
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_9, geom2_9)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.26062486859118567
    rotMatrix6.Xy = -0.96544014722396299
    rotMatrix6.Xz = 0.0
    rotMatrix6.Yx = 0.0
    rotMatrix6.Yy = 0.0
    rotMatrix6.Yz = 1.0
    rotMatrix6.Zx = -0.96544014722396299
    rotMatrix6.Zy = -0.26062486859118567
    rotMatrix6.Zz = 0.0
    translation6 = NXOpen.Point3d(46.080651415903418, -7.9368466498528569, -16.25627658264608)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 2.8177189107653997)
    
    # ----------------------------------------------
    #   Menu: Fit
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.Fit()
    
    scaleAboutPoint10 = NXOpen.Point3d(-24.00431849104713, -4.5075173321489386, 0.0)
    viewCenter10 = NXOpen.Point3d(24.00431849104713, 4.5075173321489386, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(-20.634412676059597, 2.2895326131550204, 0.0)
    viewCenter11 = NXOpen.Point3d(20.634412676059586, -2.2895326131550204, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(-26.00765952755776, 3.64894260221581, 0.0)
    viewCenter12 = NXOpen.Point3d(26.00765952755776, -3.64894260221581, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(-32.599009277148568, 4.9189177235752339, 0.0)
    viewCenter13 = NXOpen.Point3d(32.599009277148568, -4.9189177235752339, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint13, viewCenter13)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder3 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines121 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines121)
    
    lines122 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines122)
    
    lines123 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines123)
    
    lines124 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines124)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines125 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines125)
    
    lines126 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines126)
    
    lines127 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines127)
    
    lines128 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines128)
    
    theSession.SetUndoMarkName(markId32, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder3.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits95 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits97 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits99 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits103 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits105 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits107 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits109 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits110 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits111 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits112 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits113 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits114 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    point11 = NXOpen.Point3d(-24.999999999999954, 27.481176927155957, 40.000000000000014)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(line5, workPart.ModelingViews.WorkView, point11)
    
    point1_6 = NXOpen.Point3d(-24.999999999999954, 35.000000000000057, 40.000000000000021)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line5, workPart.ModelingViews.WorkView, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    point1_7 = NXOpen.Point3d(-24.999999999999954, 0.0, 39.999999999999986)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line5, workPart.ModelingViews.WorkView, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    dimensionlinearunits115 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits116 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits117 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits118 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits119 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits120 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin3 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin3.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin3.View = NXOpen.View.Null
    assocOrigin3.ViewOfGeometry = workPart.ModelingViews.WorkView
    point12 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin3.PointOnGeometry = point12
    assocOrigin3.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.DimensionLine = 0
    assocOrigin3.AssociatedView = NXOpen.View.Null
    assocOrigin3.AssociatedPoint = NXOpen.Point.Null
    assocOrigin3.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.XOffsetFactor = 0.0
    assocOrigin3.YOffsetFactor = 0.0
    assocOrigin3.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder3.Origin.SetAssociativeOrigin(assocOrigin3)
    
    point13 = NXOpen.Point3d(-24.999999999999954, 24.70208592005843, 47.962146324246774)
    sketchRapidDimensionBuilder3.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point13)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.TextCentered = False
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject6 = sketchRapidDimensionBuilder3.Commit()
    
    theSession.DeleteUndoMark(markId33, None)
    
    theSession.SetUndoMarkName(markId32, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId32, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder3.Destroy()
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder4 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines129 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines129)
    
    lines130 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines130)
    
    lines131 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines131)
    
    lines132 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines132)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId34, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder4.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits121 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits122 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits123 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits124 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits125 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits126 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits127 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits128 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits129 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits130 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits131 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits132 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits133 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits134 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits135 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits136 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits137 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits138 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits139 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits140 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    point14 = NXOpen.Point3d(-24.999999999999957, 35.000000000000107, 16.771736213394753)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(line6, workPart.ModelingViews.WorkView, point14)
    
    point1_8 = NXOpen.Point3d(-24.999999999999954, 35.000000000000128, 2.3216366752583966)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line6, workPart.ModelingViews.WorkView, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    point1_9 = NXOpen.Point3d(-24.999999999999954, 35.000000000000057, 40.000000000000021)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, workPart.ModelingViews.WorkView, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    dimensionlinearunits141 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits142 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits143 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits144 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits145 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits146 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin4 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin4.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin4.View = NXOpen.View.Null
    assocOrigin4.ViewOfGeometry = workPart.ModelingViews.WorkView
    point15 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin4.PointOnGeometry = point15
    assocOrigin4.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.DimensionLine = 0
    assocOrigin4.AssociatedView = NXOpen.View.Null
    assocOrigin4.AssociatedPoint = NXOpen.Point.Null
    assocOrigin4.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.XOffsetFactor = 0.0
    assocOrigin4.YOffsetFactor = 0.0
    assocOrigin4.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder4.Origin.SetAssociativeOrigin(assocOrigin4)
    
    point16 = NXOpen.Point3d(-24.999999999999954, 41.376631962643621, 16.883529798021463)
    sketchRapidDimensionBuilder4.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point16)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.TextCentered = False
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject7 = sketchRapidDimensionBuilder4.Commit()
    
    theSession.DeleteUndoMark(markId35, None)
    
    theSession.SetUndoMarkName(markId34, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId34, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder4.Destroy()
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder5 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines133 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines133)
    
    lines134 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines134)
    
    lines135 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines135)
    
    lines136 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines136)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId36, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder5.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits147 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits148 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits149 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits150 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits151 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits152 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits153 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits154 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits155 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits156 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits157 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits158 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits159 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits160 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits161 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits162 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits163 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits164 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits165 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits166 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Destroy()
    
    theSession.UndoToMark(markId36, None)
    
    theSession.DeleteUndoMark(markId36, None)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = -0.29810993823259013
    rotMatrix7.Xy = -0.95450744917562891
    rotMatrix7.Xz = 0.0067819020337574615
    rotMatrix7.Yx = 0.087269466003122992
    rotMatrix7.Yy = -0.020179260038927928
    rotMatrix7.Yz = 0.99598034005085212
    rotMatrix7.Zx = -0.95053380004631649
    rotMatrix7.Zy = 0.29750349062240505
    rotMatrix7.Zz = 0.089314993349344368
    translation7 = NXOpen.Point3d(-11.090815601230883, -7.2355033728185747, -3.7023273659164317)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 2.3667130293460414)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch4 = theSession.ActiveSketch
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression18 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies4)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("40")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies5 = [NXOpen.Body.Null] * 1 
    targetBodies5[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies5)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId38, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features2 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature2 = feature3
    features2[0] = sketchFeature2
    curveFeatureRule2 = workPart.ScRuleFactory.CreateRuleCurveFeature(features2)
    
    section3.AllowSelfIntersection(True)
    
    rules2 = [None] * 1 
    rules2[0] = curveFeatureRule2
    helpPoint2 = NXOpen.Point3d(-24.999999999999954, 21.626867706598176, 3.2031303510451257)
    section3.AddToSection(rules2, arc1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId40, None)
    
    direction4 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction4
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies6[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies6)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies7)
    
    expression19 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId39, None)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies8)
    
    direction5 = extrudeBuilder3.Direction
    
    success1 = direction5.ReverseDirection()
    
    extrudeBuilder3.Direction = direction5
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("70")
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    feature4 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId41, None)
    
    theSession.SetUndoMarkName(markId38, "Extrude")
    
    expression20 = extrudeBuilder3.Limits.StartExtend.Value
    expression21 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression18)
    
    workPart.Expressions.Delete(expression19)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression22 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("70")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId42, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.051460762998784243
    rotMatrix8.Xy = -0.99637482000591115
    rotMatrix8.Xz = -0.067742216746805486
    rotMatrix8.Yx = 0.20501432301203498
    rotMatrix8.Yy = -0.055847543532009367
    rotMatrix8.Yz = 0.97716435630929455
    rotMatrix8.Zx = -0.97740519603258647
    rotMatrix8.Zy = -0.064173748056573027
    rotMatrix8.Zz = 0.20139715198798566
    translation8 = NXOpen.Point3d(-10.583039548107935, -14.828673468162965, 16.492023187358008)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 0.92331013267960604)
    
    extrudeBuilder4.Destroy()
    
    section4.Destroy()
    
    workPart.Expressions.Delete(expression22)
    
    theSession.UndoToMark(markId42, None)
    
    theSession.DeleteUndoMark(markId42, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scaleAboutPoint14 = NXOpen.Point3d(-14.47125712197705, -18.626370553039767, 0.0)
    viewCenter14 = NXOpen.Point3d(14.47125712197705, 18.626370553039767, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(-11.577005697581642, -14.901096442431815, 0.0)
    viewCenter15 = NXOpen.Point3d(11.577005697581642, 14.901096442431815, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(-9.2616045580653115, -11.920877153945449, 0.0)
    viewCenter16 = NXOpen.Point3d(9.2616045580653115, 11.920877153945449, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(-9.1699055030349506, -9.389983235107815, 0.0)
    viewCenter17 = NXOpen.Point3d(9.1699055030349736, 9.3899832351078025, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(-7.3359244024279588, -7.5119865880862511, 0.0)
    viewCenter18 = NXOpen.Point3d(7.3359244024279784, 7.5119865880862413, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(-5.1175408631337351, -6.7607879292776243, 0.0)
    viewCenter19 = NXOpen.Point3d(5.1175408631337662, 6.7607879292776092, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scalar3 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point17 = workPart.Points.CreatePoint(edge3, scalar3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction6 = workPart.Directions.CreateDirection(edge1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction6, point17, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder1 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder1.Csys = cartesianCoordinateSystem3
    
    datumCsysBuilder1.DisplayScaleFactor = 1.25
    
    feature5 = datumCsysBuilder1.CommitFeature()
    
    datumCsysBuilder1.Destroy()
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem3
    
    sketchInPlaceBuilder3.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject8 = sketchInPlaceBuilder3.Commit()
    
    sketchInPlaceBuilder3.Destroy()
    
    sketch5 = nXObject8
    sketch5.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "")
    
    nErrs3 = theSession.UpdateManager.AddToDeleteList(sketch5)
    
    datumCsys4 = feature5
    nErrs4 = theSession.UpdateManager.AddToDeleteList(datumCsys4)
    
    nErrs5 = theSession.UpdateManager.AddToDeleteList(point17)
    
    nErrs6 = theSession.UpdateManager.DoUpdate(markId46)
    
    theSession.DeleteUndoMark(markId46, "")
    
    theSession.UndoToMark(markId44, "Curve")
    
    theSession.DeleteUndoMark(markId44, "Curve")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin7, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane7
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId47, "Create Sketch Dialog")
    
    scalar4 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point18 = workPart.Points.CreatePoint(edge3, scalar4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction7 = workPart.Directions.CreateDirection(edge1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction7, point18, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.Csystem = cartesianCoordinateSystem4
    
    origin8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal8 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane8 = workPart.Planes.CreatePlane(origin8, normal8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane8.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom7 = [NXOpen.NXObject.Null] * 1 
    geom7[0] = face1
    plane8.SetGeometry(geom7)
    
    plane8.SetFlip(False)
    
    plane8.SetExpression(None)
    
    plane8.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane8.Evaluate()
    
    origin9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane9 = workPart.Planes.CreatePlane(origin9, normal9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression25 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression26 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane9.SynchronizeToPlane(plane8)
    
    scalar5 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point19 = workPart.Points.CreatePoint(edge3, scalar5, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane9.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom8 = [NXOpen.NXObject.Null] * 1 
    geom8[0] = face1
    plane9.SetGeometry(geom8)
    
    plane9.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane9.Evaluate()
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId48, None)
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject9 = sketchInPlaceBuilder4.Commit()
    
    sketch6 = nXObject9
    feature6 = sketch6.Feature
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs7 = theSession.UpdateManager.DoUpdate(markId50)
    
    sketch6.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId49, None)
    
    theSession.SetUndoMarkName(markId47, "Create Sketch")
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression24)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point19)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression23)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression26)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression25)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane9.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint20 = NXOpen.Point3d(4.2442724222687467, -5.0330310140177827, 0.0)
    viewCenter20 = NXOpen.Point3d(-4.2442724222687218, 5.0330310140177765, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(36.855684197798155, -10.32898155861859, 0.0)
    viewCenter21 = NXOpen.Point3d(-36.855684197798126, 10.328981558618576, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(34.667818104018032, -9.1646236374652279, 0.0)
    viewCenter22 = NXOpen.Point3d(-34.667818104018004, 9.1646236374652101, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(34.404898573435013, -7.3316989099721832, 0.0)
    viewCenter23 = NXOpen.Point3d(-34.404898573434984, 7.3316989099721637, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(43.006123216793767, -9.2397435033460837, 0.0)
    viewCenter24 = NXOpen.Point3d(-43.006123216793739, 9.2397435033460642, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(53.663754188641128, -11.737479043884747, 0.0)
    viewCenter25 = NXOpen.Point3d(-53.663754188641079, 11.73747904388474, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(68.840314592384132, -12.91122694827324, 0.0)
    viewCenter26 = NXOpen.Point3d(-68.840314592384075, 12.91122694827323, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    # ----------------------------------------------
    #   Menu: Snap View
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.SnapToClosestCannedOrientation()
    
    # ----------------------------------------------
    #   Menu: Fit
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.Fit()
    
    scaleAboutPoint27 = NXOpen.Point3d(11.250595238095251, -16.790476190476195, 0.0)
    viewCenter27 = NXOpen.Point3d(-11.250595238095251, 16.790476190476195, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(13.880208333333339, -20.744047619047617, 0.0)
    viewCenter28 = NXOpen.Point3d(-13.880208333333339, 20.744047619047617, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(17.426525297619069, -26.006324404761905, 0.0)
    viewCenter29 = NXOpen.Point3d(-17.426525297619069, 26.006324404761909, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint29, viewCenter29)
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    expression27 = workPart.Expressions.CreateSystemExpression("30")
    
    theSession.SetUndoMarkVisibility(markId52, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(-24.999999999999954, -2.1827008928571061, 0.0)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 15.0, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = arc2
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line3
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    help2 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help2.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help2.Point.X = -24.999999999999954
    help2.Point.Y = -2.1827008928571061
    help2.Point.Z = 0.0
    help2.Parameter = 0.0
    sketchHelpedGeometricConstraint2 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_8, conGeom2_8, help2)
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_5.Geometry = arc2
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = 0.0
    dimObject1_5.HelpPoint.Y = 0.0
    dimObject1_5.HelpPoint.Z = 0.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(-24.999999999999954, -2.1827008928571061, 1.0809195725534311)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_5, dimOrigin5, expression27, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension5 = sketchDimensionalConstraint5.AssociatedDimension
    
    theSession.ActiveSketch.Update()
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    expression28 = workPart.Expressions.CreateSystemExpression("3")
    
    workPart.Expressions.Delete(expression28)
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.DeleteUndoMark(markId55, "Curve")
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete1 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    theSession.SetUndoMarkName(markId57, "Class Selection Dialog")
    
    theSession.SetUndoMarkName(markId57, "Class Selection")
    
    theSession.DeleteUndoMark(markId57, None)
    
    theSession.DeleteUndoMark(markId56, None)
    
    scaleAboutPoint30 = NXOpen.Point3d(29.504975818452397, -27.455357142857142, 0.0)
    viewCenter30 = NXOpen.Point3d(-29.504975818452397, 27.455357142857142, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(36.881219773065503, -34.319196428571423, 0.0)
    viewCenter31 = NXOpen.Point3d(-36.881219773065503, 34.319196428571431, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint31, viewCenter31)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete2 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects1 = [NXOpen.TaggedObject.Null] * 1 
    objects1[0] = arc2
    nErrs8 = theSession.UpdateManager.AddObjectsToDeleteList(objects1)
    
    notifyOnDelete3 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs9 = theSession.UpdateManager.DoUpdate(id1)
    
    theSession.DeleteUndoMark(markId58, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint32 = NXOpen.Point3d(20.779200962611618, -55.411202566964278, 0.0)
    viewCenter32 = NXOpen.Point3d(-20.779200962611597, 55.411202566964306, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    expression29 = workPart.Expressions.CreateSystemExpression("4")
    
    theSession.SetUndoMarkVisibility(markId62, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(-24.999999999999954, -2.5997744605654489, 0.0)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 2.0, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = arc3
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line3
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    help3 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help3.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help3.Point.X = -24.999999999999954
    help3.Point.Y = -2.5997744605654489
    help3.Point.Z = 0.0
    help3.Parameter = 0.0
    sketchHelpedGeometricConstraint3 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_9, conGeom2_9, help3)
    
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = arc3
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = 0.0
    dimObject1_6.HelpPoint.Y = 0.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(-24.999999999999954, -2.5997744605654489, 1.3511494656917888)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_6, dimOrigin6, expression29, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension6 = sketchDimensionalConstraint6.AssociatedDimension
    
    theSession.ActiveSketch.Update()
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId63, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix4 = theSession.ActiveSketch.Orientation
    
    center4 = NXOpen.Point3d(-24.999999999999954, -25.002583240327361, 0.0)
    arc4 = workPart.Curves.CreateArc(center4, nXMatrix4, 2.0, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = arc4
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line3
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    help4 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help4.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help4.Point.X = -24.999999999999954
    help4.Point.Y = -25.002583240327361
    help4.Point.Z = 0.0
    help4.Parameter = 0.0
    sketchHelpedGeometricConstraint4 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_10, conGeom2_10, help4)
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = arc4
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 0.0
    dimObject1_7.HelpPoint.Y = 0.0
    dimObject1_7.HelpPoint.Z = 0.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(-24.999999999999954, -25.002583240327361, 1.3511494656917888)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_7, dimOrigin7, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension7 = sketchDimensionalConstraint7.AssociatedDimension
    
    expression30 = sketchDimensionalConstraint7.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.DeleteUndoMark(markId64, "Curve")
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = 0.93623487063973676
    rotMatrix9.Xy = -0.35137482408134318
    rotMatrix9.Xz = 0.0
    rotMatrix9.Yx = 0.0
    rotMatrix9.Yy = 0.0
    rotMatrix9.Yz = 1.0
    rotMatrix9.Zx = -0.35137482408134318
    rotMatrix9.Zy = -0.93623487063973676
    rotMatrix9.Zz = 0.0
    translation9 = NXOpen.Point3d(23.080040922619062, -40.246609933035721, 3.3261744314918104e-14)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 2.2203317073170727)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = 0.16205164544734374
    rotMatrix10.Xy = -0.98667067090811078
    rotMatrix10.Xz = 0.01484086849031397
    rotMatrix10.Yx = -0.15494990708430567
    rotMatrix10.Yy = -0.010590265618857486
    rotMatrix10.Yz = 0.98786556401601877
    rotMatrix10.Zx = -0.97454081007537752
    rotMatrix10.Zy = -0.16238483132318862
    rotMatrix10.Zz = -0.15460069874928162
    translation10 = NXOpen.Point3d(22.79806442130312, -40.016055649340089, 2.9374132762363576)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 2.2203317073170727)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = 0.074042108451835065
    rotMatrix11.Xy = -0.99725468891972591
    rotMatrix11.Xz = 0.00092282372504299626
    rotMatrix11.Yx = -0.15494990708430567
    rotMatrix11.Yy = -0.010590265618857486
    rotMatrix11.Yz = 0.98786556401601877
    rotMatrix11.Zx = -0.98514379278893649
    rotMatrix11.Zy = -0.073286640677157774
    rotMatrix11.Zz = -0.15530864698298488
    translation11 = NXOpen.Point3d(23.06250727184327, -40.016055649340089, 2.9508642926767168)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 2.2203317073170727)
    
    scaleAboutPoint33 = NXOpen.Point3d(23.177373976934529, -39.443243117559518, 0.0)
    viewCenter33 = NXOpen.Point3d(-23.177373976934529, 39.443243117559533, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(18.54189918154762, -31.554594494047613, 0.0)
    viewCenter34 = NXOpen.Point3d(-18.54189918154762, 31.554594494047628, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(14.833519345238107, -25.243675595238098, 0.0)
    viewCenter35 = NXOpen.Point3d(-14.833519345238107, 25.243675595238109, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(11.683779761904763, -18.913690476190471, 0.0)
    viewCenter36 = NXOpen.Point3d(-11.683779761904763, 18.913690476190485, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(9.3470238095238098, -14.838095238095232, 0.0)
    viewCenter37 = NXOpen.Point3d(-9.3470238095238098, 14.838095238095248, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint37, viewCenter37)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete4 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects2 = [NXOpen.TaggedObject.Null] * 1 
    objects2[0] = arc3
    nErrs10 = theSession.UpdateManager.AddObjectsToDeleteList(objects2)
    
    notifyOnDelete5 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id2 = theSession.NewestVisibleUndoMark
    
    nErrs11 = theSession.UpdateManager.DoUpdate(id2)
    
    theSession.DeleteUndoMark(markId65, None)
    
    scaleAboutPoint38 = NXOpen.Point3d(12.86619047619048, -7.4190476190476131, 0.0)
    viewCenter38 = NXOpen.Point3d(-12.866190476190484, 7.4190476190476291, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(16.082738095238099, -9.3714285714285612, 0.0)
    viewCenter39 = NXOpen.Point3d(-16.082738095238099, 9.3714285714285772, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint39, viewCenter39)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete6 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects3 = [NXOpen.TaggedObject.Null] * 1 
    objects3[0] = arc4
    nErrs12 = theSession.UpdateManager.AddObjectsToDeleteList(objects3)
    
    notifyOnDelete7 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id3 = theSession.NewestVisibleUndoMark
    
    nErrs13 = theSession.UpdateManager.DoUpdate(id3)
    
    theSession.DeleteUndoMark(markId67, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    expression31 = workPart.Expressions.CreateSystemExpression("3")
    
    theSession.SetUndoMarkVisibility(markId70, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix5 = theSession.ActiveSketch.Orientation
    
    center5 = NXOpen.Point3d(-24.999999999999954, -1.4999999999999432, 4.0)
    arc5 = workPart.Curves.CreateArc(center5, nXMatrix5, 1.5, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = arc5
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 0.0
    dimObject1_8.HelpPoint.Y = 0.0
    dimObject1_8.HelpPoint.Z = 0.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(-24.999999999999954, -1.4999999999999432, 4.6917885264341956)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_8, dimOrigin8, expression31, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension8 = sketchDimensionalConstraint8.AssociatedDimension
    
    theSession.ActiveSketch.Update()
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    # ----------------------------------------------
    #   Menu: Fit
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.Fit()
    
    theSession.SetUndoMarkVisibility(markId71, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix6 = theSession.ActiveSketch.Orientation
    
    center6 = NXOpen.Point3d(-24.999999999999954, -25.982495078283065, 4.0)
    arc6 = workPart.Curves.CreateArc(center6, nXMatrix6, 1.5, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_9.Geometry = arc6
    dimObject1_9.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_9.AssocValue = 0
    dimObject1_9.HelpPoint.X = 0.0
    dimObject1_9.HelpPoint.Y = 0.0
    dimObject1_9.HelpPoint.Z = 0.0
    dimObject1_9.View = NXOpen.NXObject.Null
    dimOrigin9 = NXOpen.Point3d(-24.999999999999954, -25.982495078283065, 4.6641645321153717)
    sketchDimensionalConstraint9 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_9, dimOrigin9, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsDriving)
    
    dimension9 = sketchDimensionalConstraint9.AssociatedDimension
    
    expression32 = sketchDimensionalConstraint9.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scaleAboutPoint40 = NXOpen.Point3d(8.8742067223373695, -9.3135238868095129, 0.0)
    viewCenter40 = NXOpen.Point3d(-8.8742067223373695, 9.3135238868095129, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(11.239197457745767, -11.715124385923914, 0.0)
    viewCenter41 = NXOpen.Point3d(-11.239197457745767, 11.715124385923914, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint41, viewCenter41)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = 0.19062833711429941
    rotMatrix12.Xy = -0.98110182434909698
    rotMatrix12.Xz = -0.033166961692483322
    rotMatrix12.Yx = 0.11498573260540959
    rotMatrix12.Yy = -0.01123769460609033
    rotMatrix12.Yz = 0.99330357671617064
    rotMatrix12.Zx = -0.97490467143523019
    rotMatrix12.Zy = -0.19316553646759518
    rotMatrix12.Zz = 0.11067048899752753
    translation12 = NXOpen.Point3d(5.6916902788704666, -25.123233602506769, -2.2134097799505468)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 2.8908499432885666)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId72, "Curve")
    
    sketch7 = theSession.ActiveSketch
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section5
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression33 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("70")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId74, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features3 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature3 = feature6
    features3[0] = sketchFeature3
    curveFeatureRule3 = workPart.ScRuleFactory.CreateRuleCurveFeature(features3)
    
    section5.AllowSelfIntersection(True)
    
    rules3 = [None] * 1 
    rules3[0] = curveFeatureRule3
    helpPoint3 = NXOpen.Point3d(-24.999999999999954, -2.6796050840846752, 3.0803837536657075)
    section5.AddToSection(rules3, arc5, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId76, None)
    
    direction8 = workPart.Directions.CreateDirection(sketch7, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder5.Direction = direction8
    
    expression34 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression35 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId75, None)
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = 0.91233694461862225
    rotMatrix13.Xy = -0.33812311393172123
    rotMatrix13.Xz = -0.2308983744184282
    rotMatrix13.Yx = 0.3235882037268859
    rotMatrix13.Yy = 0.2499233164611018
    rotMatrix13.Yz = 0.91259465826723496
    rotMatrix13.Zx = -0.25086246011064145
    rotMatrix13.Zy = -0.90730981242032205
    rotMatrix13.Zz = 0.33742692600478186
    translation13 = NXOpen.Point3d(32.467042483714344, 3.7502317850647273, 40.643089298100634)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 3.5221486384567506)
    
    direction9 = extrudeBuilder5.Direction
    
    success2 = direction9.ReverseDirection()
    
    extrudeBuilder5.Direction = direction9
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("47.5")
    
    # ----------------------------------------------
    #   Menu: Snap View
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.SnapToClosestCannedOrientation()
    
    # ----------------------------------------------
    #   Menu: Fit
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.Fit()
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("55.5")
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder5.ParentFeatureInternal = False
    
    feature7 = extrudeBuilder5.CommitFeature()
    
    theSession.DeleteUndoMark(markId77, None)
    
    theSession.SetUndoMarkName(markId74, "Extrude")
    
    expression36 = extrudeBuilder5.Limits.StartExtend.Value
    expression37 = extrudeBuilder5.Limits.EndExtend.Value
    extrudeBuilder5.Destroy()
    
    workPart.Expressions.Delete(expression33)
    
    workPart.Expressions.Delete(expression34)
    
    workPart.Expressions.Delete(expression35)
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section6
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression38 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("55.5")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId78, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder6.Destroy()
    
    section6.Destroy()
    
    workPart.Expressions.Delete(expression38)
    
    theSession.UndoToMark(markId78, None)
    
    theSession.DeleteUndoMark(markId78, None)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = -0.29220737622107418
    rotMatrix14.Xy = -0.9554610018478874
    rotMatrix14.Xz = -0.041341543631392259
    rotMatrix14.Yx = 0.0070052275793491426
    rotMatrix14.Yy = -0.04536547736865993
    rotMatrix14.Yz = 0.9989458945556936
    rotMatrix14.Zx = -0.95632932406601312
    rotMatrix14.Zy = 0.29160975191331351
    rotMatrix14.Zz = 0.019949348874050015
    translation14 = NXOpen.Point3d(0.93543798639378584, -19.863975362378248, 8.3976267899371155)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 5.389756097560972)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = -0.23267367853427642
    rotMatrix15.Xy = -0.97162610718823317
    rotMatrix15.Xz = -0.042493142359296653
    rotMatrix15.Yx = -0.020273343401525097
    rotMatrix15.Yy = -0.038837233512426433
    rotMatrix15.Yz = 0.99903986949491896
    rotMatrix15.Zx = -0.9723435354156742
    rotMatrix15.Zy = 0.23331175950504612
    rotMatrix15.Zz = -0.010661707743483156
    translation15 = NXOpen.Point3d(0.95846996095187431, -19.865854861162752, 9.009847922287781)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 5.389756097560972)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = 0.033791521303461643
    rotMatrix16.Xy = -0.99891562309872761
    rotMatrix16.Xz = -0.032026723486443712
    rotMatrix16.Yx = 0.064424435329482374
    rotMatrix16.Yy = -0.029801252419769379
    rotMatrix16.Yz = 0.99747750725852957
    rotMatrix16.Zx = -0.99735030216091791
    rotMatrix16.Zy = -0.035769586012317993
    rotMatrix16.Zz = 0.063347545303921143
    translation16 = NXOpen.Point3d(0.74914158349481641, -19.834607616434965, 7.5296628613397072)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 5.389756097560972)
    
    scaleAboutPoint42 = NXOpen.Point3d(-20.936901340996179, -10.210727969348662, 0.0)
    viewCenter42 = NXOpen.Point3d(20.936901340996179, 10.210727969348662, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(-24.82115062260538, -14.665648946360161, 0.0)
    viewCenter43 = NXOpen.Point3d(24.82115062260538, 14.665648946360152, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(-10.393281549329501, -20.709859913793117, 0.0)
    viewCenter44 = NXOpen.Point3d(10.393281549329501, 20.709859913793103, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(-10.69050639068487, -28.571936362547895, 0.0)
    viewCenter45 = NXOpen.Point3d(10.69050639068487, 28.571936362547895, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint45, viewCenter45)
    
    # ----------------------------------------------
    #   Menu: File->Save
    # ----------------------------------------------
    partSaveStatus1 = workPart.Save(NXOpen.BasePart.SaveComponents.TrueValue, NXOpen.BasePart.CloseAfterSave.FalseValue)
    
    partSaveStatus1.Dispose()
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()