﻿# NX 1872
# Journal created by user on Fri Jun 14 16:02:01 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Assemblies.ProductInterface
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.PDM
import NXOpen.Positioning
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "assembly-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "AssemblyTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Assembly"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "F:\\車子.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work # 車子
    displayPart = theSession.Parts.Display # 車子
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder1 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner1 = workPart.ComponentAssembly.Positioner
    
    componentPositioner1.ClearNetwork()
    
    componentPositioner1.BeginAssemblyConstraints()
    
    allowInterpartPositioning1 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit1)
    
    unit2 = workPart.UnitCollection.FindObject("Degrees")
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit2)
    
    expression5 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression6 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression7 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    network1 = componentPositioner1.EstablishNetwork()
    
    componentNetwork1 = network1
    componentNetwork1.MoveObjectsState = True
    
    componentNetwork1.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    theSession.SetUndoMarkName(markId4, "Add Component Dialog")
    
    componentNetwork1.MoveObjectsState = True
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    addComponentBuilder1.SetComponentAnchor(NXOpen.Assemblies.ProductInterface.InterfaceObject.Null)
    
    addComponentBuilder1.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder1.SetCount(1)
    
    addComponentBuilder1.SetScatterOption(True)
    
    addComponentBuilder1.ReferenceSet = "Unknown"
    
    addComponentBuilder1.Layer = -1
    
    # ----------------------------------------------
    #   Dialog Begin Add Component
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Tools->Predict Commands->4 Open
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: File->Open...
    # ----------------------------------------------
    componentPositioner1.ClearNetwork()
    
    addComponentBuilder1.RemoveAddedComponents()
    
    addComponentBuilder1.Destroy()
    
    componentPositioner1.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner1.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId5, None)
    
    theSession.UndoToMark(markId4, None)
    
    theSession.DeleteUndoMark(markId4, None)
    
    try:
        # File already exists
        basePart1, partLoadStatus1 = theSession.Parts.OpenActiveDisplay("F:\\本體12.prt", NXOpen.DisplayPartOption.AllowAdditional)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1020004)
        
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    part1 = theSession.Parts.FindObject("本體12")
    status1, partLoadStatus2 = theSession.Parts.SetActiveDisplay(part1, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # 本體12
    displayPart = theSession.Parts.Display # 本體12
    partLoadStatus2.Dispose()
    theSession.DeleteUndoMark(markId6, None)
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = -0.038307233258222967
    rotMatrix1.Xy = -0.9958276855816246
    rotMatrix1.Xz = -0.082823767779802382
    rotMatrix1.Yx = 0.41933998942739875
    rotMatrix1.Yy = -0.091253512049212601
    rotMatrix1.Yz = 0.90323129363730059
    rotMatrix1.Zx = -0.90702068837878735
    rotMatrix1.Zy = -0.00013102605362858705
    rotMatrix1.Zz = 0.42108604071501099
    translation1 = NXOpen.Point3d(-14.294693858399418, -37.385241272970106, 2.2218572497969902)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 2.2076440975609741)
    
    # ----------------------------------------------
    #   Menu: Tools->Predict Commands->1 Open
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: File->Open...
    # ----------------------------------------------
    try:
        # File already exists
        basePart2, partLoadStatus3 = theSession.Parts.OpenActiveDisplay("F:\\CD2024\\輪子.prt", NXOpen.DisplayPartOption.AllowAdditional)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1020004)
        
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    part2 = theSession.Parts.FindObject("輪子")
    status2, partLoadStatus4 = theSession.Parts.SetActiveDisplay(part2, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # 輪子
    displayPart = theSession.Parts.Display # 輪子
    partLoadStatus4.Dispose()
    theSession.DeleteUndoMark(markId7, None)
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    part3 = nXObject1
    status3, partLoadStatus5 = theSession.Parts.SetActiveDisplay(part3, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # 車子
    displayPart = theSession.Parts.Display # 車子
    partLoadStatus5.Dispose()
    theSession.DeleteUndoMark(markId8, None)
    
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew2 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId9, "New Dialog")
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId10, None)
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew2.TemplateFileName = "assembly-mm-template.prt"
    
    fileNew2.UseBlankTemplate = False
    
    fileNew2.ApplicationName = "AssemblyTemplate"
    
    fileNew2.Units = NXOpen.Part.Units.Millimeters
    
    fileNew2.RelationType = ""
    
    fileNew2.UsesMasterModel = "No"
    
    fileNew2.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew2.TemplatePresentationName = "Assembly"
    
    fileNew2.ItemType = ""
    
    fileNew2.Specialization = ""
    
    fileNew2.SetCanCreateAltrep(False)
    
    fileNew2.NewFileName = "F:\\CD2024\\assembly1.prt"
    
    fileNew2.MasterFileName = ""
    
    fileNew2.MakeDisplayedPart = True
    
    fileNew2.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject2 = fileNew2.Commit()
    
    workPart = theSession.Parts.Work # assembly1
    displayPart = theSession.Parts.Display # assembly1
    theSession.DeleteUndoMark(markId11, None)
    
    fileNew2.Destroy()
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder2 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner2 = workPart.ComponentAssembly.Positioner
    
    componentPositioner2.ClearNetwork()
    
    componentPositioner2.BeginAssemblyConstraints()
    
    allowInterpartPositioning2 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    unit3 = workPart.UnitCollection.FindObject("MilliMeter")
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression11 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    unit4 = workPart.UnitCollection.FindObject("Degrees")
    expression12 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression16 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network2 = componentPositioner2.EstablishNetwork()
    
    componentNetwork2 = network2
    componentNetwork2.MoveObjectsState = True
    
    componentNetwork2.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    theSession.SetUndoMarkName(markId12, "Add Component Dialog")
    
    componentNetwork2.MoveObjectsState = True
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    addComponentBuilder2.SetComponentAnchor(NXOpen.Assemblies.ProductInterface.InterfaceObject.Null)
    
    addComponentBuilder2.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder2.SetCount(1)
    
    addComponentBuilder2.SetScatterOption(True)
    
    addComponentBuilder2.ReferenceSet = "Unknown"
    
    addComponentBuilder2.Layer = -1
    
    # ----------------------------------------------
    #   Dialog Begin Add Component
    # ----------------------------------------------
    addComponentBuilder2.ReferenceSet = "Use Model"
    
    addComponentBuilder2.Layer = -1
    
    partstouse1 = [NXOpen.BasePart.Null] * 1 
    partstouse1[0] = part2
    addComponentBuilder2.SetPartsToAdd(partstouse1)
    
    productinterfaceobjects1 = addComponentBuilder2.GetAllProductInterfaceObjects()
    
    arrangement1 = workPart.ComponentAssembly.Arrangements.FindObject("Arrangement 1")
    componentPositioner2.PrimaryArrangement = arrangement1
    
    partstoremove1 = [NXOpen.BasePart.Null] * 1 
    partstoremove1[0] = part2
    addComponentBuilder2.RemovePartsFromSelection(partstoremove1)
    
    partstouse2 = []
    addComponentBuilder2.SetPartsToAdd(partstouse2)
    
    productinterfaceobjects2 = addComponentBuilder2.GetAllProductInterfaceObjects()
    
    addComponentBuilder2.SetCount(2)
    
    addComponentBuilder2.SetCount(3)
    
    addComponentBuilder2.SetCount(4)
    
    coordinates1 = NXOpen.Point3d(-6.3898578591442892, -32.950143111867703, 0.0)
    point1 = workPart.Points.CreatePoint(coordinates1)
    
    coordinates2 = NXOpen.Point3d(-6.3898578591442892, -32.950143111867703, 0.0)
    point2 = workPart.Points.CreatePoint(coordinates2)
    
    origin1 = NXOpen.Point3d(-6.3898578591442892, -32.950143111867703, 0.0)
    vector1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction1 = workPart.Directions.CreateDirection(origin1, vector1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin2 = NXOpen.Point3d(-6.3898578591442892, -32.950143111867703, 0.0)
    vector2 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction2 = workPart.Directions.CreateDirection(origin2, vector2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform1 = workPart.Xforms.CreateXformByPointXDirZDir(point2, direction2, direction1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point3 = NXOpen.Point3d(-6.3898578591442892, -32.950143111867703, 0.0)
    orientation1 = NXOpen.Matrix3x3()
    
    orientation1.Xx = 1.0
    orientation1.Xy = 0.0
    orientation1.Xz = 0.0
    orientation1.Yx = 0.0
    orientation1.Yy = 1.0
    orientation1.Yz = 0.0
    orientation1.Zx = 0.0
    orientation1.Zy = 0.0
    orientation1.Zz = 1.0
    addComponentBuilder2.SetInitialLocationAndOrientation(point3, orientation1)
    
    addComponentBuilder2.ReferenceSet = "Use Model"
    
    addComponentBuilder2.Layer = -1
    
    partstouse3 = [NXOpen.BasePart.Null] * 1 
    partstouse3[0] = part2
    addComponentBuilder2.SetPartsToAdd(partstouse3)
    
    productinterfaceobjects3 = addComponentBuilder2.GetAllProductInterfaceObjects()
    
    arrangement2 = workPart.ComponentAssembly.Arrangements.FindObject("Arrangement 1")
    componentPositioner2.PrimaryArrangement = arrangement2
    
    movableObjects1 = [NXOpen.NXObject.Null] * 4 
    component1 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 輪子 1")
    movableObjects1[0] = component1
    component2 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 輪子 1")
    movableObjects1[1] = component2
    component3 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 輪子 1")
    movableObjects1[2] = component3
    component4 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 輪子 1")
    movableObjects1[3] = component4
    componentNetwork2.SetMovingGroup(movableObjects1)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.03334558096480101
    rotMatrix2.Xy = 0.99795989850781752
    rotMatrix2.Xz = 0.05444366997537714
    rotMatrix2.Yx = -0.95856745775503704
    rotMatrix2.Yy = 0.016514634171914559
    rotMatrix2.Yz = 0.28438652533341419
    rotMatrix2.Zx = 0.28290723066610513
    rotMatrix2.Zy = -0.061670964224955091
    rotMatrix2.Zz = 0.95716257292499618
    translation2 = NXOpen.Point3d(5.5038778628657035, -3.6524112900409564, 11.564118525094083)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 0.88970341151450583)
    
    componentNetwork2.EmptyMovingGroup()
    
    addComponentBuilder2.ReferenceSet = "Use Model"
    
    addComponentBuilder2.Layer = -1
    
    partstouse4 = [NXOpen.BasePart.Null] * 2 
    part4 = theSession.Parts.FindObject("桿子")
    partstouse4[0] = part4
    partstouse4[1] = part2
    addComponentBuilder2.SetPartsToAdd(partstouse4)
    
    productinterfaceobjects4 = addComponentBuilder2.GetAllProductInterfaceObjects()
    
    movableObjects2 = [NXOpen.NXObject.Null] * 8 
    movableObjects2[0] = component1
    movableObjects2[1] = component2
    movableObjects2[2] = component3
    movableObjects2[3] = component4
    component5 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 桿子 1")
    movableObjects2[4] = component5
    component6 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 桿子 1")
    movableObjects2[5] = component6
    component7 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 桿子 1")
    movableObjects2[6] = component7
    component8 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 桿子 1")
    movableObjects2[7] = component8
    componentNetwork2.SetMovingGroup(movableObjects2)
    
    componentNetwork2.EmptyMovingGroup()
    
    addComponentBuilder2.SetCount(3)
    
    movableObjects3 = [NXOpen.NXObject.Null] * 6 
    movableObjects3[0] = component1
    movableObjects3[1] = component2
    movableObjects3[2] = component3
    movableObjects3[3] = component5
    movableObjects3[4] = component6
    movableObjects3[5] = component7
    componentNetwork2.SetMovingGroup(movableObjects3)
    
    componentNetwork2.EmptyMovingGroup()
    
    addComponentBuilder2.SetCount(2)
    
    movableObjects4 = [NXOpen.NXObject.Null] * 4 
    movableObjects4[0] = component1
    movableObjects4[1] = component2
    movableObjects4[2] = component5
    movableObjects4[3] = component6
    componentNetwork2.SetMovingGroup(movableObjects4)
    
    componentNetwork2.EmptyMovingGroup()
    
    addComponentBuilder2.SetCount(3)
    
    movableObjects5 = [NXOpen.NXObject.Null] * 6 
    movableObjects5[0] = component1
    movableObjects5[1] = component2
    movableObjects5[2] = component5
    movableObjects5[3] = component6
    component9 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 輪子 1")
    movableObjects5[4] = component9
    component10 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 桿子 1")
    movableObjects5[5] = component10
    componentNetwork2.SetMovingGroup(movableObjects5)
    
    componentNetwork2.EmptyMovingGroup()
    
    addComponentBuilder2.SetCount(4)
    
    movableObjects6 = [NXOpen.NXObject.Null] * 8 
    movableObjects6[0] = component1
    movableObjects6[1] = component2
    movableObjects6[2] = component5
    movableObjects6[3] = component6
    movableObjects6[4] = component9
    movableObjects6[5] = component10
    component11 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 輪子 1")
    movableObjects6[6] = component11
    component12 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 桿子 1")
    movableObjects6[7] = component12
    componentNetwork2.SetMovingGroup(movableObjects6)
    
    componentNetwork2.EmptyMovingGroup()
    
    addComponentBuilder2.ReferenceSet = "Use Model"
    
    addComponentBuilder2.Layer = -1
    
    partstouse5 = [NXOpen.BasePart.Null] * 3 
    partstouse5[0] = part1
    partstouse5[1] = part4
    partstouse5[2] = part2
    addComponentBuilder2.SetPartsToAdd(partstouse5)
    
    productinterfaceobjects5 = addComponentBuilder2.GetAllProductInterfaceObjects()
    
    movableObjects7 = [NXOpen.NXObject.Null] * 12 
    movableObjects7[0] = component1
    movableObjects7[1] = component2
    movableObjects7[2] = component5
    movableObjects7[3] = component6
    movableObjects7[4] = component9
    movableObjects7[5] = component10
    movableObjects7[6] = component11
    movableObjects7[7] = component12
    component13 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 本體12 1")
    movableObjects7[8] = component13
    component14 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 本體12 1")
    movableObjects7[9] = component14
    component15 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 本體12 1")
    movableObjects7[10] = component15
    component16 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 本體12 1")
    movableObjects7[11] = component16
    componentNetwork2.SetMovingGroup(movableObjects7)
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Add Component")
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "AddComponent on_apply")
    
    componentNetwork2.Solve()
    
    componentPositioner2.ClearNetwork()
    
    nErrs1 = theSession.UpdateManager.AddToDeleteList(componentNetwork2)
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId13)
    
    componentPositioner2.EndAssemblyConstraints()
    
    logicalobjects1 = addComponentBuilder2.GetLogicalObjectsHavingUnassignedRequiredAttributes()
    
    nXObject3 = addComponentBuilder2.Commit()
    
    errorList1 = addComponentBuilder2.GetOperationFailures()
    
    errorList1.Dispose()
    theSession.DeleteUndoMark(markId14, None)
    
    theSession.SetUndoMarkName(markId12, "Add Component")
    
    addComponentBuilder2.Destroy()
    
    workPart.Points.DeletePoint(point1)
    
    componentPositioner2.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    theSession.DeleteUndoMark(markId13, None)
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder3 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner3 = workPart.ComponentAssembly.Positioner
    
    componentPositioner3.ClearNetwork()
    
    componentPositioner3.PrimaryArrangement = arrangement2
    
    componentPositioner3.BeginAssemblyConstraints()
    
    allowInterpartPositioning3 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression17 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression18 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression19 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression20 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression21 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression22 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network3 = componentPositioner3.EstablishNetwork()
    
    componentNetwork3 = network3
    componentNetwork3.MoveObjectsState = True
    
    componentNetwork3.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    theSession.SetUndoMarkName(markId16, "Add Component Dialog")
    
    componentNetwork3.MoveObjectsState = True
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    addComponentBuilder3.SetComponentAnchor(NXOpen.Assemblies.ProductInterface.InterfaceObject.Null)
    
    addComponentBuilder3.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder3.SetCount(4)
    
    addComponentBuilder3.SetScatterOption(True)
    
    addComponentBuilder3.ReferenceSet = "Unknown"
    
    addComponentBuilder3.Layer = -1
    
    # ----------------------------------------------
    #   Dialog Begin Add Component
    # ----------------------------------------------
    scaleAboutPoint1 = NXOpen.Point3d(95.311490588738479, -66.019191609048008, 0.0)
    viewCenter1 = NXOpen.Point3d(-95.311490588738479, 66.019191609048008, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(106.50055403148819, -78.806692686476609, 0.0)
    viewCenter2 = NXOpen.Point3d(-106.50055403148819, 78.806692686476609, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(128.9437336114222, -96.649717445678448, 0.0)
    viewCenter3 = NXOpen.Point3d(-128.9437336114222, 96.649717445678448, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(119.94090536377789, -95.836558765245883, 0.0)
    viewCenter4 = NXOpen.Point3d(-119.94090536377789, 95.836558765245883, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(94.094075878605395, -89.679785899115501, 0.0)
    viewCenter5 = NXOpen.Point3d(-94.094075878605395, 89.679785899115501, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(118.19842247713703, -116.16552577605626, 0.0)
    viewCenter6 = NXOpen.Point3d(-118.19842247713703, 116.16552577605626, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint6, viewCenter6)
    
    addComponentBuilder3.ReferenceSet = "Use Model"
    
    addComponentBuilder3.Layer = -1
    
    partstouse6 = [NXOpen.BasePart.Null] * 1 
    partstouse6[0] = part1
    addComponentBuilder3.SetPartsToAdd(partstouse6)
    
    productinterfaceobjects6 = addComponentBuilder3.GetAllProductInterfaceObjects()
    
    componentPositioner3.ClearNetwork()
    
    addComponentBuilder3.RemoveAddedComponents()
    
    addComponentBuilder3.Destroy()
    
    componentPositioner3.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner3.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId17, None)
    
    theSession.UndoToMark(markId16, None)
    
    theSession.DeleteUndoMark(markId16, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete1 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects1 = [NXOpen.TaggedObject.Null] * 1 
    objects1[0] = component13
    nErrs3 = theSession.UpdateManager.AddObjectsToDeleteList(objects1)
    
    notifyOnDelete2 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs4 = theSession.UpdateManager.DoUpdate(id1)
    
    theSession.DeleteUndoMark(markId18, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete3 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects2 = [NXOpen.TaggedObject.Null] * 1 
    objects2[0] = component14
    nErrs5 = theSession.UpdateManager.AddObjectsToDeleteList(objects2)
    
    notifyOnDelete4 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id2 = theSession.NewestVisibleUndoMark
    
    nErrs6 = theSession.UpdateManager.DoUpdate(id2)
    
    theSession.DeleteUndoMark(markId20, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete5 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects3 = [NXOpen.TaggedObject.Null] * 1 
    objects3[0] = component15
    nErrs7 = theSession.UpdateManager.AddObjectsToDeleteList(objects3)
    
    notifyOnDelete6 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id3 = theSession.NewestVisibleUndoMark
    
    nErrs8 = theSession.UpdateManager.DoUpdate(id3)
    
    theSession.DeleteUndoMark(markId22, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete7 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects4 = [NXOpen.TaggedObject.Null] * 1 
    component17 = nXObject3
    objects4[0] = component17
    nErrs9 = theSession.UpdateManager.AddObjectsToDeleteList(objects4)
    
    notifyOnDelete8 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id4 = theSession.NewestVisibleUndoMark
    
    nErrs10 = theSession.UpdateManager.DoUpdate(id4)
    
    theSession.DeleteUndoMark(markId24, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete9 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects5 = [NXOpen.TaggedObject.Null] * 1 
    objects5[0] = component6
    nErrs11 = theSession.UpdateManager.AddObjectsToDeleteList(objects5)
    
    notifyOnDelete10 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id5 = theSession.NewestVisibleUndoMark
    
    nErrs12 = theSession.UpdateManager.DoUpdate(id5)
    
    theSession.DeleteUndoMark(markId26, None)
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = -0.87584803655243992
    rotMatrix3.Xy = 0.43402742757263002
    rotMatrix3.Xz = 0.21097490130799487
    rotMatrix3.Yx = -0.12031335697958685
    rotMatrix3.Yy = -0.61975569535972919
    rotMatrix3.Yz = 0.77551761695107757
    rotMatrix3.Zx = 0.46734881298612008
    rotMatrix3.Zy = 0.65385248350362835
    rotMatrix3.Zz = 0.59503110575548968
    translation3 = NXOpen.Point3d(159.42702074012382, -130.90660904519245, 0.79394848866142098)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 0.36442251735634168)
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status4, partLoadStatus6 = theSession.Parts.SetActiveDisplay(part3, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # 車子
    displayPart = theSession.Parts.Display # 車子
    partLoadStatus6.Dispose()
    workPart.Close(NXOpen.BasePart.CloseWholeTree.FalseValue, NXOpen.BasePart.CloseModified.UseResponses, None)
    
    workPart = NXOpen.Part.Null
    displayPart = NXOpen.Part.Null
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    part5 = nXObject2
    status5, partLoadStatus7 = theSession.Parts.SetActiveDisplay(part5, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # assembly1
    displayPart = theSession.Parts.Display # assembly1
    partLoadStatus7.Dispose()
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner4 = workPart.ComponentAssembly.Positioner
    
    componentPositioner4.ClearNetwork()
    
    componentPositioner4.PrimaryArrangement = arrangement2
    
    componentPositioner4.BeginAssemblyConstraints()
    
    allowInterpartPositioning4 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression25 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression26 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression27 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression29 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression30 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression31 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression32 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network4 = componentPositioner4.EstablishNetwork()
    
    componentNetwork4 = network4
    componentNetwork4.MoveObjectsState = True
    
    componentNetwork4.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork4.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId31, "Assembly Constraints Dialog")
    
    componentNetwork4.MoveObjectsState = True
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = -0.30965220293384665
    rotMatrix4.Xy = 0.93496913157698458
    rotMatrix4.Xz = 0.1730555870707203
    rotMatrix4.Yx = -0.44594741650865982
    rotMatrix4.Yy = -0.30354400556429495
    rotMatrix4.Yz = 0.84201659033253629
    rotMatrix4.Zx = 0.83978950632135341
    rotMatrix4.Zy = 0.18355860013674
    rotMatrix4.Zz = 0.51094013875245092
    translation4 = NXOpen.Point3d(130.49782473077349, -122.15246266880101, -7.8013541045267552)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 0.36442251735634168)
    
    scaleAboutPoint7 = NXOpen.Point3d(215.99527448985421, -188.76897938609068, 0.0)
    viewCenter7 = NXOpen.Point3d(-215.99527448985421, 188.76897938609068, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(172.79621959188324, -151.0151835088725, 0.0)
    viewCenter8 = NXOpen.Point3d(-172.79621959188333, 151.0151835088725, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(138.23697567350663, -120.81214680709803, 0.0)
    viewCenter9 = NXOpen.Point3d(-138.23697567350678, 120.81214680709803, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(116.90898514102273, -90.702042525944492, 0.0)
    viewCenter10 = NXOpen.Point3d(-116.90898514102297, 90.702042525944492, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(93.229804366831502, -71.669482782795384, 0.0)
    viewCenter11 = NXOpen.Point3d(-93.229804366831658, 71.669482782795384, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint11, viewCenter11)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = -0.56960822929953514
    rotMatrix5.Xy = 0.82191156160905787
    rotMatrix5.Xz = -0.0028017865021562165
    rotMatrix5.Yx = -0.21831453793039804
    rotMatrix5.Yy = -0.14801006683658421
    rotMatrix5.Yz = 0.9645889189925736
    rotMatrix5.Zx = 0.79239209211253436
    rotMatrix5.Zy = 0.55004945687491191
    rotMatrix5.Zz = 0.263742994881627
    translation5 = NXOpen.Point3d(-2.1502712331703027, -10.709365849893839, -6.4992410061829737)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 1.1121292643931324)
    
    face1 = component12.FindObject("PROTO#.Features|EXTRUDE(2)|FACE 140 {(0,-25,-1.5) EXTRUDE(2)}")
    line1 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line1.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = -0.97096159723526365
    rotMatrix6.Xy = 0.13204146952463833
    rotMatrix6.Xz = -0.19949593233977173
    rotMatrix6.Yx = -0.21831453793039804
    rotMatrix6.Yy = -0.14801006683658421
    rotMatrix6.Yz = 0.9645889189925736
    rotMatrix6.Zx = 0.097838332071725306
    rotMatrix6.Zy = 0.9801316597482197
    rotMatrix6.Zz = 0.17253866330947046
    translation6 = NXOpen.Point3d(25.706093036321715, -10.709365849893839, 18.585322029326065)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 1.1121292643931324)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = -0.66979682948087638
    rotMatrix7.Xy = 0.7421428298430145
    rotMatrix7.Xz = -0.024417766686653238
    rotMatrix7.Yx = -0.25611328981463588
    rotMatrix7.Yy = -0.20003077344073172
    rotMatrix7.Yz = 0.94572388806512753
    rotMatrix7.Zx = 0.69697789778276675
    rotMatrix7.Zy = 0.63969657634639587
    rotMatrix7.Zz = 0.3240526195126488
    translation7 = NXOpen.Point3d(3.2877357562119727, -8.2353701740032506, -4.510671415163781)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 1.1121292643931324)
    
    face2 = component16.FindObject("PROTO#.Features|EXTRUDE(6)|FACE 170 {(0,-25.9824950782831,2.5) EXTRUDE(2)}")
    line2 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line2.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint1 = componentPositioner4.CreateConstraint(True)
    
    componentConstraint1 = constraint1
    componentConstraint1.ConstraintAlignment = NXOpen.Positioning.Constraint.Alignment.InferAlign
    
    componentConstraint1.ConstraintType = NXOpen.Positioning.Constraint.Type.Touch
    
    constraintReference1 = componentConstraint1.CreateConstraintReference(component12, face1, True, False, False)
    
    helpPoint1 = NXOpen.Point3d(202.32046771196775, -34.574352330537494, 1.0658141036401503e-13)
    constraintReference1.HelpPoint = helpPoint1
    
    constraintReference2 = componentConstraint1.CreateConstraintReference(component16, face2, True, False, False)
    
    helpPoint2 = NXOpen.Point3d(-59.489700974975904, 136.21490623500051, 3.9999999999999361)
    constraintReference2.HelpPoint = helpPoint2
    
    constraintReference2.SetFixHint(True)
    
    objects6 = [NXOpen.TaggedObject.Null] * 1 
    objects6[0] = line1
    nErrs13 = theSession.UpdateManager.AddObjectsToDeleteList(objects6)
    
    objects7 = [NXOpen.TaggedObject.Null] * 1 
    objects7[0] = line2
    nErrs14 = theSession.UpdateManager.AddObjectsToDeleteList(objects7)
    
    componentNetwork4.Solve()
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs15 = theSession.UpdateManager.DoUpdate(markId32)
    
    componentNetwork4.Solve()
    
    componentPositioner4.ClearNetwork()
    
    nErrs16 = theSession.UpdateManager.AddToDeleteList(componentNetwork4)
    
    componentPositioner4.DeleteNonPersistentConstraints()
    
    nErrs17 = theSession.UpdateManager.DoUpdate(markId32)
    
    theSession.DeleteUndoMark(markId34, None)
    
    theSession.SetUndoMarkName(markId31, "Assembly Constraints")
    
    componentPositioner4.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner4.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId32, None)
    
    theSession.DeleteUndoMark(markId33, None)
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner5 = workPart.ComponentAssembly.Positioner
    
    componentPositioner5.ClearNetwork()
    
    componentPositioner5.PrimaryArrangement = arrangement2
    
    componentPositioner5.BeginAssemblyConstraints()
    
    allowInterpartPositioning5 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression33 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression34 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression35 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression36 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression37 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression38 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression39 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression40 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network5 = componentPositioner5.EstablishNetwork()
    
    componentNetwork5 = network5
    componentNetwork5.MoveObjectsState = True
    
    componentNetwork5.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork5.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId35, "Assembly Constraints Dialog")
    
    componentNetwork5.MoveObjectsState = True
    
    componentNetwork5.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    # ----------------------------------------------
    #   Dialog Begin Assembly Constraints
    # ----------------------------------------------
    line3 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line3.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    objects8 = [NXOpen.TaggedObject.Null] * 1 
    objects8[0] = line3
    nErrs18 = theSession.UpdateManager.AddObjectsToDeleteList(objects8)
    
    line4 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects9 = [NXOpen.TaggedObject.Null] * 1 
    objects9[0] = line4
    nErrs19 = theSession.UpdateManager.AddObjectsToDeleteList(objects9)
    
    expression41 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    scalar1 = workPart.Scalars.CreateScalar(0.68058076532897716, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    scalar2 = workPart.Scalars.CreateScalar(0.45127471971881555, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    extrude1 = part4.Features.FindObject("EXTRUDE(2)")
    face3 = extrude1.FindObject("FACE 140 {(0,-25,-1.5) EXTRUDE(2)}")
    point4 = workPart.Points.CreatePoint(face3, scalar1, scalar2, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    direction3 = workPart.Directions.CreateDirection(face3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    xform2, nXObject4 = workPart.Xforms.CreateExtractXform(face1, NXOpen.SmartObject.UpdateOption.AfterParentBody, False)
    
    direction4 = workPart.Directions.CreateDirection(direction3, xform2, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    expression42 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = -0.29274614653858
    rotMatrix8.Xy = -0.89333557670863728
    rotMatrix8.Xz = -0.34095636241820165
    rotMatrix8.Yx = -0.016283662523974948
    rotMatrix8.Yy = -0.35186858670218668
    rotMatrix8.Yz = 0.93590776256370789
    rotMatrix8.Zx = -0.95605153418715405
    rotMatrix8.Zy = 0.27953540934709109
    rotMatrix8.Zz = 0.088461397793257249
    translation8 = NXOpen.Point3d(2.7524262172554756, -22.053558699602853, 112.07131046518123)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 1.1121292643931324)
    
    expression43 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    extrude2 = part1.Features.FindObject("EXTRUDE(2)")
    edge1 = extrude2.FindObject("EDGE * 150 EXTRUDE(6) 170 {(-25,-25.2324950782831,2.7009618943233)(-25,-27.4824950782831,4)(-25,-25.2324950782831,5.2990381056767) EXTRUDE(2)}")
    direction5 = workPart.Directions.CreateDirection(edge1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    edge2 = component16.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 150 EXTRUDE(6) 170 {(-25,-25.2324950782831,2.7009618943233)(-25,-27.4824950782831,4)(-25,-25.2324950782831,5.2990381056767) EXTRUDE(2)}")
    xform3, nXObject5 = workPart.Xforms.CreateExtractXform(edge2, NXOpen.SmartObject.UpdateOption.AfterParentBody, False)
    
    direction6 = workPart.Directions.CreateDirection(direction5, xform3, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    expression44 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = -0.93420478647886518
    rotMatrix9.Xy = 0.32828232987075889
    rotMatrix9.Xz = 0.13961421422833761
    rotMatrix9.Yx = 0.097470485600982079
    rotMatrix9.Yy = -0.14158191176386109
    rotMatrix9.Yz = 0.98511627064930429
    rotMatrix9.Zx = 0.34316311188220455
    rotMatrix9.Zy = 0.93390860053642788
    rotMatrix9.Zz = 0.10026866154190307
    translation9 = NXOpen.Point3d(23.162106969061035, -32.785403471499265, 18.610890117431659)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 1.1121292643931324)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = -0.93255058827197113
    rotMatrix10.Xy = -0.35784214081087107
    rotMatrix10.Xz = 0.047941658017683658
    rotMatrix10.Yx = 0.093026904541681554
    rotMatrix10.Yy = -0.10985277322782984
    rotMatrix10.Yz = 0.98958494493678617
    rotMatrix10.Zx = -0.34884867112400586
    rotMatrix10.Zy = 0.92729788658987022
    rotMatrix10.Zz = 0.1357322149711242
    translation10 = NXOpen.Point3d(32.618306545541842, -32.938835940222944, 63.68372558514325)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 1.1121292643931324)
    
    scaleAboutPoint12 = NXOpen.Point3d(-52.696399788843976, -68.279308078547118, 0.0)
    viewCenter12 = NXOpen.Point3d(52.696399788843742, 68.279308078547118, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(-65.870499736054924, -85.349135098183893, 0.0)
    viewCenter13 = NXOpen.Point3d(65.870499736054697, 85.349135098183893, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(-82.338124670068581, -106.68641887272986, 0.0)
    viewCenter14 = NXOpen.Point3d(82.338124670068439, 106.68641887272986, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint14, viewCenter14)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = -0.98615813638647865
    rotMatrix11.Xy = 0.11701547550225803
    rotMatrix11.Xz = 0.11747130939815935
    rotMatrix11.Yx = 0.078339601702814718
    rotMatrix11.Yy = -0.29559187772739642
    rotMatrix11.Yz = 0.95209681683462721
    rotMatrix11.Zx = 0.14613362667018839
    rotMatrix11.Zy = 0.94812067813889778
    rotMatrix11.Zz = 0.28233338952671816
    translation11 = NXOpen.Point3d(-20.792322254380281, -94.271907128487385, 28.672397777128477)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 0.56941018336928384)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = -0.27993560289615871
    rotMatrix12.Xy = -0.93309673177364305
    rotMatrix12.Xz = -0.22575771832763805
    rotMatrix12.Yx = 0.018455868753072771
    rotMatrix12.Yy = -0.24034693063120688
    rotMatrix12.Yz = 0.97051158357060341
    rotMatrix12.Zx = -0.95984136144454879
    rotMatrix12.Zy = 0.26751419044509572
    rotMatrix12.Zz = 0.084502773746023607
    translation12 = NXOpen.Point3d(-49.569976248937962, -91.267946473375503, 112.52350543082568)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 0.56941018336928384)
    
    scaleAboutPoint15 = NXOpen.Point3d(-144.74224511696593, -117.55951208536851, 0.0)
    viewCenter15 = NXOpen.Point3d(144.74224511696573, 117.55951208536851, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(-115.79379609357279, -94.047609668294811, 0.0)
    viewCenter16 = NXOpen.Point3d(115.79379609357254, 94.047609668294811, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(-92.635036874858216, -75.23808773463584, 0.0)
    viewCenter17 = NXOpen.Point3d(92.635036874858031, 75.23808773463584, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(-74.108029499886626, -60.190470187708677, 0.0)
    viewCenter18 = NXOpen.Point3d(74.108029499886385, 60.190470187708677, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(-65.947819510011485, -49.294329734756012, 0.0)
    viewCenter19 = NXOpen.Point3d(65.947819510011243, 49.294329734756012, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(-52.758255608009215, -39.435463787804807, 0.0)
    viewCenter20 = NXOpen.Point3d(52.758255608008987, 39.435463787804807, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-42.206604486407393, -31.54837103024385, 0.0)
    viewCenter21 = NXOpen.Point3d(42.206604486407159, 31.54837103024385, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-33.765283589125936, -25.238696824195085, 0.0)
    viewCenter22 = NXOpen.Point3d(33.765283589125715, 25.238696824195085, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(-27.012226871300765, -20.190957459356067, 0.0)
    viewCenter23 = NXOpen.Point3d(27.012226871300538, 20.190957459356067, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = 0.11891286771176508
    rotMatrix13.Xy = 0.98614988903124357
    rotMatrix13.Xz = 0.11562061345725456
    rotMatrix13.Yx = -0.074069564668644144
    rotMatrix13.Yy = -0.10731195798996745
    rotMatrix13.Yz = 0.99146247698143197
    rotMatrix13.Zx = 0.99013808606797959
    rotMatrix13.Zy = -0.12646161487197333
    rotMatrix13.Zz = 0.060282920314224345
    translation13 = NXOpen.Point3d(-94.754469687813341, -8.831071444115361, 283.41757347150502)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 4.2424364639020249)
    
    scaleAboutPoint24 = NXOpen.Point3d(0.28064651294845661, -14.718350456858808, 0.0)
    viewCenter24 = NXOpen.Point3d(-0.28064651294870341, 14.718350456858808, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(0.35080814118558351, -18.397938071073504, 0.0)
    viewCenter25 = NXOpen.Point3d(-0.35080814118585346, 18.397938071073504, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(0.43851017648201146, -22.997422588841875, 0.0)
    viewCenter26 = NXOpen.Point3d(-0.43851017648228457, 22.997422588841875, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(0.5481377206025746, -28.746778236052347, 0.0)
    viewCenter27 = NXOpen.Point3d(-0.54813772060281551, 28.746778236052347, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(-4.0349026655477136, -33.19278419205186, 0.0)
    viewCenter28 = NXOpen.Point3d(4.0349026655474622, 33.19278419205186, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(-5.0436283319345803, -41.490980240064836, 0.0)
    viewCenter29 = NXOpen.Point3d(5.04362833193436, 41.490980240064836, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(-6.3045354149182247, -51.863725300081036, 0.0)
    viewCenter30 = NXOpen.Point3d(6.3045354149179893, 51.863725300081036, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(-7.880669268647682, -64.829656625101293, 0.0)
    viewCenter31 = NXOpen.Point3d(7.8806692686475346, 64.829656625101293, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(-9.8508365858096631, -81.037070781376613, 0.0)
    viewCenter32 = NXOpen.Point3d(9.850836585809418, 81.037070781376613, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(-14.172194144678896, -103.15498688913746, 0.0)
    viewCenter33 = NXOpen.Point3d(14.172194144678665, 103.15498688913746, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = -0.84234934044613385
    rotMatrix14.Xy = 0.53862334681828938
    rotMatrix14.Xz = -0.018234004283987394
    rotMatrix14.Yx = -0.088807865212521528
    rotMatrix14.Yy = -0.10535594900383295
    rotMatrix14.Yz = 0.99046114870089463
    rotMatrix14.Zx = 0.53156443798128339
    rotMatrix14.Zy = 0.8359336183404561
    rotMatrix14.Zz = 0.13658050374001091
    translation14 = NXOpen.Point3d(-29.205167953767408, -76.557479460098179, 300.95397797337563)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 0.71176272921160511)
    
    scaleAboutPoint34 = NXOpen.Point3d(-171.55324846607957, -33.827401105987676, 0.0)
    viewCenter34 = NXOpen.Point3d(171.55324846607934, 33.827401105987676, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(-213.97689847949519, -42.284251382484598, 0.0)
    viewCenter35 = NXOpen.Point3d(213.97689847949496, 42.284251382484598, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(-267.47112309936909, -52.855314228105748, 0.0)
    viewCenter36 = NXOpen.Point3d(267.4711230993687, 52.855314228105748, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(-334.33890387421121, -66.069142785132186, 0.0)
    viewCenter37 = NXOpen.Point3d(334.33890387421098, 66.069142785132186, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(-341.69000355222698, -176.97091817446051, 0.0)
    viewCenter38 = NXOpen.Point3d(341.69000355222698, 176.97091817446051, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(-273.35200284178165, -141.57673453956838, 0.0)
    viewCenter39 = NXOpen.Point3d(273.35200284178165, 141.57673453956838, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(-157.11387361211575, -159.14677031319704, 0.0)
    viewCenter40 = NXOpen.Point3d(157.11387361211555, 159.14677031319704, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(-125.22643678658837, -127.31741625055761, 0.0)
    viewCenter41 = NXOpen.Point3d(125.22643678658822, 127.31741625055761, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(-73.416612290467427, -73.230747449225689, 0.0)
    viewCenter42 = NXOpen.Point3d(73.416612290467299, 73.230747449225689, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(-64.680964752108011, -32.712212058537503, 0.0)
    viewCenter43 = NXOpen.Point3d(64.680964752107883, 32.712212058537503, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint43, viewCenter43)
    
    nErrs20 = theSession.UpdateManager.AddToDeleteList(direction6)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    componentPositioner5.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner5.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId36, None)
    
    workPart.Expressions.Delete(expression42)
    
    workPart.Expressions.Delete(expression44)
    
    workPart.Expressions.Delete(expression41)
    
    workPart.Expressions.Delete(expression43)
    
    theSession.UndoToMark(markId35, None)
    
    theSession.DeleteUndoMark(markId35, None)
    
    theSession.DeleteUndoMark(markId30, None)
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner6 = workPart.ComponentAssembly.Positioner
    
    componentPositioner6.ClearNetwork()
    
    componentPositioner6.PrimaryArrangement = arrangement2
    
    componentPositioner6.BeginAssemblyConstraints()
    
    allowInterpartPositioning6 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression45 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression46 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression47 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression48 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression49 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression50 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression51 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression52 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network6 = componentPositioner6.EstablishNetwork()
    
    componentNetwork6 = network6
    componentNetwork6.MoveObjectsState = True
    
    componentNetwork6.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork6.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId38, "Assembly Constraints Dialog")
    
    componentNetwork6.MoveObjectsState = True
    
    componentNetwork6.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    line5 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line5.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    scaleAboutPoint44 = NXOpen.Point3d(-207.23929798448381, -23.790699678936249, 0.0)
    viewCenter44 = NXOpen.Point3d(207.23929798448381, 23.790699678936249, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(-165.79143838758711, -19.032559743148997, 0.0)
    viewCenter45 = NXOpen.Point3d(165.79143838758705, 19.032559743148997, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(-136.67756965548884, -15.701861788097872, 0.0)
    viewCenter46 = NXOpen.Point3d(136.67756965548878, 15.701861788097872, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(-125.7100571034992, -12.561489430478046, 0.0)
    viewCenter47 = NXOpen.Point3d(125.71005710349917, 12.561489430478549, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(-100.56804568279932, -10.049191544382436, 0.0)
    viewCenter48 = NXOpen.Point3d(100.56804568279932, 10.049191544382838, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = -0.73598500420227642
    rotMatrix15.Xy = 0.67633185434121401
    rotMatrix15.Xz = 0.030021598770742446
    rotMatrix15.Yx = -0.068177628531592371
    rotMatrix15.Yy = -0.11816481911015078
    rotMatrix15.Yz = 0.99065073890472266
    rotMatrix15.Zx = 0.67355614803606678
    rotMatrix15.Zy = 0.7270572868268641
    rotMatrix15.Zz = 0.13307823681870359
    translation15 = NXOpen.Point3d(39.515642431274131, 17.122375490243371, 292.60982563939109)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 2.1721274695178385)
    
    scaleAboutPoint49 = NXOpen.Point3d(-52.316700221967984, -11.20637117676594, 0.0)
    viewCenter49 = NXOpen.Point3d(52.316700221967977, 11.206371176766261, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(-41.853360177574388, -8.9650969414127513, 0.0)
    viewCenter50 = NXOpen.Point3d(41.853360177574388, 8.9650969414130071, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(-33.482688142059509, -7.1720775531302019, 0.0)
    viewCenter51 = NXOpen.Point3d(33.482688142059509, 7.172077553130408, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint51, viewCenter51)
    
    objects10 = [NXOpen.TaggedObject.Null] * 1 
    objects10[0] = line5
    nErrs21 = theSession.UpdateManager.AddObjectsToDeleteList(objects10)
    
    expression53 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    scalar3 = workPart.Scalars.CreateScalar(0.74557864036996402, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    scalar4 = workPart.Scalars.CreateScalar(0.969802565183428, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    face4 = nXObject4
    point5 = workPart.Points.CreatePoint(face4, scalar3, scalar4, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    direction7 = workPart.Directions.CreateDirection(face4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    xform4, nXObject6 = workPart.Xforms.CreateExtractXform(face1, NXOpen.SmartObject.UpdateOption.AfterParentBody, False)
    
    direction8 = workPart.Directions.CreateDirection(direction7, xform4, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    expression54 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    scaleAboutPoint52 = NXOpen.Point3d(-3.7107705600978509, -10.16564035791497, 0.0)
    viewCenter52 = NXOpen.Point3d(3.7107705600978815, 10.165640357915299, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(-2.9686164480782717, -8.1325122863319734, 0.0)
    viewCenter53 = NXOpen.Point3d(2.9686164480783046, 8.1325122863322381, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(-3.7107705600978496, -10.165640357914967, 0.0)
    viewCenter54 = NXOpen.Point3d(3.7107705600978802, 10.165640357915295, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(11.2648392002971, -15.357600847463745, 0.0)
    viewCenter55 = NXOpen.Point3d(-11.264839200297061, 15.357600847463951, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(14.08104900037139, -19.197001059329683, 0.0)
    viewCenter56 = NXOpen.Point3d(-14.081049000371326, 19.197001059329938, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(17.601311250464224, -23.996251324162099, 0.0)
    viewCenter57 = NXOpen.Point3d(-17.601311250464164, 23.996251324162419, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint57, viewCenter57)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = -0.93038312846813476
    rotMatrix16.Xy = 0.36644987639470994
    rotMatrix16.Xz = -0.010085749954695987
    rotMatrix16.Yx = -0.030479999776481869
    rotMatrix16.Yy = -0.049910207299024387
    rotMatrix16.Yz = 0.99828850580430584
    rotMatrix16.Zx = 0.36531931768724191
    rotMatrix16.Zy = 0.92909819680035477
    rotMatrix16.Zz = 0.057605006959961812
    translation16 = NXOpen.Point3d(92.430826799205164, 1.9083870637535245, 312.37905056085759)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 1.7377019756142713)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Components->Add Component...
    # ----------------------------------------------
    componentPositioner6.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner6.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId39, None)
    
    workPart.Expressions.Delete(expression54)
    
    workPart.Expressions.Delete(expression53)
    
    theSession.UndoToMark(markId38, None)
    
    theSession.DeleteUndoMark(markId38, None)
    
    theSession.DeleteUndoMark(markId37, None)
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder4 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner7 = workPart.ComponentAssembly.Positioner
    
    componentPositioner7.ClearNetwork()
    
    componentPositioner7.PrimaryArrangement = arrangement2
    
    componentPositioner7.BeginAssemblyConstraints()
    
    allowInterpartPositioning7 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression55 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression56 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression57 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression58 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression59 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression60 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression61 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression62 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network7 = componentPositioner7.EstablishNetwork()
    
    componentNetwork7 = network7
    componentNetwork7.MoveObjectsState = True
    
    componentNetwork7.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    theSession.SetUndoMarkName(markId40, "Add Component Dialog")
    
    componentNetwork7.MoveObjectsState = True
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    addComponentBuilder4.SetComponentAnchor(NXOpen.Assemblies.ProductInterface.InterfaceObject.Null)
    
    addComponentBuilder4.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder4.SetCount(4)
    
    addComponentBuilder4.SetScatterOption(True)
    
    addComponentBuilder4.ReferenceSet = "Unknown"
    
    addComponentBuilder4.Layer = -1
    
    addComponentBuilder4.SetCount(3)
    
    addComponentBuilder4.SetCount(2)
    
    addComponentBuilder4.SetCount(1)
    
    addComponentBuilder4.ReferenceSet = "Use Model"
    
    addComponentBuilder4.Layer = -1
    
    partstouse7 = [NXOpen.BasePart.Null] * 1 
    partstouse7[0] = part1
    addComponentBuilder4.SetPartsToAdd(partstouse7)
    
    productinterfaceobjects7 = addComponentBuilder4.GetAllProductInterfaceObjects()
    
    scaleAboutPoint58 = NXOpen.Point3d(23.371983364587003, -50.854999633693858, 0.0)
    viewCenter58 = NXOpen.Point3d(-23.371983364586928, 50.854999633694263, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint58, viewCenter58)
    
    componentPositioner7.ClearNetwork()
    
    addComponentBuilder4.RemoveAddedComponents()
    
    addComponentBuilder4.Destroy()
    
    componentPositioner7.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner7.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId41, None)
    
    theSession.UndoToMark(markId40, None)
    
    theSession.DeleteUndoMark(markId40, None)
    
    scaleAboutPoint59 = NXOpen.Point3d(71.086610640661533, -34.639258732531097, 0.0)
    viewCenter59 = NXOpen.Point3d(-71.086610640661476, 34.639258732531594, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(88.85826330082692, -44.012794406032043, 0.0)
    viewCenter60 = NXOpen.Point3d(-88.858263300826849, 44.012794406032043, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(111.07282912603364, -55.313376753526917, 0.0)
    viewCenter61 = NXOpen.Point3d(-111.07282912603354, 55.313376753526917, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(176.75746402084664, -100.36701427051214, 0.0)
    viewCenter62 = NXOpen.Point3d(-176.75746402084653, 100.36701427051214, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(223.73480264468367, -128.24674045676585, 0.0)
    viewCenter63 = NXOpen.Point3d(-223.7348026446835, 128.24674045676585, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(282.57264145025601, -162.63173608647821, 0.0)
    viewCenter64 = NXOpen.Point3d(-282.5726414502559, 162.63173608647821, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(368.46252707092708, -195.30329021099422, 0.0)
    viewCenter65 = NXOpen.Point3d(-368.46252707092708, 195.30329021099422, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(294.77002165674168, -156.24263216879538, 0.0)
    viewCenter66 = NXOpen.Point3d(-294.77002165674168, 156.24263216879538, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(245.10925938747775, -121.74147101330676, 0.0)
    viewCenter67 = NXOpen.Point3d(-245.10925938747775, 121.74147101330676, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(196.45913719246559, -97.021447128161824, 0.0)
    viewCenter68 = NXOpen.Point3d(-196.45913719246559, 97.021447128161824, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint68, viewCenter68)
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = -0.95742373788922419
    rotMatrix17.Xy = -0.28824392958770434
    rotMatrix17.Xz = 0.015975705995746832
    rotMatrix17.Yx = 0.078888771412297137
    rotMatrix17.Yy = -0.20799948356060272
    rotMatrix17.Yz = 0.97494244783145012
    rotMatrix17.Zx = -0.27769830368816195
    rotMatrix17.Zy = 0.93469334644810675
    rotMatrix17.Zz = 0.22188285250184722
    translation17 = NXOpen.Point3d(125.03706914151881, -33.004221020921321, 352.1507617749503)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 0.88970341151450771)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner8 = workPart.ComponentAssembly.Positioner
    
    componentPositioner8.ClearNetwork()
    
    componentPositioner8.PrimaryArrangement = arrangement2
    
    componentPositioner8.BeginAssemblyConstraints()
    
    allowInterpartPositioning8 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression63 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression64 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression65 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression66 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression67 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression68 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression69 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression70 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network8 = componentPositioner8.EstablishNetwork()
    
    componentNetwork8 = network8
    componentNetwork8.MoveObjectsState = True
    
    componentNetwork8.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork8.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId43, "Assembly Constraints Dialog")
    
    componentNetwork8.MoveObjectsState = True
    
    componentNetwork8.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    expression71 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    scaleAboutPoint69 = NXOpen.Point3d(-107.20684042820641, -41.931108184125272, 0.0)
    viewCenter69 = NXOpen.Point3d(107.20684042820636, 41.931108184125272, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(-85.765472342565133, -33.544886547300223, 0.0)
    viewCenter70 = NXOpen.Point3d(85.765472342565062, 33.544886547300223, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(-68.612377874052115, -26.835909237840177, 0.0)
    viewCenter71 = NXOpen.Point3d(68.612377874052044, 26.835909237840177, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(-54.889902299241683, -21.468727390272139, 0.0)
    viewCenter72 = NXOpen.Point3d(54.889902299241626, 21.468727390272139, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(-45.739047574735672, -18.393065735778961, 0.0)
    viewCenter73 = NXOpen.Point3d(45.739047574735586, 18.393065735779281, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(-36.591238059788559, -14.714452588623171, 0.0)
    viewCenter74 = NXOpen.Point3d(36.591238059788466, 14.714452588623427, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint74, viewCenter74)
    
    scaleAboutPoint75 = NXOpen.Point3d(-29.272990447830857, -11.771562070898531, 0.0)
    viewCenter75 = NXOpen.Point3d(29.272990447830743, 11.771562070898737, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(-23.418392358264725, -9.2925178731861404, 0.0)
    viewCenter76 = NXOpen.Point3d(23.418392358264555, 9.2925178731863038, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint76, viewCenter76)
    
    scaleAboutPoint77 = NXOpen.Point3d(-16.689112636675507, -6.0370183229826679, 0.0)
    viewCenter77 = NXOpen.Point3d(16.689112636675304, 6.0370183229828003, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint77, viewCenter77)
    
    scaleAboutPoint78 = NXOpen.Point3d(-13.311375938609951, -4.7497863169251584, 0.0)
    viewCenter78 = NXOpen.Point3d(13.311375938609752, 4.7497863169253689, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint78, viewCenter78)
    
    scaleAboutPoint79 = NXOpen.Point3d(-10.649100750887989, -3.7998290535401238, 0.0)
    viewCenter79 = NXOpen.Point3d(10.649100750887758, 3.7998290535402925, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint79, viewCenter79)
    
    scalar5 = workPart.Scalars.CreateScalar(0.76809486610248612, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    scalar6 = workPart.Scalars.CreateScalar(0.0054807066700426899, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    face5 = nXObject6
    point6 = workPart.Points.CreatePoint(face5, scalar5, scalar6, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    direction9 = workPart.Directions.CreateDirection(face5, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    xform5, nXObject7 = workPart.Xforms.CreateExtractXform(face1, NXOpen.SmartObject.UpdateOption.AfterParentBody, False)
    
    direction10 = workPart.Directions.CreateDirection(direction9, xform5, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    expression72 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    scaleAboutPoint80 = NXOpen.Point3d(9.1579073323976203, -7.8167911958540319, 0.0)
    viewCenter80 = NXOpen.Point3d(-9.1579073323978477, 7.8167911958542335, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint80, viewCenter80)
    
    scaleAboutPoint81 = NXOpen.Point3d(11.447384165497045, -9.770988994817575, 0.0)
    viewCenter81 = NXOpen.Point3d(-11.447384165497276, 9.7709889948177437, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(14.508801060523663, -12.213736243521973, 0.0)
    viewCenter82 = NXOpen.Point3d(-14.50880106052389, 12.213736243522183, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(18.136001325654604, -15.317063017815574, 0.0)
    viewCenter83 = NXOpen.Point3d(-18.136001325654835, 15.317063017815837, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint83, viewCenter83)
    
    scaleAboutPoint84 = NXOpen.Point3d(22.794733440600979, -19.27106055580224, 0.0)
    viewCenter84 = NXOpen.Point3d(-22.794733440601245, 19.271060555802407, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(34.496133883262509, -25.25818616537191, 0.0)
    viewCenter85 = NXOpen.Point3d(-34.496133883262743, 25.258186165372116, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint85, viewCenter85)
    
    scaleAboutPoint86 = NXOpen.Point3d(43.509954177617821, -31.767626118484706, 0.0)
    viewCenter86 = NXOpen.Point3d(-43.509954177618113, 31.767626118484962, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint86, viewCenter86)
    
    # ----------------------------------------------
    #   Menu: Snap View
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.SnapToClosestCannedOrientation()
    
    # ----------------------------------------------
    #   Menu: Fit
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.Fit()
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = -0.7932968388068864
    rotMatrix18.Xy = -0.60394237406329676
    rotMatrix18.Xz = -0.077030736396511312
    rotMatrix18.Yx = 0.08183497965292022
    rotMatrix18.Yy = -0.2311454428528969
    rotMatrix18.Yz = 0.96947141286040195
    rotMatrix18.Zx = -0.60331017034706591
    rotMatrix18.Zy = 0.76277479839014495
    rotMatrix18.Zz = 0.23279056101282719
    translation18 = NXOpen.Point3d(60.553623240789449, -17.166736445836939, 27.093669084439721)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation18, 1.0274956614727939)
    
    scaleAboutPoint87 = NXOpen.Point3d(58.58195863041815, -53.303144775809116, 0.0)
    viewCenter87 = NXOpen.Point3d(-58.58195863041815, 53.303144775809116, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint87, viewCenter87)
    
    scaleAboutPoint88 = NXOpen.Point3d(46.865566904334521, -42.642515820647297, 0.0)
    viewCenter88 = NXOpen.Point3d(-46.865566904334521, 42.642515820647297, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint88, viewCenter88)
    
    scaleAboutPoint89 = NXOpen.Point3d(37.657255516977365, -34.443616643537297, 0.0)
    viewCenter89 = NXOpen.Point3d(-37.657255516977365, 34.443616643537297, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint89, viewCenter89)
    
    scaleAboutPoint90 = NXOpen.Point3d(32.103428335698865, -29.400675642138996, 0.0)
    viewCenter90 = NXOpen.Point3d(-32.103428335698865, 29.400675642138996, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint90, viewCenter90)
    
    scaleAboutPoint91 = NXOpen.Point3d(25.893689220251566, -23.415067237864896, 0.0)
    viewCenter91 = NXOpen.Point3d(-25.893689220251566, 23.415067237864896, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint91, viewCenter91)
    
    scaleAboutPoint92 = NXOpen.Point3d(20.799329996878253, -18.394539307583994, 0.0)
    viewCenter92 = NXOpen.Point3d(-20.799329996878253, 18.394539307583994, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint92, viewCenter92)
    
    scaleAboutPoint93 = NXOpen.Point3d(16.909475583668971, -14.58062565298402, 0.0)
    viewCenter93 = NXOpen.Point3d(-16.909475583668971, 14.58062565298402, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint93, viewCenter93)
    
    scaleAboutPoint94 = NXOpen.Point3d(13.527580466935181, -11.664500522387216, 0.0)
    viewCenter94 = NXOpen.Point3d(-13.527580466935172, 11.664500522387216, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(10.822064373548155, -9.2451967103365433, 0.0)
    viewCenter95 = NXOpen.Point3d(-10.822064373548127, 9.2451967103365433, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint95, viewCenter95)
    
    scaleAboutPoint96 = NXOpen.Point3d(-11.353447175123536, -5.3915913525700789, 0.0)
    viewCenter96 = NXOpen.Point3d(11.35344717512357, 5.3915913525700789, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(-14.191808968904425, -6.7394891907125976, 0.0)
    viewCenter97 = NXOpen.Point3d(14.191808968904455, 6.7394891907125976, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint97, viewCenter97)
    
    scaleAboutPoint98 = NXOpen.Point3d(-17.739761211130538, -8.4243614883907476, 0.0)
    viewCenter98 = NXOpen.Point3d(17.739761211130563, 8.4243614883907476, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint98, viewCenter98)
    
    scaleAboutPoint99 = NXOpen.Point3d(-22.107198617371573, -10.732960550113235, 0.0)
    viewCenter99 = NXOpen.Point3d(22.107198617371619, 10.732960550113235, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint99, viewCenter99)
    
    scaleAboutPoint100 = NXOpen.Point3d(-38.012568614984346, -13.669336549672543, 0.0)
    viewCenter100 = NXOpen.Point3d(38.012568614984389, 13.669336549672543, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint100, viewCenter100)
    
    scaleAboutPoint101 = NXOpen.Point3d(-50.152542664886397, -17.403090514629294, 0.0)
    viewCenter101 = NXOpen.Point3d(50.152542664886447, 17.403090514629294, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint101, viewCenter101)
    
    scaleAboutPoint102 = NXOpen.Point3d(-65.591193416879577, -22.017546332902363, 0.0)
    viewCenter102 = NXOpen.Point3d(65.591193416879591, 22.017546332902363, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint102, viewCenter102)
    
    scaleAboutPoint103 = NXOpen.Point3d(-86.438645595862667, -27.521932916127955, 0.0)
    viewCenter103 = NXOpen.Point3d(86.438645595862695, 27.521932916127955, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint103, viewCenter103)
    
    scaleAboutPoint104 = NXOpen.Point3d(-112.58036181634638, -34.814421128934264, 0.0)
    viewCenter104 = NXOpen.Point3d(112.58036181634641, 34.814421128934264, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint104, viewCenter104)
    
    scaleAboutPoint105 = NXOpen.Point3d(-140.72545227043292, -43.518026411167824, 0.0)
    viewCenter105 = NXOpen.Point3d(140.72545227043295, 43.518026411167824, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint105, viewCenter105)
    
    scaleAboutPoint106 = NXOpen.Point3d(-175.90681533804113, -54.397533013959766, 0.0)
    viewCenter106 = NXOpen.Point3d(175.90681533804118, 54.397533013959766, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(-219.88351917255136, -67.996916267449706, 0.0)
    viewCenter107 = NXOpen.Point3d(219.8835191725515, 67.996916267449706, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint107, viewCenter107)
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = -0.75299279505733685
    rotMatrix19.Xy = 0.65657736313657888
    rotMatrix19.Xz = 0.043680851735684763
    rotMatrix19.Yx = -0.17360025992965833
    rotMatrix19.Yy = -0.26224501012066553
    rotMatrix19.Yz = 0.94925787034881492
    rotMatrix19.Zx = 0.63471631485577384
    rotMatrix19.Zy = 0.70720132980886508
    rotMatrix19.Zz = 0.31145060406503922
    translation19 = NXOpen.Point3d(-250.2576770567745, -30.42663480445902, -54.869821983221314)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 0.52607777867407091)
    
    scaleAboutPoint108 = NXOpen.Point3d(-289.43953633074864, -108.63412658113248, 0.0)
    viewCenter108 = NXOpen.Point3d(289.43953633074875, 108.63412658113248, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint108, viewCenter108)
    
    scaleAboutPoint109 = NXOpen.Point3d(-231.55162906459893, -86.102604030971762, 0.0)
    viewCenter109 = NXOpen.Point3d(231.55162906459904, 86.102604030971762, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(-185.24130325167911, -68.882083224777404, 0.0)
    viewCenter110 = NXOpen.Point3d(185.2413032516792, 68.882083224777404, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint110, viewCenter110)
    
    scaleAboutPoint111 = NXOpen.Point3d(-162.35571391858724, -49.698101167783385, 0.0)
    viewCenter111 = NXOpen.Point3d(162.35571391858733, 49.698101167783385, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint111, viewCenter111)
    
    scaleAboutPoint112 = NXOpen.Point3d(-129.88457113486979, -39.758480934226711, 0.0)
    viewCenter112 = NXOpen.Point3d(129.88457113486987, 39.758480934226711, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(-103.90765690789583, -31.806784747381368, 0.0)
    viewCenter113 = NXOpen.Point3d(103.9076569078959, 31.806784747381368, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint113, viewCenter113)
    
    scaleAboutPoint114 = NXOpen.Point3d(-91.036621214784518, -23.204120686172491, 0.0)
    viewCenter114 = NXOpen.Point3d(91.036621214784603, 23.204120686172491, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint114, viewCenter114)
    
    expression73 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    # ----------------------------------------------
    #   Menu: Fit
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.Fit()
    
    scaleAboutPoint115 = NXOpen.Point3d(-113.74755209266728, -68.642763342363864, 0.0)
    viewCenter115 = NXOpen.Point3d(113.74755209266728, 68.642763342363864, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(-90.998041674133816, -54.914210673891098, 0.0)
    viewCenter116 = NXOpen.Point3d(90.998041674133816, 54.914210673891098, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint116, viewCenter116)
    
    scaleAboutPoint117 = NXOpen.Point3d(-73.837350838542832, -40.963032827010757, 0.0)
    viewCenter117 = NXOpen.Point3d(73.837350838542804, 40.963032827010757, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint117, viewCenter117)
    
    scaleAboutPoint118 = NXOpen.Point3d(-59.069880670834237, -32.532959404640444, 0.0)
    viewCenter118 = NXOpen.Point3d(59.069880670834223, 32.532959404640444, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint118, viewCenter118)
    
    scaleAboutPoint119 = NXOpen.Point3d(-47.255904536667423, -25.55143380977599, 0.0)
    viewCenter119 = NXOpen.Point3d(47.255904536667359, 25.55143380977599, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(-36.96884029280595, -19.301306134373501, 0.0)
    viewCenter120 = NXOpen.Point3d(36.968840292805901, 19.301306134373501, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint120, viewCenter120)
    
    nErrs22 = theSession.UpdateManager.AddToDeleteList(direction10)
    
    scalar7 = workPart.Scalars.CreateScalar(0.79528147213764455, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    scalar8 = workPart.Scalars.CreateScalar(0.32060040538861145, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    face6 = nXObject7
    point7 = workPart.Points.CreatePoint(face6, scalar7, scalar8, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    direction11 = workPart.Directions.CreateDirection(face6, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    xform6, nXObject8 = workPart.Xforms.CreateExtractXform(face1, NXOpen.SmartObject.UpdateOption.AfterParentBody, False)
    
    direction12 = workPart.Directions.CreateDirection(direction11, xform6, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    nErrs23 = theSession.UpdateManager.DoUpdate(markId44)
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    expression74 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression75 = workPart.Expressions.CreateSystemExpressionWithUnits("p12_x=0.00000000000", unit3)
    
    expression76 = workPart.Expressions.CreateSystemExpressionWithUnits("p13_y=0.00000000000", unit3)
    
    expression77 = workPart.Expressions.CreateSystemExpressionWithUnits("p14_z=0.00000000000", unit3)
    
    expression78 = workPart.Expressions.CreateSystemExpressionWithUnits("p15_xdelta=0.00000000000", unit3)
    
    expression79 = workPart.Expressions.CreateSystemExpressionWithUnits("p16_ydelta=0.00000000000", unit3)
    
    expression80 = workPart.Expressions.CreateSystemExpressionWithUnits("p17_zdelta=0.00000000000", unit3)
    
    expression81 = workPart.Expressions.CreateSystemExpressionWithUnits("p18_radius=0.00000000000", unit3)
    
    expression82 = workPart.Expressions.CreateSystemExpressionWithUnits("p19_angle=0.00000000000", unit4)
    
    expression83 = workPart.Expressions.CreateSystemExpressionWithUnits("p20_zdelta=0.00000000000", unit3)
    
    expression84 = workPart.Expressions.CreateSystemExpressionWithUnits("p21_radius=0.00000000000", unit3)
    
    expression85 = workPart.Expressions.CreateSystemExpressionWithUnits("p22_angle1=0.00000000000", unit4)
    
    expression86 = workPart.Expressions.CreateSystemExpressionWithUnits("p23_angle2=0.00000000000", unit4)
    
    expression87 = workPart.Expressions.CreateSystemExpressionWithUnits("p24_distance=0", unit3)
    
    expression88 = workPart.Expressions.CreateSystemExpressionWithUnits("p25_arclen=0", unit3)
    
    expression89 = workPart.Expressions.CreateSystemExpressionWithUnits("p26_percent=0", NXOpen.Unit.Null)
    
    theSession.SetUndoMarkName(markId45, "Point Dialog")
    
    expression90 = workPart.Expressions.CreateSystemExpressionWithUnits("p27_x=0.00000000000", unit3)
    
    scalar9 = workPart.Scalars.CreateScalarExpression(expression90, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    expression91 = workPart.Expressions.CreateSystemExpressionWithUnits("p28_y=0.00000000000", unit3)
    
    scalar10 = workPart.Scalars.CreateScalarExpression(expression91, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    expression92 = workPart.Expressions.CreateSystemExpressionWithUnits("p29_z=0.00000000000", unit3)
    
    scalar11 = workPart.Scalars.CreateScalarExpression(expression92, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    point8 = workPart.Points.CreatePoint(scalar9, scalar10, scalar11, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    expression75.SetFormula("0")
    
    expression76.SetFormula("0")
    
    expression77.SetFormula("0")
    
    expression75.SetFormula("0.00000000000")
    
    expression76.SetFormula("0.00000000000")
    
    expression77.SetFormula("0.00000000000")
    
    expression75.SetFormula("0")
    
    expression76.SetFormula("0")
    
    expression77.SetFormula("0")
    
    expression75.SetFormula("0.00000000000")
    
    expression76.SetFormula("0.00000000000")
    
    expression77.SetFormula("0.00000000000")
    
    expression89.SetFormula("100.00000000000")
    
    edge3 = extrude1.FindObject("EDGE * 130 * 140 {(-0.75,-50,-1.2990381056767)(1.5,-50,0)(-0.75,-50,1.2990381056767) EXTRUDE(2)}")
    point9 = workPart.Points.CreatePoint(edge3, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    edge4 = component12.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 130 * 140 {(-0.75,-50,-1.2990381056767)(1.5,-50,0)(-0.75,-50,1.2990381056767) EXTRUDE(2)}")
    xform7, nXObject9 = workPart.Xforms.CreateExtractXform(edge4, NXOpen.SmartObject.UpdateOption.AfterParentBody, False)
    
    point10 = workPart.Points.CreatePoint(point9, xform7, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    workPart.Points.DeletePoint(point8)
    
    partLoadStatus8 = part4.LoadFeatureDataForSelection()
    
    partLoadStatus8.Dispose()
    edge5 = nXObject9
    point11 = workPart.Points.CreatePoint(edge5, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    xform8, nXObject10 = workPart.Xforms.CreateExtractXform(edge4, NXOpen.SmartObject.UpdateOption.AfterParentBody, False)
    
    point12 = workPart.Points.CreatePoint(point11, xform8, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    expression75.SetFormula("202.320467711969")
    
    expression76.SetFormula("136.214906235001")
    
    expression77.SetFormula("4")
    
    expression75.SetFormula("202.32046771197")
    
    expression76.SetFormula("136.21490623500")
    
    expression77.SetFormula("4.00000000000")
    
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = -0.98796483902755805
    rotMatrix20.Xy = -0.12943362444112505
    rotMatrix20.Xz = -0.084690103963108387
    rotMatrix20.Yx = -0.056107192831333245
    rotMatrix20.Yy = -0.21035336504610552
    rotMatrix20.Yz = 0.97601405969707578
    rotMatrix20.Zx = -0.14414388560683364
    rotMatrix20.Zy = 0.96901929737121761
    rotMatrix20.Zz = 0.20055957111130424
    translation20 = NXOpen.Point3d(207.76774801985599, 27.986515223815374, 60.027135186181212)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation20, 4.3523069241272392)
    
    expression75.SetFormula("202.320467711969")
    
    expression76.SetFormula("136.214906235001")
    
    expression77.SetFormula("4")
    
    expression75.SetFormula("202.32046771197")
    
    expression76.SetFormula("136.21490623500")
    
    expression77.SetFormula("4.00000000000")
    
    expression75.SetFormula("202.320467711969")
    
    expression76.SetFormula("136.214906235001")
    
    expression77.SetFormula("4")
    
    expression75.SetFormula("202.32046771197")
    
    expression76.SetFormula("136.21490623500")
    
    expression77.SetFormula("4.00000000000")
    
    expression75.SetFormula("202.320467711969")
    
    expression76.SetFormula("136.214906235001")
    
    expression77.SetFormula("4")
    
    expression75.SetFormula("202.32046771197")
    
    expression76.SetFormula("136.21490623500")
    
    expression77.SetFormula("4.00000000000")
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Point")
    
    theSession.DeleteUndoMark(markId46, None)
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Point")
    
    nErrs24 = theSession.UpdateManager.AddToDeleteList(point12)
    
    expression93 = workPart.Expressions.CreateSystemExpressionWithUnits("p13_x=202.32046771197", unit3)
    
    scalar12 = workPart.Scalars.CreateScalarExpression(expression93, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    expression94 = workPart.Expressions.CreateSystemExpressionWithUnits("p14_y=136.21490623500", unit3)
    
    scalar13 = workPart.Scalars.CreateScalarExpression(expression94, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    expression95 = workPart.Expressions.CreateSystemExpressionWithUnits("p15_z=4.00000000000", unit3)
    
    scalar14 = workPart.Scalars.CreateScalarExpression(expression95, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    point13 = workPart.Points.CreatePoint(scalar12, scalar13, scalar14, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    expression76.SetFormula("136.214906235")
    
    expression77.SetFormula("4")
    
    expression76.SetFormula("136.21490623500")
    
    expression77.SetFormula("4.00000000000")
    
    nErrs25 = theSession.UpdateManager.AddToDeleteList(point10)
    
    theSession.DeleteUndoMark(markId47, None)
    
    theSession.SetUndoMarkName(markId45, "Point")
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression75)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression76)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression77)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression78)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression79)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression80)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression81)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression82)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression83)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression84)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression85)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression86)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression87)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression88)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression89)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Expressions.Delete(expression74)
    
    theSession.DeleteUndoMark(markId45, None)
    
    scalar15 = workPart.Scalars.CreateScalarExpression(expression93, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    scalar16 = workPart.Scalars.CreateScalarExpression(expression94, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    scalar17 = workPart.Scalars.CreateScalarExpression(expression95, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    point14 = workPart.Points.CreatePoint(scalar15, scalar16, scalar17, NXOpen.SmartObject.UpdateOption.AfterParentBody)
    
    workPart.Points.DeletePoint(point14)
    
    workPart.Points.DeletePoint(point13)
    
    rotMatrix21 = NXOpen.Matrix3x3()
    
    rotMatrix21.Xx = -0.84591165721399686
    rotMatrix21.Xy = -0.50926167115186749
    rotMatrix21.Xz = -0.15838566376119198
    rotMatrix21.Yx = -0.056107192831333245
    rotMatrix21.Yy = -0.21035336504610552
    rotMatrix21.Yz = 0.97601405969707578
    rotMatrix21.Zx = -0.53036350845628
    rotMatrix21.Zy = 0.834508245680881
    rotMatrix21.Zz = 0.14936712084176706
    translation21 = NXOpen.Point3d(239.82963841769873, 27.986515223815374, 154.29242193400765)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix21, translation21, 4.3523069241272392)
    
    scaleAboutPoint121 = NXOpen.Point3d(11.702366711391775, -7.6597309383655539, 0.0)
    viewCenter121 = NXOpen.Point3d(-11.702366711391846, 7.6597309383655539, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint121, viewCenter121)
    
    scaleAboutPoint122 = NXOpen.Point3d(14.627958389239724, -9.5746636729569445, 0.0)
    viewCenter122 = NXOpen.Point3d(-14.627958389239804, 9.5746636729569445, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint122, viewCenter122)
    
    scaleAboutPoint123 = NXOpen.Point3d(18.284947986549685, -11.968329591196181, 0.0)
    viewCenter123 = NXOpen.Point3d(-18.284947986549717, 11.968329591196181, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(22.856184983187134, -14.960411988995224, 0.0)
    viewCenter124 = NXOpen.Point3d(-22.856184983187134, 14.960411988995224, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint124, viewCenter124)
    
    scaleAboutPoint125 = NXOpen.Point3d(42.22457550465414, -29.238106764206911, 0.0)
    viewCenter125 = NXOpen.Point3d(-42.224575504654155, 29.238106764206911, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(38.0540638291505, -27.308688551340438, 0.0)
    viewCenter126 = NXOpen.Point3d(-38.054063829150486, 27.308688551340438, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint126, viewCenter126)
    
    scaleAboutPoint127 = NXOpen.Point3d(32.81791963300217, -23.6516989540305, 0.0)
    viewCenter127 = NXOpen.Point3d(-32.81791963300217, 23.6516989540305, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint127, viewCenter127)
    
    scaleAboutPoint128 = NXOpen.Point3d(26.938240254470077, -19.149327345913878, 0.0)
    viewCenter128 = NXOpen.Point3d(-26.938240254470102, 19.149327345913878, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint128, viewCenter128)
    
    scaleAboutPoint129 = NXOpen.Point3d(21.550592203576073, -15.319461876731099, 0.0)
    viewCenter129 = NXOpen.Point3d(-21.550592203576073, 15.319461876731099, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(21.179763959734565, -12.109669864463616, 0.0)
    viewCenter130 = NXOpen.Point3d(-21.179763959734565, 12.109669864463616, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint130, viewCenter130)
    
    scaleAboutPoint131 = NXOpen.Point3d(17.371783436089995, -9.6488293217253123, 0.0)
    viewCenter131 = NXOpen.Point3d(-17.371783436089995, 9.6488293217252092, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint131, viewCenter131)
    
    scaleAboutPoint132 = NXOpen.Point3d(14.177554051760781, -7.6879382015036963, 0.0)
    viewCenter132 = NXOpen.Point3d(-14.177554051760781, 7.6879382015036137, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint132, viewCenter132)
    
    scaleAboutPoint133 = NXOpen.Point3d(11.441644060213536, -6.1254503565017187, 0.0)
    viewCenter133 = NXOpen.Point3d(-11.441644060213536, 6.1254503565016529, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint133, viewCenter133)
    
    scaleAboutPoint134 = NXOpen.Point3d(9.1732354119318078, -4.8206796301574588, 0.0)
    viewCenter134 = NXOpen.Point3d(-9.1732354119318078, 4.8206796301574064, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint134, viewCenter134)
    
    scaleAboutPoint135 = NXOpen.Point3d(7.7529277357738513, -3.6175017389942061, 0.0)
    viewCenter135 = NXOpen.Point3d(-7.7529277357738513, 3.6175017389941218, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint135, viewCenter135)
    
    scaleAboutPoint136 = NXOpen.Point3d(9.6911596697173188, -4.521877173742733, 0.0)
    viewCenter136 = NXOpen.Point3d(-9.6911596697173188, 4.5218771737426806, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint136, viewCenter136)
    
    scaleAboutPoint137 = NXOpen.Point3d(12.860955728183441, -5.3784442154649383, 0.0)
    viewCenter137 = NXOpen.Point3d(-12.860955728183441, 5.3784442154648726, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint137, viewCenter137)
    
    scaleAboutPoint138 = NXOpen.Point3d(16.16957042785889, -6.6608047575781111, 0.0)
    viewCenter138 = NXOpen.Point3d(-16.16957042785889, 6.6608047575780285, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint138, viewCenter138)
    
    scaleAboutPoint139 = NXOpen.Point3d(20.250869604669294, -8.3260059469726411, 0.0)
    viewCenter139 = NXOpen.Point3d(-20.250869604669294, 8.3260059469725398, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint139, viewCenter139)
    
    scaleAboutPoint140 = NXOpen.Point3d(25.410853430450764, -10.310241009101642, 0.0)
    viewCenter140 = NXOpen.Point3d(-25.410853430450764, 10.310241009101514, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint140, viewCenter140)
    
    scaleAboutPoint141 = NXOpen.Point3d(32.006732849598876, -12.827009745993163, 0.0)
    viewCenter141 = NXOpen.Point3d(-32.006732849598876, 12.827009745993003, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint141, viewCenter141)
    
    scaleAboutPoint142 = NXOpen.Point3d(40.31237363891784, -15.805793999801871, 0.0)
    viewCenter142 = NXOpen.Point3d(-40.31237363891784, 15.805793999801871, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint142, viewCenter142)
    
    scaleAboutPoint143 = NXOpen.Point3d(51.720281447669059, -18.617401586305068, 0.0)
    viewCenter143 = NXOpen.Point3d(-51.720281447669059, 18.617401586305068, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint143, viewCenter143)
    
    scaleAboutPoint144 = NXOpen.Point3d(64.650351809586283, -23.271751982881327, 0.0)
    viewCenter144 = NXOpen.Point3d(-64.650351809586326, 23.271751982881327, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint144, viewCenter144)
    
    scaleAboutPoint145 = NXOpen.Point3d(80.812939761982889, -29.089689978601669, 0.0)
    viewCenter145 = NXOpen.Point3d(-80.812939761982932, 29.089689978601669, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint145, viewCenter145)
    
    scaleAboutPoint146 = NXOpen.Point3d(101.01617470247862, -36.362112473252083, 0.0)
    viewCenter146 = NXOpen.Point3d(-101.01617470247862, 36.362112473252083, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint146, viewCenter146)
    
    rotMatrix22 = NXOpen.Matrix3x3()
    
    rotMatrix22.Xx = -0.73761744768888182
    rotMatrix22.Xy = -0.65008482761815134
    rotMatrix22.Xz = -0.1825108702669905
    rotMatrix22.Yx = -0.056107192831333245
    rotMatrix22.Yy = -0.21035336504610552
    rotMatrix22.Yz = 0.97601405969707578
    rotMatrix22.Zx = -0.67288370746922133
    rotMatrix22.Zy = 0.73016517221410449
    rotMatrix22.Zz = 0.11868587745818028
    translation22 = NXOpen.Point3d(309.30034380350787, 4.2605426970788756, 195.45151798637377)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix22, translation22, 1.1409311463184117)
    
    # ----------------------------------------------
    #   Menu: Snap View
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.SnapToClosestCannedOrientation()
    
    componentPositioner8.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner8.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId44, None)
    
    workPart.Expressions.Delete(expression72)
    
    workPart.Expressions.Delete(expression71)
    
    workPart.Expressions.Delete(expression73)
    
    theSession.UndoToMark(markId43, None)
    
    theSession.DeleteUndoMark(markId43, None)
    
    theSession.DeleteUndoMark(markId42, None)
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete Constraint")
    
    objects11 = [NXOpen.TaggedObject.Null] * 1 
    objects11[0] = componentConstraint1
    nErrs26 = theSession.UpdateManager.AddObjectsToDeleteList(objects11)
    
    nErrs27 = theSession.UpdateManager.DoUpdate(markId48)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner9 = workPart.ComponentAssembly.Positioner
    
    componentPositioner9.ClearNetwork()
    
    componentPositioner9.PrimaryArrangement = arrangement2
    
    componentPositioner9.BeginAssemblyConstraints()
    
    allowInterpartPositioning9 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression96 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression97 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression98 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression99 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression100 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression101 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression102 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression103 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network9 = componentPositioner9.EstablishNetwork()
    
    componentNetwork9 = network9
    componentNetwork9.MoveObjectsState = True
    
    componentNetwork9.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork9.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId50, "Assembly Constraints Dialog")
    
    componentNetwork9.MoveObjectsState = True
    
    componentNetwork9.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    # ----------------------------------------------
    #   Menu: Snap View
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.SnapToClosestCannedOrientation()
    
    # ----------------------------------------------
    #   Menu: Fit
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.Fit()
    
    rotMatrix23 = NXOpen.Matrix3x3()
    
    rotMatrix23.Xx = -0.95368081330913312
    rotMatrix23.Xy = 0.28979575464240231
    rotMatrix23.Xz = 0.080692793465529739
    rotMatrix23.Yx = -0.039083502122690038
    rotMatrix23.Yy = -0.38533300800192499
    rotMatrix23.Yz = 0.92194953918639899
    rotMatrix23.Zx = 0.29827065928088825
    rotMatrix23.Zy = 0.87609182939656993
    rotMatrix23.Zz = 0.37881092945784356
    translation23 = NXOpen.Point3d(58.070945510844403, -6.6584940283628189, -35.76219759741042)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix23, translation23, 1.0274956614727939)
    
    scaleAboutPoint147 = NXOpen.Point3d(-41.329249934866411, 1.545018689153725, 0.0)
    viewCenter147 = NXOpen.Point3d(41.329249934866411, -1.545018689153725, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint147, viewCenter147)
    
    scaleAboutPoint148 = NXOpen.Point3d(-33.063399947893167, 1.2360149513229801, 0.0)
    viewCenter148 = NXOpen.Point3d(33.063399947893132, -1.2360149513229801, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint148, viewCenter148)
    
    scaleAboutPoint149 = NXOpen.Point3d(-28.922749860960746, 0.32960398701946131, 0.0)
    viewCenter149 = NXOpen.Point3d(28.922749860960717, -0.32960398701946131, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint149, viewCenter149)
    
    scaleAboutPoint150 = NXOpen.Point3d(-23.138199888768593, 0.26368318961556902, 0.0)
    viewCenter150 = NXOpen.Point3d(23.138199888768572, -0.26368318961556902, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint150, viewCenter150)
    
    scaleAboutPoint151 = NXOpen.Point3d(-18.510559911014855, 0.42189310338491043, 0.0)
    viewCenter151 = NXOpen.Point3d(18.510559911014855, -0.42189310338491043, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint151, viewCenter151)
    
    face7 = component2.FindObject("PROTO#.Features|EXTRUDE(2)|FACE 150 {(0,-1.5,-1.5) EXTRUDE(2)}")
    line6 = workPart.Lines.CreateFaceAxis(face7, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line6.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    objects12 = [NXOpen.TaggedObject.Null] * 1 
    objects12[0] = line6
    nErrs28 = theSession.UpdateManager.AddObjectsToDeleteList(objects12)
    
    scaleAboutPoint152 = NXOpen.Point3d(-51.260012061271894, -4.3876882752035131, 0.0)
    viewCenter152 = NXOpen.Point3d(51.260012061271922, 4.3876882752035131, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint152, viewCenter152)
    
    scaleAboutPoint153 = NXOpen.Point3d(-60.699870249510234, -8.9652284469302508, 0.0)
    viewCenter153 = NXOpen.Point3d(60.69987024951029, 8.9652284469302508, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint153, viewCenter153)
    
    scaleAboutPoint154 = NXOpen.Point3d(-75.479313027464386, -11.733901937893949, 0.0)
    viewCenter154 = NXOpen.Point3d(75.479313027464443, 11.733901937893949, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint154, viewCenter154)
    
    scaleAboutPoint155 = NXOpen.Point3d(-84.625823667255347, -21.259457162757524, 0.0)
    viewCenter155 = NXOpen.Point3d(84.625823667255432, 21.259457162757524, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint155, viewCenter155)
    
    scaleAboutPoint156 = NXOpen.Point3d(-105.16427210840764, -27.192328929108257, 0.0)
    viewCenter156 = NXOpen.Point3d(105.16427210840769, 27.192328929108257, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint156, viewCenter156)
    
    scaleAboutPoint157 = NXOpen.Point3d(-139.95294292585595, -38.625467228847178, 0.0)
    viewCenter157 = NXOpen.Point3d(139.95294292585598, 38.625467228847178, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint157, viewCenter157)
    
    scaleAboutPoint158 = NXOpen.Point3d(-174.94117865731997, -48.281834036058974, 0.0)
    viewCenter158 = NXOpen.Point3d(174.94117865731997, 48.281834036058974, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint158, viewCenter158)
    
    line7 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line7.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    scaleAboutPoint159 = NXOpen.Point3d(-244.82913342451525, -105.8176862623623, 0.0)
    viewCenter159 = NXOpen.Point3d(244.82913342451525, 105.8176862623623, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint159, viewCenter159)
    
    scaleAboutPoint160 = NXOpen.Point3d(-196.50706452675959, -84.654149009889835, 0.0)
    viewCenter160 = NXOpen.Point3d(196.50706452675959, 84.654149009889835, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint160, viewCenter160)
    
    scaleAboutPoint161 = NXOpen.Point3d(-157.46315473626669, -67.723319207911871, 0.0)
    viewCenter161 = NXOpen.Point3d(157.46315473626669, 67.723319207911871, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint161, viewCenter161)
    
    scaleAboutPoint162 = NXOpen.Point3d(-125.97052378901337, -54.178655366329494, 0.0)
    viewCenter162 = NXOpen.Point3d(125.97052378901331, 54.178655366329494, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint162, viewCenter162)
    
    scaleAboutPoint163 = NXOpen.Point3d(-91.382705401155107, -42.518914325514842, 0.0)
    viewCenter163 = NXOpen.Point3d(91.38270540115505, 42.518914325514842, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint163, viewCenter163)
    
    scaleAboutPoint164 = NXOpen.Point3d(-73.106164320924094, -34.015131460411872, 0.0)
    viewCenter164 = NXOpen.Point3d(73.106164320923995, 34.015131460411872, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint164, viewCenter164)
    
    scaleAboutPoint165 = NXOpen.Point3d(-58.48493145673929, -27.212105168329494, 0.0)
    viewCenter165 = NXOpen.Point3d(58.484931456739183, 27.212105168329494, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint165, viewCenter165)
    
    scaleAboutPoint166 = NXOpen.Point3d(-46.787945165391434, -21.769684134663592, 0.0)
    viewCenter166 = NXOpen.Point3d(46.787945165391335, 21.769684134663592, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint166, viewCenter166)
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint2 = componentPositioner9.CreateConstraint(True)
    
    componentConstraint2 = constraint2
    componentConstraint2.ConstraintAlignment = NXOpen.Positioning.Constraint.Alignment.InferAlign
    
    componentConstraint2.ConstraintType = NXOpen.Positioning.Constraint.Type.Touch
    
    constraintReference3 = componentConstraint2.CreateConstraintReference(component2, face7, False, False, False)
    
    helpPoint3 = NXOpen.Point3d(97.208933502347975, -34.179908218749986, -1.2953386698545355)
    constraintReference3.HelpPoint = helpPoint3
    
    constraintReference4 = componentConstraint2.CreateConstraintReference(component12, face1, False, False, False)
    
    helpPoint4 = NXOpen.Point3d(205.89168392523877, 137.68251536580843, 4.3100378020032384)
    constraintReference4.HelpPoint = helpPoint4
    
    constraintReference4.SetFixHint(True)
    
    componentConstraint2.SetAlignmentHint(NXOpen.Positioning.Constraint.Alignment.ContraAlign)
    
    objects13 = [NXOpen.TaggedObject.Null] * 1 
    objects13[0] = line7
    nErrs29 = theSession.UpdateManager.AddObjectsToDeleteList(objects13)
    
    componentNetwork9.Solve()
    
    scaleAboutPoint167 = NXOpen.Point3d(-12.656793101548669, -15.998186480357441, 0.0)
    viewCenter167 = NXOpen.Point3d(12.656793101548557, 15.998186480357441, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint167, viewCenter167)
    
    scaleAboutPoint168 = NXOpen.Point3d(-15.567855514904833, -19.913354479769875, 0.0)
    viewCenter168 = NXOpen.Point3d(15.567855514904743, 19.913354479769875, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint168, viewCenter168)
    
    scaleAboutPoint169 = NXOpen.Point3d(-18.932453014399833, -24.364326720481131, 0.0)
    viewCenter169 = NXOpen.Point3d(18.932453014399762, 24.364326720481131, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint169, viewCenter169)
    
    scaleAboutPoint170 = NXOpen.Point3d(-22.478991914729608, -29.400675642138964, 0.0)
    viewCenter170 = NXOpen.Point3d(22.478991914729523, 29.400675642138964, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint170, viewCenter170)
    
    scaleAboutPoint171 = NXOpen.Point3d(-19.364234237395351, -27.85153690314738, 0.0)
    viewCenter171 = NXOpen.Point3d(19.364234237395326, 27.85153690314738, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint171, viewCenter171)
    
    scaleAboutPoint172 = NXOpen.Point3d(-24.205292796744153, -34.814421128934221, 0.0)
    viewCenter172 = NXOpen.Point3d(24.205292796744121, 34.814421128934221, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint172, viewCenter172)
    
    scaleAboutPoint173 = NXOpen.Point3d(-30.25661599593019, -43.518026411167774, 0.0)
    viewCenter173 = NXOpen.Point3d(30.25661599593019, 43.518026411167774, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint173, viewCenter173)
    
    scaleAboutPoint174 = NXOpen.Point3d(-37.820769994912737, -54.7194119075332, 0.0)
    viewCenter174 = NXOpen.Point3d(37.820769994912737, 54.7194119075332, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint174, viewCenter174)
    
    line8 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line8.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    scaleAboutPoint175 = NXOpen.Point3d(-92.339007593962521, -84.090860946135862, 0.0)
    viewCenter175 = NXOpen.Point3d(92.339007593962521, 84.090860946135862, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint175, viewCenter175)
    
    scaleAboutPoint176 = NXOpen.Point3d(-73.871206075169965, -67.272688756908664, 0.0)
    viewCenter176 = NXOpen.Point3d(73.871206075169994, 67.272688756908664, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint176, viewCenter176)
    
    scaleAboutPoint177 = NXOpen.Point3d(-59.096964860135998, -53.818151005526943, 0.0)
    viewCenter177 = NXOpen.Point3d(59.096964860135998, 53.818151005526943, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint177, viewCenter177)
    
    scaleAboutPoint178 = NXOpen.Point3d(-47.277571888108795, -43.054520804421543, 0.0)
    viewCenter178 = NXOpen.Point3d(47.277571888108795, 43.054520804421543, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint178, viewCenter178)
    
    scaleAboutPoint179 = NXOpen.Point3d(-33.866809666253104, -33.125200695459178, 0.0)
    viewCenter179 = NXOpen.Point3d(33.866809666253076, 33.125200695459178, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint179, viewCenter179)
    
    scaleAboutPoint180 = NXOpen.Point3d(-27.093447733002481, -26.500160556367355, 0.0)
    viewCenter180 = NXOpen.Point3d(27.093447733002471, 26.500160556367355, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint180, viewCenter180)
    
    scaleAboutPoint181 = NXOpen.Point3d(-21.674758186401991, -21.200128445093881, 0.0)
    viewCenter181 = NXOpen.Point3d(21.674758186402009, 21.200128445093881, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint181, viewCenter181)
    
    scaleAboutPoint182 = NXOpen.Point3d(-17.339806549121594, -16.960102756075106, 0.0)
    viewCenter182 = NXOpen.Point3d(17.339806549121594, 16.960102756075106, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint182, viewCenter182)
    
    scaleAboutPoint183 = NXOpen.Point3d(-13.804342342755678, -13.433076411776913, 0.0)
    viewCenter183 = NXOpen.Point3d(13.804342342755678, 13.433076411776913, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint183, viewCenter183)
    
    objects14 = [NXOpen.TaggedObject.Null] * 1 
    objects14[0] = line8
    nErrs30 = theSession.UpdateManager.AddObjectsToDeleteList(objects14)
    
    scaleAboutPoint184 = NXOpen.Point3d(7.0473023989422581, -3.5641529373960763, 0.0)
    viewCenter184 = NXOpen.Point3d(-7.0473023989422758, 3.5641529373960763, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint184, viewCenter184)
    
    scaleAboutPoint185 = NXOpen.Point3d(5.6378419191538152, -2.8513223499168614, 0.0)
    viewCenter185 = NXOpen.Point3d(-5.6378419191538152, 2.8513223499168614, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint185, viewCenter185)
    
    scaleAboutPoint186 = NXOpen.Point3d(4.5448350183523472, -2.281057879933488, 0.0)
    viewCenter186 = NXOpen.Point3d(-4.5448350183523472, 2.281057879933488, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint186, viewCenter186)
    
    scaleAboutPoint187 = NXOpen.Point3d(3.6358680146818743, -1.8248463039467908, 0.0)
    viewCenter187 = NXOpen.Point3d(-3.6358680146818854, 1.8248463039467908, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint187, viewCenter187)
    
    scaleAboutPoint188 = NXOpen.Point3d(4.5448350183523569, -2.2810578799334889, 0.0)
    viewCenter188 = NXOpen.Point3d(-4.5448350183523427, 2.2810578799334889, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint188, viewCenter188)
    
    scaleAboutPoint189 = NXOpen.Point3d(5.7242456267270434, -2.851322349916861, 0.0)
    viewCenter189 = NXOpen.Point3d(-5.7242456267270576, 2.851322349916861, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint189, viewCenter189)
    
    scaleAboutPoint190 = NXOpen.Point3d(7.1553070334088149, -3.5641529373960767, 0.0)
    viewCenter190 = NXOpen.Point3d(-7.1553070334088149, 3.5641529373960767, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint190, viewCenter190)
    
    scaleAboutPoint191 = NXOpen.Point3d(8.9441337917610078, -4.4551911717450956, 0.0)
    viewCenter191 = NXOpen.Point3d(-8.9441337917610291, 4.4551911717450956, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint191, viewCenter191)
    
    scaleAboutPoint192 = NXOpen.Point3d(11.770817584440218, -4.9783386199424404, 0.0)
    viewCenter192 = NXOpen.Point3d(-11.770817584440218, 4.9783386199424404, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint192, viewCenter192)
    
    scaleAboutPoint193 = NXOpen.Point3d(9.5516598606353575, -3.8476651028707813, 0.0)
    viewCenter193 = NXOpen.Point3d(-9.5516598606353575, 3.8476651028707813, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint193, viewCenter193)
    
    scaleAboutPoint194 = NXOpen.Point3d(7.9113394746746533, -2.8621228133635506, 0.0)
    viewCenter194 = NXOpen.Point3d(-7.9113394746746533, 2.8621228133635506, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint194, viewCenter194)
    
    scaleAboutPoint195 = NXOpen.Point3d(6.5450808486728178, -2.073688981757738, 0.0)
    viewCenter195 = NXOpen.Point3d(-6.5450808486728178, 2.073688981757738, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint195, viewCenter195)
    
    scaleAboutPoint196 = NXOpen.Point3d(5.8927328564948755, -1.0714059739081607, 0.0)
    viewCenter196 = NXOpen.Point3d(-5.8927328564948613, 1.0714059739081607, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint196, viewCenter196)
    
    scaleAboutPoint197 = NXOpen.Point3d(4.9906781494302548, -0.6359312877390243, 0.0)
    viewCenter197 = NXOpen.Point3d(-4.9906781494302663, 0.6359312877390243, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint197, viewCenter197)
    
    scaleAboutPoint198 = NXOpen.Point3d(3.992542519544203, -0.4866256810524876, 0.0)
    viewCenter198 = NXOpen.Point3d(-3.9925425195442172, 0.4866256810524876, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint198, viewCenter198)
    
    scaleAboutPoint199 = NXOpen.Point3d(3.194034015635371, -0.38930054484199039, 0.0)
    viewCenter199 = NXOpen.Point3d(-3.194034015635371, 0.38930054484199039, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint199, viewCenter199)
    
    scaleAboutPoint200 = NXOpen.Point3d(2.5552272125082909, -0.31144043587359244, 0.0)
    viewCenter200 = NXOpen.Point3d(-2.5552272125083046, 0.31144043587359244, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint200, viewCenter200)
    
    scaleAboutPoint201 = NXOpen.Point3d(2.0441817700066411, -0.24915234869887429, 0.0)
    viewCenter201 = NXOpen.Point3d(-2.0441817700066411, 0.24915234869887429, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint201, viewCenter201)
    
    scaleAboutPoint202 = NXOpen.Point3d(1.6353454160053156, -0.19932187895908782, 0.0)
    viewCenter202 = NXOpen.Point3d(-1.6353454160053156, 0.19932187895911171, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint202, viewCenter202)
    
    scaleAboutPoint203 = NXOpen.Point3d(2.04418177000665, -0.24915234869887451, 0.0)
    viewCenter203 = NXOpen.Point3d(-2.0441817700066354, 0.24915234869887451, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint203, viewCenter203)
    
    scaleAboutPoint204 = NXOpen.Point3d(2.5552272125082993, -0.33975320277118859, 0.0)
    viewCenter204 = NXOpen.Point3d(-2.5552272125082993, 0.33975320277118859, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint204, viewCenter204)
    
    scaleAboutPoint205 = NXOpen.Point3d(3.1940340156353799, -0.42469150346398554, 0.0)
    viewCenter205 = NXOpen.Point3d(-3.1940340156353666, 0.42469150346398554, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint205, viewCenter205)
    
    scaleAboutPoint206 = NXOpen.Point3d(3.9925425195442119, -0.53086437932998143, 0.0)
    viewCenter206 = NXOpen.Point3d(-3.9925425195442119, 0.53086437932998143, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint206, viewCenter206)
    
    scaleAboutPoint207 = NXOpen.Point3d(4.9906781494302619, -0.69122966058592872, 0.0)
    viewCenter207 = NXOpen.Point3d(-4.9906781494302761, 0.69122966058592872, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint207, viewCenter207)
    
    scaleAboutPoint208 = NXOpen.Point3d(6.2383476867878374, -1.0714059739081627, 0.0)
    viewCenter208 = NXOpen.Point3d(-6.2383476867878374, 1.0714059739081627, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint208, viewCenter208)
    
    scaleAboutPoint209 = NXOpen.Point3d(7.7979346084847965, -1.3824593211718468, 0.0)
    viewCenter209 = NXOpen.Point3d(-7.7979346084847965, 1.3824593211718468, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint209, viewCenter209)
    
    scaleAboutPoint210 = NXOpen.Point3d(9.7474182606060022, -1.9440834203978825, 0.0)
    viewCenter210 = NXOpen.Point3d(-9.7474182606059845, 1.9440834203978825, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint210, viewCenter210)
    
    scaleAboutPoint211 = NXOpen.Point3d(12.184272825757494, -2.4976071720388937, 0.0)
    viewCenter211 = NXOpen.Point3d(-12.184272825757494, 2.4976071720388937, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint211, viewCenter211)
    
    scaleAboutPoint212 = NXOpen.Point3d(15.230341032196863, -3.2907662064026932, 0.0)
    viewCenter212 = NXOpen.Point3d(-15.230341032196877, 3.2907662064026932, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint212, viewCenter212)
    
    scaleAboutPoint213 = NXOpen.Point3d(20.620025427939659, -3.4806181029258609, 0.0)
    viewCenter213 = NXOpen.Point3d(-20.620025427939659, 3.4806181029258609, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint213, viewCenter213)
    
    scaleAboutPoint214 = NXOpen.Point3d(17.930456893860573, -0.92816482744685924, 0.0)
    viewCenter214 = NXOpen.Point3d(-17.930456893860573, 0.92816482744685924, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint214, viewCenter214)
    
    scaleAboutPoint215 = NXOpen.Point3d(14.546874204713239, -0.60752606887431582, 0.0)
    viewCenter215 = NXOpen.Point3d(-14.546874204713239, 0.60752606887431582, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint215, viewCenter215)
    
    scaleAboutPoint216 = NXOpen.Point3d(11.691501681003857, -0.48602085509945275, 0.0)
    viewCenter216 = NXOpen.Point3d(-11.691501681003857, 0.48602085509945275, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint216, viewCenter216)
    
    scaleAboutPoint217 = NXOpen.Point3d(9.3532013448030789, -0.38881668407956227, 0.0)
    viewCenter217 = NXOpen.Point3d(-9.3532013448030931, 0.38881668407956227, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint217, viewCenter217)
    
    scaleAboutPoint218 = NXOpen.Point3d(7.4825610758424705, -0.31105334726364986, 0.0)
    viewCenter218 = NXOpen.Point3d(-7.4825610758424705, 0.31105334726364986, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint218, viewCenter218)
    
    scaleAboutPoint219 = NXOpen.Point3d(5.986048860673975, -0.24884267781091982, 0.0)
    viewCenter219 = NXOpen.Point3d(-5.986048860673975, 0.24884267781091982, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint219, viewCenter219)
    
    scaleAboutPoint220 = NXOpen.Point3d(5.1206293256204249, -0.30967088794248443, 0.0)
    viewCenter220 = NXOpen.Point3d(-5.1206293256204098, 0.30967088794248443, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint220, viewCenter220)
    
    scaleAboutPoint221 = NXOpen.Point3d(4.0965034604963337, -0.24773671035398753, 0.0)
    viewCenter221 = NXOpen.Point3d(-4.0965034604963337, 0.24773671035398753, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint221, viewCenter221)
    
    scaleAboutPoint222 = NXOpen.Point3d(3.2772027683970615, -0.19818936828319011, 0.0)
    viewCenter222 = NXOpen.Point3d(-3.2772027683970752, 0.19818936828319011, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint222, viewCenter222)
    
    scaleAboutPoint223 = NXOpen.Point3d(2.6217622147176582, -0.1585514946265523, 0.0)
    viewCenter223 = NXOpen.Point3d(-2.6217622147176582, 0.1585514946265523, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint223, viewCenter223)
    
    scaleAboutPoint224 = NXOpen.Point3d(2.0974097717741222, -0.12684119570122998, 0.0)
    viewCenter224 = NXOpen.Point3d(-2.0974097717741356, 0.12684119570125388, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint224, viewCenter224)
    
    scaleAboutPoint225 = NXOpen.Point3d(1.6779278174192982, -0.10147295656098416, 0.0)
    viewCenter225 = NXOpen.Point3d(-1.6779278174193126, 0.10147295656100329, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint225, viewCenter225)
    
    scaleAboutPoint226 = NXOpen.Point3d(1.284357707329161, -0.23773664108575343, 0.0)
    viewCenter226 = NXOpen.Point3d(-1.284357707329161, 0.23773664108576875, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint226, viewCenter226)
    
    scaleAboutPoint227 = NXOpen.Point3d(1.0274861658633321, -0.19018931286860338, 0.0)
    viewCenter227 = NXOpen.Point3d(-1.0274861658633321, 0.19018931286861562, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint227, viewCenter227)
    
    scaleAboutPoint228 = NXOpen.Point3d(0.82198893269066919, -0.15215145029488333, 0.0)
    viewCenter228 = NXOpen.Point3d(-0.82198893269066919, 0.15215145029489313, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint228, viewCenter228)
    
    scaleAboutPoint229 = NXOpen.Point3d(0.65759114615253367, -0.12172116023590243, 0.0)
    viewCenter229 = NXOpen.Point3d(-0.65759114615253367, 0.1217211602359181, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint229, viewCenter229)
    
    scaleAboutPoint230 = NXOpen.Point3d(0.52607291692202351, -0.097376928188721318, 0.0)
    viewCenter230 = NXOpen.Point3d(-0.52607291692202351, 0.097376928188733849, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint230, viewCenter230)
    
    scaleAboutPoint231 = NXOpen.Point3d(0.42085833353761543, -0.077901542550973923, 0.0)
    viewCenter231 = NXOpen.Point3d(-0.42085833353761543, 0.077901542550988967, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint231, viewCenter231)
    
    scaleAboutPoint232 = NXOpen.Point3d(0.32300639594309261, -0.068401354434999742, 0.0)
    viewCenter232 = NXOpen.Point3d(-0.32300639594309261, 0.068401354435015771, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint232, viewCenter232)
    
    scaleAboutPoint233 = NXOpen.Point3d(0.39615784443608498, -0.087401730666947453, 0.0)
    viewCenter233 = NXOpen.Point3d(-0.39615784443608498, 0.087401730666962496, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint233, viewCenter233)
    
    scaleAboutPoint234 = NXOpen.Point3d(0.48332207040013581, -0.11162721036267806, 0.0)
    viewCenter234 = NXOpen.Point3d(-0.48332207040013581, 0.11162721036269058, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint234, viewCenter234)
    
    scaleAboutPoint235 = NXOpen.Point3d(0.55368283863406031, -0.18406614474697253, 0.0)
    viewCenter235 = NXOpen.Point3d(-0.55368283863406031, 0.18406614474698821, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint235, viewCenter235)
    
    scaleAboutPoint236 = NXOpen.Point3d(0.6735484933785636, -0.25605975781333373, 0.0)
    viewCenter236 = NXOpen.Point3d(-0.6735484933785636, 0.25605975781334356, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint236, viewCenter236)
    
    scaleAboutPoint237 = NXOpen.Point3d(0.82801932553769853, -0.33399098845217695, 0.0)
    viewCenter237 = NXOpen.Point3d(-0.82801932553769853, 0.33399098845218922, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint237, viewCenter237)
    
    scaleAboutPoint238 = NXOpen.Point3d(1.023427247600869, -0.42908564488647705, 0.0)
    viewCenter238 = NXOpen.Point3d(-1.023427247600869, 0.42908564488649237, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint238, viewCenter238)
    
    scaleAboutPoint239 = NXOpen.Point3d(1.2647879228495162, -0.54360512443387599, 0.0)
    viewCenter239 = NXOpen.Point3d(-1.2647879228495162, 0.54360512443389508, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint239, viewCenter239)
    
    scaleAboutPoint240 = NXOpen.Point3d(1.5628647327474383, -0.67950640554234421, 0.0)
    viewCenter240 = NXOpen.Point3d(-1.5628647327474234, 0.67950640554236819, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint240, viewCenter240)
    
    scaleAboutPoint241 = NXOpen.Point3d(1.1155230157653739, -0.92865875424121813, 0.0)
    viewCenter241 = NXOpen.Point3d(-1.1155230157653739, 0.92865875424121813, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint241, viewCenter241)
    
    scaleAboutPoint242 = NXOpen.Point3d(1.3802473862579183, -1.1891362096991376, 0.0)
    viewCenter242 = NXOpen.Point3d(-1.3802473862579183, 1.1891362096991376, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint242, viewCenter242)
    
    scaleAboutPoint243 = NXOpen.Point3d(1.7076137535114015, -1.4864202621239229, 0.0)
    viewCenter243 = NXOpen.Point3d(-1.7076137535114015, 1.4864202621239229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint243, viewCenter243)
    
    scaleAboutPoint244 = NXOpen.Point3d(2.1345171918892509, -1.8580253276549026, 0.0)
    viewCenter244 = NXOpen.Point3d(-2.1345171918892509, 1.8580253276549026, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint244, viewCenter244)
    
    scaleAboutPoint245 = NXOpen.Point3d(2.6681464898615639, -2.3225316595686283, 0.0)
    viewCenter245 = NXOpen.Point3d(-2.6681464898615639, 2.3225316595686283, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint245, viewCenter245)
    
    scaleAboutPoint246 = NXOpen.Point3d(3.1623756971804893, -2.8686030914314711, 0.0)
    viewCenter246 = NXOpen.Point3d(-3.1623756971804751, 2.8686030914314711, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint246, viewCenter246)
    
    scaleAboutPoint247 = NXOpen.Point3d(3.8665659139023578, -3.5857538642893378, 0.0)
    viewCenter247 = NXOpen.Point3d(-3.8665659139023578, 3.5857538642893378, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint247, viewCenter247)
    
    scaleAboutPoint248 = NXOpen.Point3d(4.8332073923779468, -4.4821923303616718, 0.0)
    viewCenter248 = NXOpen.Point3d(-4.8332073923779468, 4.4821923303616718, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint248, viewCenter248)
    
    scaleAboutPoint249 = NXOpen.Point3d(6.0415092404724211, -5.6027404129520892, 0.0)
    viewCenter249 = NXOpen.Point3d(-6.0415092404724433, 5.6027404129520892, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint249, viewCenter249)
    
    scaleAboutPoint250 = NXOpen.Point3d(7.5518865505905488, -7.003425516190112, 0.0)
    viewCenter250 = NXOpen.Point3d(-7.5518865505905346, 7.003425516190112, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint250, viewCenter250)
    
    scaleAboutPoint251 = NXOpen.Point3d(9.4398581882381762, -8.7542818952376393, 0.0)
    viewCenter251 = NXOpen.Point3d(-9.4398581882381762, 8.7542818952376393, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint251, viewCenter251)
    
    scaleAboutPoint252 = NXOpen.Point3d(9.0311492443340118, -10.811010774239179, 0.0)
    viewCenter252 = NXOpen.Point3d(-9.0311492443339887, 10.811010774239179, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint252, viewCenter252)
    
    scaleAboutPoint253 = NXOpen.Point3d(11.288936555417511, -13.513763467798968, 0.0)
    viewCenter253 = NXOpen.Point3d(-11.288936555417482, 13.513763467798968, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint253, viewCenter253)
    
    scaleAboutPoint254 = NXOpen.Point3d(14.111170694271939, -16.892204334748712, 0.0)
    viewCenter254 = NXOpen.Point3d(-14.111170694271854, 16.892204334748712, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint254, viewCenter254)
    
    scaleAboutPoint255 = NXOpen.Point3d(17.638963367839903, -21.11525541843589, 0.0)
    viewCenter255 = NXOpen.Point3d(-17.638963367839818, 21.11525541843589, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint255, viewCenter255)
    
    scaleAboutPoint256 = NXOpen.Point3d(38.786406675633316, 7.081335658621958, 0.0)
    viewCenter256 = NXOpen.Point3d(-38.786406675633266, -7.081335658621958, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint256, viewCenter256)
    
    scaleAboutPoint257 = NXOpen.Point3d(48.885356961508826, 8.851669573277448, 0.0)
    viewCenter257 = NXOpen.Point3d(-48.885356961508755, -8.851669573277448, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint257, viewCenter257)
    
    scaleAboutPoint258 = NXOpen.Point3d(62.615503515512763, 10.561651195387592, 0.0)
    viewCenter258 = NXOpen.Point3d(-62.615503515512678, -10.561651195387592, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint258, viewCenter258)
    
    scaleAboutPoint259 = NXOpen.Point3d(90.842773674614392, 38.97752226869278, 0.0)
    viewCenter259 = NXOpen.Point3d(-90.842773674614278, -38.97752226869278, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint259, viewCenter259)
    
    scaleAboutPoint260 = NXOpen.Point3d(72.674218939691542, 31.684953586162774, 0.0)
    viewCenter260 = NXOpen.Point3d(-72.674218939691457, -31.684953586162774, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint260, viewCenter260)
    
    scaleAboutPoint261 = NXOpen.Point3d(58.541723768720445, 25.347962868930217, 0.0)
    viewCenter261 = NXOpen.Point3d(-58.54172376872031, -25.347962868930217, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint261, viewCenter261)
    
    scaleAboutPoint262 = NXOpen.Point3d(48.764652376418617, 20.600249188718077, 0.0)
    viewCenter262 = NXOpen.Point3d(-48.764652376418589, -20.600249188718077, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint262, viewCenter262)
    
    scaleAboutPoint263 = NXOpen.Point3d(40.041734360570807, 16.222696236115336, 0.0)
    viewCenter263 = NXOpen.Point3d(-40.041734360570679, -16.222696236115336, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint263, viewCenter263)
    
    scaleAboutPoint264 = NXOpen.Point3d(32.03338748845664, 12.978156988892268, 0.0)
    viewCenter264 = NXOpen.Point3d(-32.03338748845654, -12.978156988892268, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint264, viewCenter264)
    
    scaleAboutPoint265 = NXOpen.Point3d(25.626709990765342, 10.382525591113815, 0.0)
    viewCenter265 = NXOpen.Point3d(-25.62670999076526, -10.382525591113815, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint265, viewCenter265)
    
    scaleAboutPoint266 = NXOpen.Point3d(20.633209587420076, 8.3060204728910527, 0.0)
    viewCenter266 = NXOpen.Point3d(-20.633209587420023, -8.3060204728910527, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint266, viewCenter266)
    
    scaleAboutPoint267 = NXOpen.Point3d(16.506567669936061, 6.644816378312842, 0.0)
    viewCenter267 = NXOpen.Point3d(-16.506567669936011, -6.644816378312842, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint267, viewCenter267)
    
    scaleAboutPoint268 = NXOpen.Point3d(13.205254135948831, 5.315853102650383, 0.0)
    viewCenter268 = NXOpen.Point3d(-13.20525413594879, -5.315853102650161, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint268, viewCenter268)
    
    scaleAboutPoint269 = NXOpen.Point3d(10.564203308759094, 4.2526824821203073, 0.0)
    viewCenter269 = NXOpen.Point3d(-10.564203308759039, -4.2526824821201288, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint269, viewCenter269)
    
    line9 = workPart.Lines.CreateFaceAxis(face7, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line9.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint3 = componentPositioner9.CreateConstraint(True)
    
    componentConstraint3 = constraint3
    componentConstraint3.ConstraintAlignment = NXOpen.Positioning.Constraint.Alignment.InferAlign
    
    componentConstraint3.ConstraintType = NXOpen.Positioning.Constraint.Type.Touch
    
    constraintReference5 = componentConstraint3.CreateConstraintReference(component12, face1, False, False, False)
    
    helpPoint5 = NXOpen.Point3d(203.31809702646112, 137.69427070551134, 0.75204685249252912)
    constraintReference5.HelpPoint = helpPoint5
    
    constraintReference6 = componentConstraint3.CreateConstraintReference(component2, face7, False, False, False)
    
    helpPoint6 = NXOpen.Point3d(97.273900445287936, -34.307098348121897, 2.6688501798218445)
    constraintReference6.HelpPoint = helpPoint6
    
    constraintReference6.SetFixHint(True)
    
    componentConstraint3.SetAlignmentHint(NXOpen.Positioning.Constraint.Alignment.ContraAlign)
    
    objects15 = [NXOpen.TaggedObject.Null] * 1 
    objects15[0] = line9
    nErrs31 = theSession.UpdateManager.AddObjectsToDeleteList(objects15)
    
    componentNetwork9.Solve()
    
    line10 = workPart.Lines.CreateFaceAxis(face7, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line10.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    objects16 = [NXOpen.TaggedObject.Null] * 1 
    objects16[0] = line10
    nErrs32 = theSession.UpdateManager.AddObjectsToDeleteList(objects16)
    
    scaleAboutPoint270 = NXOpen.Point3d(-5.9672560542766382, -8.1003475849909101, 0.0)
    viewCenter270 = NXOpen.Point3d(5.9672560542767092, 8.1003475849910522, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint270, viewCenter270)
    
    scaleAboutPoint271 = NXOpen.Point3d(-7.4590700678458148, -10.192937377780177, 0.0)
    viewCenter271 = NXOpen.Point3d(7.4590700678458699, 10.192937377780355, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint271, viewCenter271)
    
    scaleAboutPoint272 = NXOpen.Point3d(-9.323837584807281, -12.74117172222522, 0.0)
    viewCenter272 = NXOpen.Point3d(9.3238375848073236, 12.741171722225443, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint272, viewCenter272)
    
    scaleAboutPoint273 = NXOpen.Point3d(-11.65479698100909, -15.926464652781661, 0.0)
    viewCenter273 = NXOpen.Point3d(11.654796981009143, 15.926464652781661, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint273, viewCenter273)
    
    scaleAboutPoint274 = NXOpen.Point3d(-16.018753769147111, -21.622021548478511, 0.0)
    viewCenter274 = NXOpen.Point3d(16.018753769147189, 21.622021548478511, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint274, viewCenter274)
    
    scaleAboutPoint275 = NXOpen.Point3d(-21.671462146531372, -29.664358831753983, 0.0)
    viewCenter275 = NXOpen.Point3d(21.671462146531454, 29.664358831753983, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint275, viewCenter275)
    
    scaleAboutPoint276 = NXOpen.Point3d(-27.913337650712972, -37.4924535234668, 0.0)
    viewCenter276 = NXOpen.Point3d(27.913337650713007, 37.4924535234668, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint276, viewCenter276)
    
    scaleAboutPoint277 = NXOpen.Point3d(-34.891672063391191, -46.865566904333498, 0.0)
    viewCenter277 = NXOpen.Point3d(34.891672063391233, 46.865566904333498, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint277, viewCenter277)
    
    scaleAboutPoint278 = NXOpen.Point3d(-43.936468972812705, -58.581958630416864, 0.0)
    viewCenter278 = NXOpen.Point3d(43.936468972812754, 58.581958630416864, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint278, viewCenter278)
    
    scaleAboutPoint279 = NXOpen.Point3d(-54.920586216015863, -73.227448288021066, 0.0)
    viewCenter279 = NXOpen.Point3d(54.920586216015934, 73.227448288021066, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint279, viewCenter279)
    
    scaleAboutPoint280 = NXOpen.Point3d(-94.803392872884586, -167.98054758378481, 0.0)
    viewCenter280 = NXOpen.Point3d(94.803392872884586, 167.98054758378481, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint280, viewCenter280)
    
    scaleAboutPoint281 = NXOpen.Point3d(-76.647411532242046, -133.17739221612624, 0.0)
    viewCenter281 = NXOpen.Point3d(76.647411532241918, 133.17739221612624, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint281, viewCenter281)
    
    scaleAboutPoint282 = NXOpen.Point3d(-62.283565906514752, -104.93251930503277, 0.0)
    viewCenter282 = NXOpen.Point3d(62.283565906514724, 104.93251930503277, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint282, viewCenter282)
    
    scaleAboutPoint283 = NXOpen.Point3d(-49.826852725211801, -81.628487410295165, 0.0)
    viewCenter283 = NXOpen.Point3d(49.826852725211779, 81.628487410295165, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint283, viewCenter283)
    
    scaleAboutPoint284 = NXOpen.Point3d(-39.861482180169439, -64.47877996068749, 0.0)
    viewCenter284 = NXOpen.Point3d(39.861482180169439, 64.47877996068749, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint284, viewCenter284)
    
    line11 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line11.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint4 = componentPositioner9.CreateConstraint(True)
    
    componentConstraint4 = constraint4
    componentConstraint4.ConstraintAlignment = NXOpen.Positioning.Constraint.Alignment.InferAlign
    
    componentConstraint4.ConstraintType = NXOpen.Positioning.Constraint.Type.Touch
    
    constraintReference7 = componentConstraint4.CreateConstraintReference(component2, face7, False, False, False)
    
    helpPoint7 = NXOpen.Point3d(97.062437015474231, -34.667423931162944, 2.8021562976574108)
    constraintReference7.HelpPoint = helpPoint7
    
    constraintReference8 = componentConstraint4.CreateConstraintReference(component12, face1, False, False, False)
    
    helpPoint8 = NXOpen.Point3d(206.15887871572113, 136.953487967402, 2.305563872183372)
    constraintReference8.HelpPoint = helpPoint8
    
    constraintReference8.SetFixHint(True)
    
    componentConstraint4.SetAlignmentHint(NXOpen.Positioning.Constraint.Alignment.ContraAlign)
    
    objects17 = [NXOpen.TaggedObject.Null] * 1 
    objects17[0] = line11
    nErrs33 = theSession.UpdateManager.AddObjectsToDeleteList(objects17)
    
    componentNetwork9.Solve()
    
    line12 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line12.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    objects18 = [NXOpen.TaggedObject.Null] * 1 
    objects18[0] = line12
    nErrs34 = theSession.UpdateManager.AddObjectsToDeleteList(objects18)
    
    componentNetwork9.Solve()
    
    componentPositioner9.ClearNetwork()
    
    nErrs35 = theSession.UpdateManager.AddToDeleteList(componentNetwork9)
    
    componentPositioner9.DeleteNonPersistentConstraints()
    
    nErrs36 = theSession.UpdateManager.DoUpdate(markId51)
    
    theSession.SetUndoMarkName(markId50, "Assembly Constraints")
    
    componentPositioner9.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner9.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId51, None)
    
    theSession.DeleteUndoMark(markId54, None)
    
    theSession.DeleteUndoMark(markId53, None)
    
    theSession.DeleteUndoMark(markId52, None)
    
    theSession.DeleteUndoMark(markId49, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete11 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects19 = [NXOpen.TaggedObject.Null] * 3 
    displayedConstraint1 = workPart.FindObject("ENTITY 160 1 1")
    objects19[0] = displayedConstraint1
    displayedConstraint2 = workPart.FindObject("ENTITY 160 3 1")
    objects19[1] = displayedConstraint2
    displayedConstraint3 = workPart.FindObject("ENTITY 160 2 1")
    objects19[2] = displayedConstraint3
    nErrs37 = theSession.UpdateManager.AddObjectsToDeleteList(objects19)
    
    notifyOnDelete12 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id6 = theSession.NewestVisibleUndoMark
    
    nErrs38 = theSession.UpdateManager.DoUpdate(id6)
    
    theSession.DeleteUndoMark(markId55, None)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner10 = workPart.ComponentAssembly.Positioner
    
    componentPositioner10.ClearNetwork()
    
    componentPositioner10.PrimaryArrangement = arrangement2
    
    componentPositioner10.BeginAssemblyConstraints()
    
    allowInterpartPositioning10 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression104 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression105 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression106 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression107 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression108 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression109 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression110 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression111 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network10 = componentPositioner10.EstablishNetwork()
    
    componentNetwork10 = network10
    componentNetwork10.MoveObjectsState = True
    
    componentNetwork10.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork10.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId58, "Assembly Constraints Dialog")
    
    componentNetwork10.MoveObjectsState = True
    
    componentNetwork10.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    scaleAboutPoint285 = NXOpen.Point3d(16.562600347729283, 33.454804682478027, 0.0)
    viewCenter285 = NXOpen.Point3d(-16.56260034772934, -33.454804682478027, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint285, viewCenter285)
    
    scaleAboutPoint286 = NXOpen.Point3d(13.250080278183429, 26.763843745982424, 0.0)
    viewCenter286 = NXOpen.Point3d(-13.250080278183473, -26.763843745982076, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint286, viewCenter286)
    
    scaleAboutPoint287 = NXOpen.Point3d(-29.690727150715599, -13.922472411703017, 0.0)
    viewCenter287 = NXOpen.Point3d(29.690727150715528, 13.922472411703296, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint287, viewCenter287)
    
    scaleAboutPoint288 = NXOpen.Point3d(-37.113408938394471, -17.534932109436813, 0.0)
    viewCenter288 = NXOpen.Point3d(37.113408938394407, 17.534932109437161, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint288, viewCenter288)
    
    line13 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint5 = componentPositioner10.CreateConstraint(True)
    
    componentConstraint5 = constraint5
    componentConstraint5.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge6 = component2.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 120 * 150 {(-0.75,0,-1.2990381056767)(1.5,0,0)(-0.75,0,1.2990381056767) EXTRUDE(2)}")
    constraintReference9 = componentConstraint5.CreateConstraintReference(component2, edge6, False, False, False)
    
    helpPoint9 = NXOpen.Point3d(96.664927186513211, -32.950143111867703, 3.2523251150567458)
    constraintReference9.HelpPoint = helpPoint9
    
    constraintReference10 = componentConstraint5.CreateConstraintReference(component12, edge4, False, False, False)
    
    helpPoint10 = NXOpen.Point3d(202.320467711969, 137.5218272062059, 1.7361776789779448)
    constraintReference10.HelpPoint = helpPoint10
    
    constraintReference10.SetFixHint(True)
    
    objects20 = [NXOpen.TaggedObject.Null] * 1 
    objects20[0] = line13
    nErrs39 = theSession.UpdateManager.AddObjectsToDeleteList(objects20)
    
    componentNetwork10.Solve()
    
    face8 = component2.FindObject("PROTO#.Features|EXTRUDE(2)|FACE 140 {(0,-1.5,-10) EXTRUDE(2)}")
    line14 = workPart.Lines.CreateFaceAxis(face8, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint289 = NXOpen.Point3d(-60.564732614831087, -47.792578117825933, 0.0)
    viewCenter289 = NXOpen.Point3d(60.564732614831009, 47.792578117825933, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint289, viewCenter289)
    
    rotMatrix24 = NXOpen.Matrix3x3()
    
    rotMatrix24.Xx = -0.89293739689764118
    rotMatrix24.Xy = -0.40064113543853141
    rotMatrix24.Xz = -0.20530339942677256
    rotMatrix24.Yx = -0.039083502122690038
    rotMatrix24.Yy = -0.38533300800192499
    rotMatrix24.Yz = 0.92194953918639899
    rotMatrix24.Zx = -0.44848108665080871
    rotMatrix24.Zy = 0.83126719743937494
    rotMatrix24.Zz = 0.32841979443662805
    translation24 = NXOpen.Point3d(114.09605456201359, 14.900127024360771, 14.655816868496505)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix24, translation24, 2.0068274638140569)
    
    scaleAboutPoint290 = NXOpen.Point3d(-49.770202039942866, -42.452993528110106, 0.0)
    viewCenter290 = NXOpen.Point3d(49.770202039942781, 42.452993528110454, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint290, viewCenter290)
    
    scaleAboutPoint291 = NXOpen.Point3d(-62.212752549928538, -53.066241910137641, 0.0)
    viewCenter291 = NXOpen.Point3d(62.21275254992846, 53.066241910137641, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint291, viewCenter291)
    
    scaleAboutPoint292 = NXOpen.Point3d(-82.503998000815798, -65.920797403897723, 0.0)
    viewCenter292 = NXOpen.Point3d(82.503998000815727, 65.920797403897723, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint292, viewCenter292)
    
    scaleAboutPoint293 = NXOpen.Point3d(-103.12999750101973, -82.400996754872139, 0.0)
    viewCenter293 = NXOpen.Point3d(103.12999750101964, 82.400996754872139, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint293, viewCenter293)
    
    rotMatrix25 = NXOpen.Matrix3x3()
    
    rotMatrix25.Xx = -0.19482956074025601
    rotMatrix25.Xy = -0.89692303797700101
    rotMatrix25.Xz = -0.3969515161929299
    rotMatrix25.Yx = 0.00047902641842595753
    rotMatrix25.Yy = -0.4047938312172078
    rotMatrix25.Yz = 0.91440785470280406
    rotMatrix25.Zx = -0.98083699603728813
    rotMatrix25.Zy = 0.17796353040609633
    rotMatrix25.Zz = 0.079295454156899772
    translation25 = NXOpen.Point3d(2.5634913843883282, -48.317439328916628, 61.213336411512977)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix25, translation25, 0.82199652917823784)
    
    rotMatrix26 = NXOpen.Matrix3x3()
    
    rotMatrix26.Xx = -0.39768633327380287
    rotMatrix26.Xy = -0.84213454348453864
    rotMatrix26.Xz = -0.36421832874983778
    rotMatrix26.Yx = 0.10586632095690254
    rotMatrix26.Yy = -0.43642371780970896
    rotMatrix26.Yz = 0.89349127618583979
    rotMatrix26.Zx = -0.91139338510562473
    rotMatrix26.Zy = 0.31677081494866016
    rotMatrix26.Zz = 0.26271343395889257
    translation26 = NXOpen.Point3d(14.763994984565301, -54.559330134198177, 52.236653972072716)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix26, translation26, 0.82199652917823784)
    
    scaleAboutPoint294 = NXOpen.Point3d(-157.88159729790945, -109.43882381506475, 0.0)
    viewCenter294 = NXOpen.Point3d(157.88159729790934, 109.43882381506475, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint294, viewCenter294)
    
    scaleAboutPoint295 = NXOpen.Point3d(-155.4031298173918, -70.040847241641231, 0.0)
    viewCenter295 = NXOpen.Point3d(155.40312981739172, 70.040847241641231, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint295, viewCenter295)
    
    scaleAboutPoint296 = NXOpen.Point3d(-124.32250385391345, -56.03267779331297, 0.0)
    viewCenter296 = NXOpen.Point3d(124.32250385391337, 56.03267779331297, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint296, viewCenter296)
    
    scaleAboutPoint297 = NXOpen.Point3d(-99.458003083130777, -44.826142234650391, 0.0)
    viewCenter297 = NXOpen.Point3d(99.458003083130649, 44.826142234650391, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint297, viewCenter297)
    
    scaleAboutPoint298 = NXOpen.Point3d(-79.566402466504599, -35.860913787720307, 0.0)
    viewCenter298 = NXOpen.Point3d(79.566402466504513, 35.860913787720655, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint298, viewCenter298)
    
    scaleAboutPoint299 = NXOpen.Point3d(-55.637153008889705, -30.270830167869697, 0.0)
    viewCenter299 = NXOpen.Point3d(55.637153008889634, 30.270830167869974, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint299, viewCenter299)
    
    scaleAboutPoint300 = NXOpen.Point3d(-44.425343786434823, -24.301042754972801, 0.0)
    viewCenter300 = NXOpen.Point3d(44.425343786434709, 24.301042754973022, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint300, viewCenter300)
    
    scaleAboutPoint301 = NXOpen.Point3d(-35.540275029147878, -19.440834203978245, 0.0)
    viewCenter301 = NXOpen.Point3d(35.540275029147764, 19.440834203978422, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint301, viewCenter301)
    
    scaleAboutPoint302 = NXOpen.Point3d(-28.432220023318308, -15.552667363182596, 0.0)
    viewCenter302 = NXOpen.Point3d(28.432220023318202, 15.552667363182739, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint302, viewCenter302)
    
    scaleAboutPoint303 = NXOpen.Point3d(-22.745776018654652, -12.442133890546016, 0.0)
    viewCenter303 = NXOpen.Point3d(22.745776018654539, 12.442133890546243, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint303, viewCenter303)
    
    rotMatrix27 = NXOpen.Matrix3x3()
    
    rotMatrix27.Xx = -0.35738207674221106
    rotMatrix27.Xy = -0.85181358490921244
    rotMatrix27.Xz = -0.38300348273552065
    rotMatrix27.Yx = 0.15374790909118444
    rotMatrix27.Yy = -0.45814917570480435
    rotMatrix27.Yz = 0.87547753440684928
    rotMatrix27.Zx = -0.92121638699792663
    rotMatrix27.Zy = 0.25399399474224238
    rotMatrix27.Zz = 0.29469886148637264
    translation27 = NXOpen.Point3d(171.12149017293635, 25.237620503539521, 61.530324723040117)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix27, translation27, 7.6554392387926367)
    
    scaleAboutPoint304 = NXOpen.Point3d(2.2983386214480457, -3.8017631332223485, 0.0)
    viewCenter304 = NXOpen.Point3d(-2.2983386214481625, 3.8017631332225306, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint304, viewCenter304)
    
    scaleAboutPoint305 = NXOpen.Point3d(1.8386708971584225, -3.0414105065778418, 0.0)
    viewCenter305 = NXOpen.Point3d(-1.838670897158541, 3.0414105065780608, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint305, viewCenter305)
    
    scaleAboutPoint306 = NXOpen.Point3d(1.4709367177267296, -2.4331284052622717, 0.0)
    viewCenter306 = NXOpen.Point3d(-1.4709367177268409, 2.4331284052624467, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint306, viewCenter306)
    
    scaleAboutPoint307 = NXOpen.Point3d(1.1590538948703686, -1.7695479310997992, 0.0)
    viewCenter307 = NXOpen.Point3d(-1.1590538948704825, 1.769547931099986, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint307, viewCenter307)
    
    scaleAboutPoint308 = NXOpen.Point3d(0.81399204830589367, -1.3731691945334199, 0.0)
    viewCenter308 = NXOpen.Point3d(-0.8139920483060068, 1.3731691945336066, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint308, viewCenter308)
    
    scaleAboutPoint309 = NXOpen.Point3d(0.91131718451638644, -1.6810705345448023, 0.0)
    viewCenter309 = NXOpen.Point3d(-0.91131718451650023, 1.681070534544989, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint309, viewCenter309)
    
    scaleAboutPoint310 = NXOpen.Point3d(1.0949077823680018, -2.1013381681810039, 0.0)
    viewCenter310 = NXOpen.Point3d(-1.094907782368113, 2.1013381681812371, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint310, viewCenter310)
    
    scaleAboutPoint311 = NXOpen.Point3d(1.1474412365725246, -2.6266727102262895, 0.0)
    viewCenter311 = NXOpen.Point3d(-1.1474412365726385, 2.6266727102265084, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint311, viewCenter311)
    
    scaleAboutPoint312 = NXOpen.Point3d(1.2269326475399092, -3.2833408877829084, 0.0)
    viewCenter312 = NXOpen.Point3d(-1.2269326475400233, 3.2833408877830905, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint312, viewCenter312)
    
    scaleAboutPoint313 = NXOpen.Point3d(1.4904639556382797, -4.0609742559419928, 0.0)
    viewCenter313 = NXOpen.Point3d(-1.4904639556383938, 4.0609742559422211, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint313, viewCenter313)
    
    scaleAboutPoint314 = NXOpen.Point3d(-1.593068358381615, -4.7522039165279573, 0.0)
    viewCenter314 = NXOpen.Point3d(1.5930683583814991, 4.7522039165280994, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint314, viewCenter314)
    
    scaleAboutPoint315 = NXOpen.Point3d(-1.9913354479770078, -5.9402548956599475, 0.0)
    viewCenter315 = NXOpen.Point3d(1.9913354479768741, 5.9402548956601251, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint315, viewCenter315)
    
    scaleAboutPoint316 = NXOpen.Point3d(-2.4891693099712322, -7.6784544816059315, 0.0)
    viewCenter316 = NXOpen.Point3d(2.4891693099711207, 7.6784544816061544, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint316, viewCenter316)
    
    scaleAboutPoint317 = NXOpen.Point3d(-3.1114616374640227, -9.5980681020074137, 0.0)
    viewCenter317 = NXOpen.Point3d(3.1114616374639184, 9.5980681020076926, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint317, viewCenter317)
    
    rotMatrix28 = NXOpen.Matrix3x3()
    
    rotMatrix28.Xx = -0.55171617083461266
    rotMatrix28.Xy = 0.72445698444330209
    rotMatrix28.Xz = 0.41324489655760943
    rotMatrix28.Yx = -0.10009112290508437
    rotMatrix28.Yy = -0.54940960754921364
    rotMatrix28.Yz = 0.82953652737430195
    rotMatrix28.Zx = 0.82800424754658908
    rotMatrix28.Zy = 0.41630657071914473
    rotMatrix28.Zz = 0.3756298779661601
    translation28 = NXOpen.Point3d(-1.5226352438963122, 71.053258592867692, -253.03589931583252)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix28, translation28, 2.0068274638140582)
    
    objects21 = [NXOpen.TaggedObject.Null] * 1 
    objects21[0] = line14
    nErrs40 = theSession.UpdateManager.AddObjectsToDeleteList(objects21)
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs41 = theSession.UpdateManager.DoUpdate(markId59)
    
    componentNetwork10.Solve()
    
    componentPositioner10.ClearNetwork()
    
    nErrs42 = theSession.UpdateManager.AddToDeleteList(componentNetwork10)
    
    componentPositioner10.DeleteNonPersistentConstraints()
    
    nErrs43 = theSession.UpdateManager.DoUpdate(markId59)
    
    theSession.DeleteUndoMark(markId61, None)
    
    theSession.SetUndoMarkName(markId58, "Assembly Constraints")
    
    componentPositioner10.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner10.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId59, None)
    
    theSession.DeleteUndoMark(markId60, None)
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner11 = workPart.ComponentAssembly.Positioner
    
    componentPositioner11.ClearNetwork()
    
    componentPositioner11.PrimaryArrangement = arrangement2
    
    componentPositioner11.BeginAssemblyConstraints()
    
    allowInterpartPositioning11 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression112 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression113 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression114 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression115 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression116 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression117 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression118 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression119 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network11 = componentPositioner11.EstablishNetwork()
    
    componentNetwork11 = network11
    componentNetwork11.MoveObjectsState = True
    
    componentNetwork11.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork11.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId62, "Assembly Constraints Dialog")
    
    componentNetwork11.MoveObjectsState = True
    
    componentNetwork11.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    # ----------------------------------------------
    #   Dialog Begin Assembly Constraints
    # ----------------------------------------------
    line15 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint318 = NXOpen.Point3d(-14.172971441838044, -22.808595901748408, 0.0)
    viewCenter318 = NXOpen.Point3d(14.172971441837957, 22.808595901748756, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint318, viewCenter318)
    
    scaleAboutPoint319 = NXOpen.Point3d(-11.338377153470434, -18.246876721398728, 0.0)
    viewCenter319 = NXOpen.Point3d(11.338377153470356, 18.246876721399005, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint319, viewCenter319)
    
    scaleAboutPoint320 = NXOpen.Point3d(-9.0707017227763629, -14.597501377118983, 0.0)
    viewCenter320 = NXOpen.Point3d(9.0707017227762794, 14.597501377119205, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint320, viewCenter320)
    
    scaleAboutPoint321 = NXOpen.Point3d(-7.2565613782211118, -11.678001101695184, 0.0)
    viewCenter321 = NXOpen.Point3d(7.2565613782210008, 11.678001101695363, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint321, viewCenter321)
    
    scaleAboutPoint322 = NXOpen.Point3d(-5.7512467853436142, -9.5044078330559874, 0.0)
    viewCenter322 = NXOpen.Point3d(5.7512467853435165, 9.5044078330561295, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint322, viewCenter322)
    
    scaleAboutPoint323 = NXOpen.Point3d(-5.5514382115805043, -8.3379577808172556, 0.0)
    viewCenter323 = NXOpen.Point3d(5.5514382115804191, 8.337957780817483, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint323, viewCenter323)
    
    scaleAboutPoint324 = NXOpen.Point3d(-4.4411505692644102, -6.6703662246538054, 0.0)
    viewCenter324 = NXOpen.Point3d(4.4411505692643249, 6.6703662246539883, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint324, viewCenter324)
    
    scaleAboutPoint325 = NXOpen.Point3d(-3.5529204554115417, -5.3362929797230079, 0.0)
    viewCenter325 = NXOpen.Point3d(3.5529204554114506, 5.3362929797232264, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint325, viewCenter325)
    
    objects22 = [NXOpen.TaggedObject.Null] * 1 
    objects22[0] = line15
    nErrs44 = theSession.UpdateManager.AddObjectsToDeleteList(objects22)
    
    scaleAboutPoint326 = NXOpen.Point3d(12.132463002603579, -4.4681085260271383, 0.0)
    viewCenter326 = NXOpen.Point3d(-12.132463002603666, 4.4681085260273141, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint326, viewCenter326)
    
    scaleAboutPoint327 = NXOpen.Point3d(9.7059704020828583, -3.539095862199694, 0.0)
    viewCenter327 = NXOpen.Point3d(-9.7059704020829418, 3.5390958621998805, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint327, viewCenter327)
    
    scaleAboutPoint328 = NXOpen.Point3d(7.7506199382174756, -2.8454330732085245, 0.0)
    viewCenter328 = NXOpen.Point3d(-7.75061993821756, 2.845433073208711, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint328, viewCenter328)
    
    scaleAboutPoint329 = NXOpen.Point3d(9.6351884848388583, -3.5921823001326723, 0.0)
    viewCenter329 = NXOpen.Point3d(-9.6351884848389435, 3.5921823001328592, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint329, viewCenter329)
    
    scaleAboutPoint330 = NXOpen.Point3d(12.043985606048579, -4.4902278751658695, 0.0)
    viewCenter330 = NXOpen.Point3d(-12.043985606048667, 4.4902278751660445, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint330, viewCenter330)
    
    scaleAboutPoint331 = NXOpen.Point3d(15.054982007560737, -5.6127848439573365, 0.0)
    viewCenter331 = NXOpen.Point3d(-15.054982007560819, 5.6127848439575549, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint331, viewCenter331)
    
    scaleAboutPoint332 = NXOpen.Point3d(19.50995717003682, -7.8108951646205256, 0.0)
    viewCenter332 = NXOpen.Point3d(-19.509957170036905, 7.8108951646207077, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint332, viewCenter332)
    
    scaleAboutPoint333 = NXOpen.Point3d(24.733061292838986, -9.9364263709221117, 0.0)
    viewCenter333 = NXOpen.Point3d(-24.733061292839075, 9.9364263709223408, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint333, viewCenter333)
    
    scaleAboutPoint334 = NXOpen.Point3d(30.970328933282005, -12.474535280886013, 0.0)
    viewCenter334 = NXOpen.Point3d(-30.970328933282094, 12.474535280886155, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint334, viewCenter334)
    
    scaleAboutPoint335 = NXOpen.Point3d(38.71291116660251, -15.593169101107513, 0.0)
    viewCenter335 = NXOpen.Point3d(-38.712911166602602, 15.593169101107691, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint335, viewCenter335)
    
    scaleAboutPoint336 = NXOpen.Point3d(48.391138958253151, -19.49146137638439, 0.0)
    viewCenter336 = NXOpen.Point3d(-48.391138958253237, 19.491461376384613, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint336, viewCenter336)
    
    scaleAboutPoint337 = NXOpen.Point3d(61.227236628740094, -24.153380168788033, 0.0)
    viewCenter337 = NXOpen.Point3d(-61.227236628740201, 24.153380168788313, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint337, viewCenter337)
    
    scaleAboutPoint338 = NXOpen.Point3d(76.53404578592513, -30.191725210985037, 0.0)
    viewCenter338 = NXOpen.Point3d(-76.534045785925215, 30.191725210985386, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint338, viewCenter338)
    
    scaleAboutPoint339 = NXOpen.Point3d(95.667557232406423, -37.739656513731518, 0.0)
    viewCenter339 = NXOpen.Point3d(-95.667557232406523, 37.739656513731518, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint339, viewCenter339)
    
    scaleAboutPoint340 = NXOpen.Point3d(119.58444654050805, -47.17457064216439, 0.0)
    viewCenter340 = NXOpen.Point3d(-119.58444654050815, 47.17457064216439, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint340, viewCenter340)
    
    rotMatrix29 = NXOpen.Matrix3x3()
    
    rotMatrix29.Xx = 0.33019136347128342
    rotMatrix29.Xy = -0.85731617273691008
    rotMatrix29.Xz = -0.39494638047804587
    rotMatrix29.Yx = 0.06223138271347442
    rotMatrix29.Yy = -0.39773114580698221
    rotMatrix29.Yz = 0.9153890924959891
    rotMatrix29.Zx = -0.94186034978363165
    rotMatrix29.Zy = -0.32683163191282072
    rotMatrix29.Zz = -0.077975418476960781
    translation29 = NXOpen.Point3d(119.27566059255997, 23.036958169339233, -120.92597443668652)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix29, translation29, 1.0274956614727986)
    
    scaleAboutPoint341 = NXOpen.Point3d(-26.651572387903972, -39.140473458564252, 0.0)
    viewCenter341 = NXOpen.Point3d(26.651572387903869, 39.140473458564252, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint341, viewCenter341)
    
    scaleAboutPoint342 = NXOpen.Point3d(-24.205292796743727, -31.930386242513016, 0.0)
    viewCenter342 = NXOpen.Point3d(24.205292796743574, 31.930386242513016, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint342, viewCenter342)
    
    scaleAboutPoint343 = NXOpen.Point3d(-19.693838224414474, -25.709110987520031, 0.0)
    viewCenter343 = NXOpen.Point3d(19.693838224414367, 25.709110987520031, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint343, viewCenter343)
    
    scaleAboutPoint344 = NXOpen.Point3d(-16.150595363954977, -20.567288790016022, 0.0)
    viewCenter344 = NXOpen.Point3d(16.150595363954849, 20.567288790016022, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint344, viewCenter344)
    
    scaleAboutPoint345 = NXOpen.Point3d(-13.764262497933876, -16.031937928627922, 0.0)
    viewCenter345 = NXOpen.Point3d(13.764262497933746, 16.031937928628199, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint345, viewCenter345)
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint6 = componentPositioner11.CreateConstraint(True)
    
    componentConstraint6 = constraint6
    componentConstraint6.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge7 = component2.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 130 * 150 {(-0.75,-3,-1.2990381056767)(1.5,-3,0)(-0.75,-3,1.2990381056767) EXTRUDE(2)}")
    constraintReference11 = componentConstraint6.CreateConstraintReference(component2, edge7, False, False, False)
    
    helpPoint11 = NXOpen.Point3d(205.320467711969, 137.63536695458839, 1.4819661234047588)
    constraintReference11.HelpPoint = helpPoint11
    
    constraintReference12 = componentConstraint6.CreateConstraintReference(component16, edge2, False, False, False)
    
    helpPoint12 = NXOpen.Point3d(-105.39955928289965, 135.17459085134135, 5.0806219979811384)
    constraintReference12.HelpPoint = helpPoint12
    
    constraintReference12.SetFixHint(True)
    
    componentNetwork11.Solve()
    
    rotMatrix30 = NXOpen.Matrix3x3()
    
    rotMatrix30.Xx = 0.96043258412626686
    rotMatrix30.Xy = 0.011589920192679426
    rotMatrix30.Xz = -0.27827131562284396
    rotMatrix30.Yx = 0.27848604229916291
    rotMatrix30.Yy = -0.053752871932535681
    rotMatrix30.Yz = 0.95893490550899729
    rotMatrix30.Zx = -0.0038439033663475765
    rotMatrix30.Zy = -0.99848700668007029
    rotMatrix30.Zz = -0.054853640699396369
    translation30 = NXOpen.Point3d(-13.916950314335832, -10.368445158970633, -28.193845821007116)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix30, translation30, 3.1356679122094677)
    
    scaleAboutPoint346 = NXOpen.Point3d(-53.3694775781956, -2.1938441376015985, 0.0)
    viewCenter346 = NXOpen.Point3d(53.369477578195493, 2.193844137601821, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint346, viewCenter346)
    
    scaleAboutPoint347 = NXOpen.Point3d(-66.079007317667063, -3.1641982753870384, 0.0)
    viewCenter347 = NXOpen.Point3d(66.079007317666964, 3.1641982753873168, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint347, viewCenter347)
    
    scaleAboutPoint348 = NXOpen.Point3d(-80.09376884573571, -4.7462974130806614, 0.0)
    viewCenter348 = NXOpen.Point3d(80.093768845735568, 4.7462974130806614, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint348, viewCenter348)
    
    scaleAboutPoint349 = NXOpen.Point3d(-68.804832290318231, -15.161783402896415, 0.0)
    viewCenter349 = NXOpen.Point3d(68.804832290318132, 15.161783402896415, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint349, viewCenter349)
    
    scaleAboutPoint350 = NXOpen.Point3d(-86.006040362897835, -19.98224171305645, 0.0)
    viewCenter350 = NXOpen.Point3d(86.006040362897636, 19.98224171305645, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint350, viewCenter350)
    
    scaleAboutPoint351 = NXOpen.Point3d(-107.2500473387633, -25.750311485897576, 0.0)
    viewCenter351 = NXOpen.Point3d(107.25004733876304, 25.750311485897576, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint351, viewCenter351)
    
    scaleAboutPoint352 = NXOpen.Point3d(-133.41880138630663, -32.831647144519337, 0.0)
    viewCenter352 = NXOpen.Point3d(133.41880138630637, 32.831647144519337, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint352, viewCenter352)
    
    rotMatrix31 = NXOpen.Matrix3x3()
    
    rotMatrix31.Xx = 0.49003932874264838
    rotMatrix31.Xy = 0.78931891171070767
    rotMatrix31.Xz = -0.36991500632073865
    rotMatrix31.Yx = 0.13630199040753477
    rotMatrix31.Yy = 0.34975778802112589
    rotMatrix31.Yz = 0.92687175872906502
    rotMatrix31.Zx = 0.8609780622619817
    rotMatrix31.Zy = -0.5046237661212416
    rotMatrix31.Zz = 0.063809332931906507
    translation31 = NXOpen.Point3d(-185.858902147566, -45.279537000686368, -7.7805492538096033)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix31, translation31, 0.65759722334259119)
    
    scaleAboutPoint353 = NXOpen.Point3d(-120.90575939862832, -28.164403187700152, 0.0)
    viewCenter353 = NXOpen.Point3d(120.90575939862806, 28.164403187700152, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint353, viewCenter353)
    
    scaleAboutPoint354 = NXOpen.Point3d(-98.334001986771241, -21.565885869439274, 0.0)
    viewCenter354 = NXOpen.Point3d(98.334001986771028, 21.565885869439274, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint354, viewCenter354)
    
    scaleAboutPoint355 = NXOpen.Point3d(-73.259636177378511, -10.300124594358959, 0.0)
    viewCenter355 = NXOpen.Point3d(73.25963617737834, 10.300124594358959, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint355, viewCenter355)
    
    scaleAboutPoint356 = NXOpen.Point3d(-58.607708941902821, -8.0340971836001458, 0.0)
    viewCenter356 = NXOpen.Point3d(58.607708941902686, 8.0340971836001458, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint356, viewCenter356)
    
    scaleAboutPoint357 = NXOpen.Point3d(-46.556563166502769, -6.262475753370282, 0.0)
    viewCenter357 = NXOpen.Point3d(46.556563166502663, 6.262475753370282, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint357, viewCenter357)
    
    scaleAboutPoint358 = NXOpen.Point3d(-36.98156734358664, -4.3507726286572286, 0.0)
    viewCenter358 = NXOpen.Point3d(36.981567343586512, 4.3507726286575767, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint358, viewCenter358)
    
    line16 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint359 = NXOpen.Point3d(-23.467803875787599, 5.8010301715431591, 0.0)
    viewCenter359 = NXOpen.Point3d(23.467803875787503, -5.8010301715428811, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint359, viewCenter359)
    
    scaleAboutPoint360 = NXOpen.Point3d(-18.605485859276111, 4.7252027579114522, 0.0)
    viewCenter360 = NXOpen.Point3d(18.605485859276016, -4.7252027579112292, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint360, viewCenter360)
    
    scaleAboutPoint361 = NXOpen.Point3d(-14.884388687420907, 3.915167999412418, 0.0)
    viewCenter361 = NXOpen.Point3d(14.884388687420797, -3.9151679994122399, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint361, viewCenter361)
    
    scaleAboutPoint362 = NXOpen.Point3d(-11.475492412070553, 3.4021459856962357, 0.0)
    viewCenter362 = NXOpen.Point3d(11.475492412070441, -3.4021459856960932, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint362, viewCenter362)
    
    scaleAboutPoint363 = NXOpen.Point3d(-14.344365515088187, 4.252682482120294, 0.0)
    viewCenter363 = NXOpen.Point3d(14.344365515088054, -4.2526824821201155, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint363, viewCenter363)
    
    scaleAboutPoint364 = NXOpen.Point3d(-17.930456893860221, 5.315853102650367, 0.0)
    viewCenter364 = NXOpen.Point3d(17.930456893860082, -5.3158531026501441, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint364, viewCenter364)
    
    scaleAboutPoint365 = NXOpen.Point3d(-22.413071117325241, 6.6448163783128198, 0.0)
    viewCenter365 = NXOpen.Point3d(22.413071117325138, -6.6448163783125418, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint365, viewCenter365)
    
    scaleAboutPoint366 = NXOpen.Point3d(-28.016338896656531, 8.7015452573144572, 0.0)
    viewCenter366 = NXOpen.Point3d(28.016338896656446, -8.7015452573144572, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint366, viewCenter366)
    
    scaleAboutPoint367 = NXOpen.Point3d(-35.020423620820665, 10.876931571643073, 0.0)
    viewCenter367 = NXOpen.Point3d(35.020423620820559, -10.876931571643073, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint367, viewCenter367)
    
    rotMatrix32 = NXOpen.Matrix3x3()
    
    rotMatrix32.Xx = 0.88386353900951076
    rotMatrix32.Xy = 0.36249428737503203
    rotMatrix32.Xz = -0.29560638699129438
    rotMatrix32.Yx = 0.22041804305218957
    rotMatrix32.Yy = 0.23462628583884315
    rotMatrix32.Yz = 0.9467662817667879
    rotMatrix32.Zx = 0.41255439726977045
    rotMatrix32.Zy = -0.90196917775161678
    rotMatrix32.Zz = 0.12747733790537372
    translation32 = NXOpen.Point3d(-103.06730748939756, -18.825944522010019, -18.556843247204483)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix32, translation32, 1.2843695768409988)
    
    modelingView1 = part4.ModelingViews.FindObject("Trimetric")
    scaleAboutPoint368 = NXOpen.Point3d(-8.7977337615988578, 5.0847608850820887, 0.0)
    viewCenter368 = NXOpen.Point3d(8.7977337615988578, -5.0847608850820887, 0.0)
    modelingView1.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint368, viewCenter368)
    
    scaleAboutPoint369 = NXOpen.Point3d(-10.99716720199857, 6.3559511063526086, 0.0)
    viewCenter369 = NXOpen.Point3d(10.99716720199857, -6.3559511063526086, 0.0)
    modelingView1.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint369, viewCenter369)
    
    scaleAboutPoint370 = NXOpen.Point3d(-13.74645900249822, 7.944938882940761, 0.0)
    viewCenter370 = NXOpen.Point3d(13.746459002498211, -7.944938882940761, 0.0)
    modelingView1.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint370, viewCenter370)
    
    modelingView2 = part1.ModelingViews.FindObject("Trimetric")
    rotMatrix33 = NXOpen.Matrix3x3()
    
    rotMatrix33.Xx = 0.92882320847186428
    rotMatrix33.Xy = 0.13795899713296217
    rotMatrix33.Xz = -0.34388190198685764
    rotMatrix33.Yx = 0.31416339096972995
    rotMatrix33.Yy = 0.19882033032974017
    rotMatrix33.Yz = 0.92831667011961549
    rotMatrix33.Zx = 0.19644035017896019
    rotMatrix33.Zy = -0.97027717243972944
    rotMatrix33.Zz = 0.14132727077223067
    translation33 = NXOpen.Point3d(-9.0735311742583491, -37.886948802616416, 7.8170326486526331)
    modelingView2.SetRotationTranslationScale(rotMatrix33, translation33, 2.2076440975609741)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    objects23 = [NXOpen.TaggedObject.Null] * 1 
    objects23[0] = line16
    nErrs45 = theSession.UpdateManager.AddObjectsToDeleteList(objects23)
    
    theSession.DeleteUndoMark(markId65, None)
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs46 = theSession.UpdateManager.DoUpdate(markId63)
    
    componentNetwork11.Solve()
    
    componentPositioner11.ClearNetwork()
    
    nErrs47 = theSession.UpdateManager.AddToDeleteList(componentNetwork11)
    
    componentPositioner11.DeleteNonPersistentConstraints()
    
    nErrs48 = theSession.UpdateManager.DoUpdate(markId63)
    
    theSession.DeleteUndoMark(markId66, None)
    
    theSession.SetUndoMarkName(markId62, "Assembly Constraints")
    
    componentPositioner11.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner11.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId63, None)
    
    theSession.DeleteUndoMark(markId64, None)
    
    theSession.DeleteUndoMark(markId57, None)
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin3, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    expression120 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression121 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    theSession.SetUndoMarkName(markId67, "Create Sketch Dialog")
    
    scaleAboutPoint371 = NXOpen.Point3d(-39.72985278600936, 0.8389410844707782, 0.0)
    viewCenter371 = NXOpen.Point3d(39.72985278600936, -0.8389410844707782, 0.0)
    modelingView2.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint371, viewCenter371)
    
    scaleAboutPoint372 = NXOpen.Point3d(-49.662315982511693, 1.0486763555884726, 0.0)
    viewCenter372 = NXOpen.Point3d(49.662315982511693, -1.0486763555884726, 0.0)
    modelingView2.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint372, viewCenter372)
    
    scaleAboutPoint373 = NXOpen.Point3d(-62.077894978139618, 1.3108454444855908, 0.0)
    viewCenter373 = NXOpen.Point3d(62.077894978139618, -1.3108454444855908, 0.0)
    modelingView2.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint373, viewCenter373)
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression121)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression120)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    theSession.UndoToMark(markId67, None)
    
    theSession.DeleteUndoMark(markId67, None)
    
    rotMatrix34 = NXOpen.Matrix3x3()
    
    rotMatrix34.Xx = 0.96024930862811009
    rotMatrix34.Xy = -0.1549031171501746
    rotMatrix34.Xz = -0.23222034703357775
    rotMatrix34.Yx = 0.278232148528334
    rotMatrix34.Yy = 0.59830261128535223
    rotMatrix34.Yz = 0.75141257432547137
    rotMatrix34.Zx = 0.022541889994927823
    rotMatrix34.Zy = -0.78615457107764963
    rotMatrix34.Zz = 0.61761869593558227
    translation34 = NXOpen.Point3d(-49.174278209989083, -33.549251165597354, -1.7087958546144106)
    modelingView2.SetRotationTranslationScale(rotMatrix34, translation34, 1.1303137779512185)
    
    # ----------------------------------------------
    #   Menu: Analysis->Measure...
    # ----------------------------------------------
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    theSession.SetUndoMarkName(markId68, "Measure Dialog")
    
    scCollector1 = workPart.ScCollectors.CreateCollector()
    
    scCollector1.SetMultiComponent()
    
    scaleAboutPoint374 = NXOpen.Point3d(-81.828292479280563, -31.417286017592357, 0.0)
    viewCenter374 = NXOpen.Point3d(81.828292479280492, 31.417286017592357, 0.0)
    modelingView2.ZoomAboutPoint(1.25, scaleAboutPoint374, viewCenter374)
    
    scaleAboutPoint375 = NXOpen.Point3d(-60.110944197918222, -21.120061474944254, 0.0)
    viewCenter375 = NXOpen.Point3d(60.110944197918158, 21.120061474944254, 0.0)
    modelingView2.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint375, viewCenter375)
    
    scaleAboutPoint376 = NXOpen.Point3d(-73.94410663456155, -25.922247398545718, 0.0)
    viewCenter376 = NXOpen.Point3d(73.944106634561479, 25.922247398545718, 0.0)
    modelingView2.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint376, viewCenter376)
    
    scaleAboutPoint377 = NXOpen.Point3d(-78.393893342376401, -36.285173489900025, 0.0)
    viewCenter377 = NXOpen.Point3d(78.393893342376373, 36.285173489900025, 0.0)
    modelingView2.ZoomAboutPoint(1.25, scaleAboutPoint377, viewCenter377)
    
    scaleAboutPoint378 = NXOpen.Point3d(-62.715114673901162, -29.028138791920021, 0.0)
    viewCenter378 = NXOpen.Point3d(62.715114673901084, 29.028138791920021, 0.0)
    modelingView2.ZoomAboutPoint(1.25, scaleAboutPoint378, viewCenter378)
    
    scaleAboutPoint379 = NXOpen.Point3d(-50.172091739120908, -23.222511033536019, 0.0)
    viewCenter379 = NXOpen.Point3d(50.172091739120908, 23.222511033536019, 0.0)
    modelingView2.ZoomAboutPoint(1.25, scaleAboutPoint379, viewCenter379)
    
    scaleAboutPoint380 = NXOpen.Point3d(-40.137673391296701, -18.578008826828817, 0.0)
    viewCenter380 = NXOpen.Point3d(40.137673391296723, 18.578008826828817, 0.0)
    modelingView2.ZoomAboutPoint(1.25, scaleAboutPoint380, viewCenter380)
    
    scaleAboutPoint381 = NXOpen.Point3d(-32.110138713037365, -14.862407061463054, 0.0)
    viewCenter381 = NXOpen.Point3d(32.110138713037401, 14.862407061463054, 0.0)
    modelingView2.ZoomAboutPoint(1.25, scaleAboutPoint381, viewCenter381)
    
    expression122 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    scaleAboutPoint382 = NXOpen.Point3d(-50.935854324223868, -14.434271878622544, 0.0)
    viewCenter382 = NXOpen.Point3d(50.935854324223889, 14.434271878622544, 0.0)
    modelingView2.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint382, viewCenter382)
    
    scaleAboutPoint383 = NXOpen.Point3d(-63.669817905279814, -18.042839848278181, 0.0)
    viewCenter383 = NXOpen.Point3d(63.669817905279864, 18.042839848278181, 0.0)
    modelingView2.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint383, viewCenter383)
    
    scaleAboutPoint384 = NXOpen.Point3d(-79.58727238159976, -22.553549810347722, 0.0)
    viewCenter384 = NXOpen.Point3d(79.587272381599831, 22.553549810347722, 0.0)
    modelingView2.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint384, viewCenter384)
    
    scCollector1.Destroy()
    
    workPart.Expressions.Delete(expression122)
    
    theSession.UndoToMark(markId68, None)
    
    theSession.DeleteUndoMark(markId68, None)
    
    # ----------------------------------------------
    #   Menu: Analysis->Measure...
    # ----------------------------------------------
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    theSession.SetUndoMarkName(markId69, "Measure Dialog")
    
    scCollector2 = workPart.ScCollectors.CreateCollector()
    
    scCollector2.SetMultiComponent()
    
    rotMatrix35 = NXOpen.Matrix3x3()
    
    rotMatrix35.Xx = 0.33694387403838372
    rotMatrix35.Xy = 0.92072266168467287
    rotMatrix35.Xz = -0.19682125395468125
    rotMatrix35.Yx = 0.90160515524428375
    rotMatrix35.Yy = -0.25530365571053731
    rotMatrix35.Yz = 0.34918216938693575
    rotMatrix35.Zx = 0.27125075075460675
    rotMatrix35.Zy = -0.29510985012554586
    rotMatrix35.Zz = -0.91615130113641008
    translation35 = NXOpen.Point3d(-62.872818064660237, -20.344180625262911, 28.966604086825431)
    modelingView2.SetRotationTranslationScale(rotMatrix35, translation35, 1.3842979750801381)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    scCollector2.Destroy()
    
    theSession.UndoToMark(markId69, None)
    
    theSession.DeleteUndoMark(markId69, None)
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin4, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane2
    
    expression123 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression124 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    theSession.SetUndoMarkName(markId70, "Create Sketch Dialog")
    
    rotMatrix36 = NXOpen.Matrix3x3()
    
    rotMatrix36.Xx = -0.25220572200536179
    rotMatrix36.Xy = 0.88271410284738216
    rotMatrix36.Xz = 0.39649474955173203
    rotMatrix36.Yx = 0.30489853625454749
    rotMatrix36.Yy = -0.31638046949371768
    rotMatrix36.Yz = 0.898298547874127
    rotMatrix36.Zx = 0.91838399179079189
    rotMatrix36.Zy = 0.34744670261389865
    rotMatrix36.Zz = -0.18934527315235425
    translation36 = NXOpen.Point3d(-74.739138134788533, -31.326508195006742, 14.430483527144276)
    modelingView2.SetRotationTranslationScale(rotMatrix36, translation36, 1.3842979750801381)
    
    rotMatrix37 = NXOpen.Matrix3x3()
    
    rotMatrix37.Xx = 0.66482965680685957
    rotMatrix37.Xy = 0.7230917274806441
    rotMatrix37.Xz = 0.18745634446219264
    rotMatrix37.Yx = -0.034518946588549759
    rotMatrix37.Yy = -0.22094020530527336
    rotMatrix37.Yz = 0.97467628882930912
    rotMatrix37.Zx = 0.74619700465526473
    rotMatrix37.Zy = -0.65446449814234842
    rotMatrix37.Zz = -0.12192723614841526
    translation37 = NXOpen.Point3d(-70.558370032997772, -32.85406301411038, 13.082122787065535)
    modelingView2.SetRotationTranslationScale(rotMatrix37, translation37, 1.3842979750801381)
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression124)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression123)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane2.DestroyPlane()
    
    theSession.UndoToMark(markId70, None)
    
    theSession.DeleteUndoMark(markId70, None)
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status6, partLoadStatus9 = theSession.Parts.SetActiveDisplay(part4, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # 桿子
    displayPart = theSession.Parts.Display # 桿子
    partLoadStatus9.Dispose()
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status7, partLoadStatus10 = theSession.Parts.SetActiveDisplay(part1, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # 本體12
    displayPart = theSession.Parts.Display # 本體12
    partLoadStatus10.Dispose()
    theSession.DeleteUndoMark(markId72, None)
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Enter Direct Sketch")
    
    theSession.SetUndoMarkVisibility(markId73, "Enter Direct Sketch", NXOpen.Session.MarkVisibility.Visible)
    
    sketchFeature1 = workPart.Features.FindObject("SKETCH(1)")
    sketch1 = sketchFeature1.FindObject("SKETCH_000")
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    modelingView2.Fit()
    
    modelingView2.Fit()
    
    modelingView2.Fit()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch2 = theSession.ActiveSketch
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status8, partLoadStatus11 = theSession.Parts.SetActiveDisplay(part4, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # 桿子
    displayPart = theSession.Parts.Display # 桿子
    partLoadStatus11.Dispose()
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Redefine Feature")
    
    editWithRollbackManager1 = workPart.Features.StartEditWithRollbackManager(extrude1, markId76)
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(extrude1)
    
    section1 = extrudeBuilder1.Section
    
    section1.PrepareMappingData()
    
    refs1 = section1.EvaluateAndAskOutputEntities()
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit5 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression125 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit5)
    
    unit6 = extrudeBuilder1.Offset.StartOffset.Units
    
    expression126 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit6)
    
    theSession.SetUndoMarkName(markId77, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("54")
    
    modelingView3 = part5.ModelingViews.FindObject("Trimetric")
    scaleAboutPoint385 = NXOpen.Point3d(-39.037472212620642, 2.0600249188718567, 0.0)
    viewCenter385 = NXOpen.Point3d(39.037472212620507, -2.0600249188718567, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint385, viewCenter385)
    
    scaleAboutPoint386 = NXOpen.Point3d(-49.569349610352639, -0.77250934457701437, 0.0)
    viewCenter386 = NXOpen.Point3d(49.569349610352596, 0.77250934457701437, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint386, viewCenter386)
    
    # ----------------------------------------------
    #   Menu: View->Operation->Rotate...
    # ----------------------------------------------
    matrix1 = NXOpen.Matrix3x3()
    
    matrix1.Xx = 0.0
    matrix1.Xy = 1.0
    matrix1.Xz = 0.0
    matrix1.Yx = 0.0
    matrix1.Yy = 0.0
    matrix1.Yz = 1.0
    matrix1.Zx = 1.0
    matrix1.Zy = 0.0
    matrix1.Zz = 0.0
    modelingView1.Orient(matrix1)
    
    expression127 = extrudeBuilder1.Limits.StartExtend.Value
    expression128 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression125)
    
    workPart.Expressions.Delete(expression126)
    
    theSession.UndoToMark(markId77, None)
    
    theSession.DeleteUndoMark(markId77, None)
    
    theSession.DeleteUndoMark(markId77, None)
    
    editWithRollbackManager1.UpdateFeature(True)
    
    editWithRollbackManager1.Stop()
    
    theSession.UndoToMarkWithStatus(markId76, None)
    
    theSession.DeleteUndoMarksUpToMark(markId76, None, False)
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status9, partLoadStatus12 = theSession.Parts.SetActiveDisplay(part5, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # assembly1
    displayPart = theSession.Parts.Display # assembly1
    partLoadStatus12.Dispose()
    theSession.DeleteUndoMark(markId78, None)
    
    modelingView3.Fit()
    
    scaleAboutPoint387 = NXOpen.Point3d(-5.5124390417441749, -53.88215063338685, 0.0)
    viewCenter387 = NXOpen.Point3d(5.5124390417441749, 53.88215063338685, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint387, viewCenter387)
    
    scaleAboutPoint388 = NXOpen.Point3d(-6.5023488696630318, -67.158588325474867, 0.0)
    viewCenter388 = NXOpen.Point3d(6.5023488696629999, 67.158588325474867, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint388, viewCenter388)
    
    rotMatrix38 = NXOpen.Matrix3x3()
    
    rotMatrix38.Xx = 0.96498868638087076
    rotMatrix38.Xy = -0.022653729048696274
    rotMatrix38.Xz = -0.26131139224517103
    rotMatrix38.Yx = 0.26210131055059621
    rotMatrix38.Yy = 0.045350912090338681
    rotMatrix38.Yz = 0.96397416862706187
    rotMatrix38.Zx = -0.0099868996481049781
    rotMatrix38.Zy = -0.99871422505778018
    rotMatrix38.Zz = 0.04970068915675166
    translation38 = NXOpen.Point3d(53.810352377765987, -35.205564827139469, 30.156929364216431)
    modelingView3.SetRotationTranslationScale(rotMatrix38, translation38, 1.0905033666243134)
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status10, partLoadStatus13 = theSession.Parts.SetActiveDisplay(part4, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # 桿子
    displayPart = theSession.Parts.Display # 桿子
    partLoadStatus13.Dispose()
    theSession.DeleteUndoMark(markId79, None)
    
    # ----------------------------------------------
    #   Menu: File->Save
    # ----------------------------------------------
    partSaveStatus1 = workPart.Save(NXOpen.BasePart.SaveComponents.TrueValue, NXOpen.BasePart.CloseAfterSave.FalseValue)
    
    partSaveStatus1.Dispose()
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status11, partLoadStatus14 = theSession.Parts.SetActiveDisplay(part5, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # assembly1
    displayPart = theSession.Parts.Display # assembly1
    partLoadStatus14.Dispose()
    theSession.DeleteUndoMark(markId80, None)
    
    scaleAboutPoint389 = NXOpen.Point3d(15.891934737422705, -48.524991564649596, 0.0)
    viewCenter389 = NXOpen.Point3d(-15.891934737422705, 48.524991564649596, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint389, viewCenter389)
    
    scaleAboutPoint390 = NXOpen.Point3d(20.168199619057511, -62.172645442207333, 0.0)
    viewCenter390 = NXOpen.Point3d(-20.168199619057486, 62.172645442207333, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint390, viewCenter390)
    
    rotMatrix39 = NXOpen.Matrix3x3()
    
    rotMatrix39.Xx = 0.98461534107927484
    rotMatrix39.Xy = 0.17376747112171106
    rotMatrix39.Xz = -0.018371066689412914
    rotMatrix39.Yx = -0.014307927936651066
    rotMatrix39.Yy = 0.18495973794683612
    rotMatrix39.Yz = 0.98264193811214673
    rotMatrix39.Zx = 0.17414911228456145
    rotMatrix39.Zy = -0.96726147515477978
    rotMatrix39.Zz = 0.18460044791900102
    translation39 = NXOpen.Point3d(57.474143091479121, -73.803832413127623, 33.738485482043878)
    modelingView3.SetRotationTranslationScale(rotMatrix39, translation39, 0.69792215463956064)
    
    scaleAboutPoint391 = NXOpen.Point3d(-2.0850582312935044, -75.062096326567413, 0.0)
    viewCenter391 = NXOpen.Point3d(2.0850582312935044, 75.062096326567413, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint391, viewCenter391)
    
    scaleAboutPoint392 = NXOpen.Point3d(1.0614841904766976, -56.107021496625961, 0.0)
    viewCenter392 = NXOpen.Point3d(-1.0614841904766976, 56.107021496625961, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint392, viewCenter392)
    
    scaleAboutPoint393 = NXOpen.Point3d(1.5770622258511058, -43.672492408184517, 0.0)
    viewCenter393 = NXOpen.Point3d(-1.5770622258511457, 43.672492408184517, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint393, viewCenter393)
    
    scaleAboutPoint394 = NXOpen.Point3d(19.701146575247677, -3.4937993926546587, 0.0)
    viewCenter394 = NXOpen.Point3d(-19.701146575247741, 3.4937993926546587, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint394, viewCenter394)
    
    scaleAboutPoint395 = NXOpen.Point3d(15.760917260198141, -2.7950395141237272, 0.0)
    viewCenter395 = NXOpen.Point3d(-15.760917260198193, 2.7950395141237272, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint395, viewCenter395)
    
    scaleAboutPoint396 = NXOpen.Point3d(12.608733808158513, -2.2360316112989818, 0.0)
    viewCenter396 = NXOpen.Point3d(-12.608733808158565, 2.2360316112989818, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint396, viewCenter396)
    
    rotMatrix40 = NXOpen.Matrix3x3()
    
    rotMatrix40.Xx = 0.96936681624882848
    rotMatrix40.Xy = -0.24514825353116607
    rotMatrix40.Xz = -0.015175946304115956
    rotMatrix40.Yx = 0.066108097927338808
    rotMatrix40.Yy = 0.20090027794929455
    rotMatrix40.Yz = 0.97737853348041237
    rotMatrix40.Zx = -0.23655378869093627
    rotMatrix40.Zy = -0.94844157021427034
    rotMatrix40.Zz = 0.21095234757036696
    translation40 = NXOpen.Point3d(52.206502773443567, -34.630055895858561, 19.779487669666551)
    modelingView3.SetRotationTranslationScale(rotMatrix40, translation40, 2.6623617349226403)
    
    scaleAboutPoint397 = NXOpen.Point3d(-11.180158056495259, -21.366524285746419, 0.0)
    viewCenter397 = NXOpen.Point3d(11.180158056495218, 21.366524285746419, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint397, viewCenter397)
    
    scaleAboutPoint398 = NXOpen.Point3d(-16.956573052351121, -26.956603313994172, 0.0)
    viewCenter398 = NXOpen.Point3d(16.956573052351089, 26.956603313994172, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint398, viewCenter398)
    
    rotMatrix41 = NXOpen.Matrix3x3()
    
    rotMatrix41.Xx = 0.88175962222216553
    rotMatrix41.Xy = -0.4708717655752731
    rotMatrix41.Xz = 0.027923986152490192
    rotMatrix41.Yx = 0.079213316629202959
    rotMatrix41.Yy = 0.20617391397172924
    rotMatrix41.Yz = 0.97530383351352357
    rotMatrix41.Zx = -0.46500023557759829
    rotMatrix41.Zy = -0.85777158823406963
    rotMatrix41.Zz = 0.21909514675404332
    translation41 = NXOpen.Point3d(44.374810532238968, -46.317026355698168, 11.155429938093578)
    modelingView3.SetRotationTranslationScale(rotMatrix41, translation41, 1.7039115103504898)
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status12, partLoadStatus15 = theSession.Parts.SetActiveDisplay(part4, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # 桿子
    displayPart = theSession.Parts.Display # 桿子
    partLoadStatus15.Dispose()
    theSession.DeleteUndoMark(markId81, None)
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Redefine Feature")
    
    editWithRollbackManager2 = workPart.Features.StartEditWithRollbackManager(extrude1, markId82)
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(extrude1)
    
    section1.PrepareMappingData()
    
    refs2 = section1.EvaluateAndAskOutputEntities()
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    unit7 = extrudeBuilder2.Draft.FrontDraftAngle.Units
    
    expression129 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit7)
    
    expression130 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit6)
    
    theSession.SetUndoMarkName(markId83, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("56")
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId84, None)
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    feature1 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId85, None)
    
    theSession.SetUndoMarkName(markId83, "Extrude")
    
    section1.CleanMappingData()
    
    expression131 = extrudeBuilder2.Limits.StartExtend.Value
    expression132 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression129)
    
    workPart.Expressions.Delete(expression130)
    
    theSession.DeleteUndoMark(markId83, None)
    
    editWithRollbackManager2.UpdateFeature(False)
    
    editWithRollbackManager2.Stop()
    
    editWithRollbackManager2.Destroy()
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Redefine Feature")
    
    extrude3 = feature1
    editWithRollbackManager3 = workPart.Features.StartEditWithRollbackManager(extrude3, markId86)
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(extrude3)
    
    section1.PrepareMappingData()
    
    refs3 = section1.EvaluateAndAskOutputEntities()
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression133 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit7)
    
    expression134 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit6)
    
    theSession.SetUndoMarkName(markId87, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId88, None)
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId89, None)
    
    expression135 = extrudeBuilder3.Limits.StartExtend.Value
    expression136 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression133)
    
    workPart.Expressions.Delete(expression134)
    
    theSession.UndoToMark(markId87, None)
    
    theSession.DeleteUndoMark(markId87, None)
    
    theSession.DeleteUndoMark(markId87, None)
    
    editWithRollbackManager3.UpdateFeature(True)
    
    editWithRollbackManager3.Stop()
    
    theSession.UndoToMarkWithStatus(markId86, None)
    
    theSession.DeleteUndoMarksUpToMark(markId86, None, False)
    
    # ----------------------------------------------
    #   Menu: File->Save
    # ----------------------------------------------
    partSaveStatus2 = workPart.Save(NXOpen.BasePart.SaveComponents.TrueValue, NXOpen.BasePart.CloseAfterSave.FalseValue)
    
    partSaveStatus2.Dispose()
    # ----------------------------------------------
    #   Menu: File->Save
    # ----------------------------------------------
    partSaveStatus3 = workPart.Save(NXOpen.BasePart.SaveComponents.TrueValue, NXOpen.BasePart.CloseAfterSave.FalseValue)
    
    partSaveStatus3.Dispose()
    # ----------------------------------------------
    #   Menu: File->Save
    # ----------------------------------------------
    partSaveStatus4 = workPart.Save(NXOpen.BasePart.SaveComponents.TrueValue, NXOpen.BasePart.CloseAfterSave.FalseValue)
    
    partSaveStatus4.Dispose()
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Change Displayed Part")
    
    status13, partLoadStatus16 = theSession.Parts.SetActiveDisplay(part5, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.UseLast)
    
    workPart = theSession.Parts.Work # assembly1
    displayPart = theSession.Parts.Display # assembly1
    partLoadStatus16.Dispose()
    theSession.DeleteUndoMark(markId90, None)
    
    scaleAboutPoint399 = NXOpen.Point3d(-43.400752455422506, -12.888237759570895, 0.0)
    viewCenter399 = NXOpen.Point3d(43.400752455422456, 12.888237759570895, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint399, viewCenter399)
    
    scaleAboutPoint400 = NXOpen.Point3d(-54.056840603019531, -16.692597098239482, 0.0)
    viewCenter400 = NXOpen.Point3d(54.056840603019467, 16.692597098239482, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint400, viewCenter400)
    
    scaleAboutPoint401 = NXOpen.Point3d(-67.571050753774372, -20.86574637279935, 0.0)
    viewCenter401 = NXOpen.Point3d(67.57105075377433, 20.86574637279935, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint401, viewCenter401)
    
    scaleAboutPoint402 = NXOpen.Point3d(-91.439280979636351, -73.697330938811533, 0.0)
    viewCenter402 = NXOpen.Point3d(91.439280979636308, 73.697330938811533, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint402, viewCenter402)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete13 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects24 = [NXOpen.TaggedObject.Null] * 1 
    objects24[0] = component10
    nErrs49 = theSession.UpdateManager.AddObjectsToDeleteList(objects24)
    
    notifyOnDelete14 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id7 = theSession.NewestVisibleUndoMark
    
    nErrs50 = theSession.UpdateManager.DoUpdate(id7)
    
    theSession.DeleteUndoMark(markId91, None)
    
    rotMatrix42 = NXOpen.Matrix3x3()
    
    rotMatrix42.Xx = 0.91365632965176213
    rotMatrix42.Xy = 0.29060623229947508
    rotMatrix42.Xz = -0.28421845301804249
    rotMatrix42.Yx = 0.13876584941155917
    rotMatrix42.Yy = 0.4342166945009151
    rotMatrix42.Yz = 0.89005612253036159
    rotMatrix42.Zx = 0.38206825348928719
    rotMatrix42.Zy = -0.85264522514665897
    rotMatrix42.Zz = 0.35639861070189777
    translation42 = NXOpen.Point3d(-41.008200986895993, -82.22114507176245, 36.425857279378164)
    modelingView3.SetRotationTranslationScale(rotMatrix42, translation42, 0.69792215463956087)
    
    scaleAboutPoint403 = NXOpen.Point3d(11.183494149665334, -51.178702040841181, 0.0)
    viewCenter403 = NXOpen.Point3d(-11.183494149665398, 51.178702040841181, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint403, viewCenter403)
    
    scaleAboutPoint404 = NXOpen.Point3d(5.6107021496625622, -38.516712054440319, 0.0)
    viewCenter404 = NXOpen.Point3d(-5.6107021496626128, 38.516712054440319, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint404, viewCenter404)
    
    scaleAboutPoint405 = NXOpen.Point3d(1.0918123102046202, -28.144495107496663, 0.0)
    viewCenter405 = NXOpen.Point3d(-1.0918123102046602, 28.144495107496663, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint405, viewCenter405)
    
    scaleAboutPoint406 = NXOpen.Point3d(-4.3672492408184809, -18.439496794566814, 0.0)
    viewCenter406 = NXOpen.Point3d(4.3672492408184169, 18.439496794566814, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint406, viewCenter406)
    
    scaleAboutPoint407 = NXOpen.Point3d(-48.369711591642613, -2.0186396490895162, 0.0)
    viewCenter407 = NXOpen.Point3d(48.369711591642556, 2.0186396490895162, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint407, viewCenter407)
    
    scaleAboutPoint408 = NXOpen.Point3d(-39.068441208530615, -1.4906877408660413, 0.0)
    viewCenter408 = NXOpen.Point3d(39.06844120853053, 1.4906877408660413, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint408, viewCenter408)
    
    scaleAboutPoint409 = NXOpen.Point3d(-31.254752966824487, -1.1925501926928328, 0.0)
    viewCenter409 = NXOpen.Point3d(31.254752966824423, 1.1925501926928328, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint409, viewCenter409)
    
    scaleAboutPoint410 = NXOpen.Point3d(-25.003802373459607, -0.95404015415426635, 0.0)
    viewCenter410 = NXOpen.Point3d(25.003802373459521, 0.95404015415426635, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint410, viewCenter410)
    
    # ----------------------------------------------
    #   Menu: Edit->Copy
    # ----------------------------------------------
    workPart.PmiManager.RestoreUnpastedObjects()
    
    # ----------------------------------------------
    #   Menu: Edit->Paste
    # ----------------------------------------------
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Component")
    
    option1 = theSession.Parts.LoadOptions.UsePartialLoading
    
    theSession.Parts.LoadOptions.UsePartialLoading = False
    
    componentsToOpen1 = [NXOpen.Assemblies.Component.Null] * 1 
    componentsToOpen1[0] = component12
    partLoadStatus17, openStatus1 = workPart.ComponentAssembly.OpenComponents(NXOpen.Assemblies.ComponentAssembly.OpenOption.ComponentOnly, componentsToOpen1)
    
    theSession.Parts.LoadOptions.UsePartialLoading = True
    
    partLoadStatus17.Dispose()
    theSession.DeleteUndoMark(markId93, None)
    
    scaleAboutPoint411 = NXOpen.Point3d(-4.8656047861867693, -5.5970355710383357, 0.0)
    viewCenter411 = NXOpen.Point3d(4.8656047861866805, 5.5970355710383357, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint411, viewCenter411)
    
    scaleAboutPoint412 = NXOpen.Point3d(-6.0820059827334365, -7.0757978099773817, 0.0)
    viewCenter412 = NXOpen.Point3d(6.0820059827333708, 7.0757978099773817, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint412, viewCenter412)
    
    scaleAboutPoint413 = NXOpen.Point3d(-7.6025074784167961, -8.8447472624717278, 0.0)
    viewCenter413 = NXOpen.Point3d(7.6025074784167224, 8.8447472624717278, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint413, viewCenter413)
    
    scaleAboutPoint414 = NXOpen.Point3d(-9.5031343480209749, -11.055934078089658, 0.0)
    viewCenter414 = NXOpen.Point3d(9.5031343480209234, 11.055934078089658, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint414, viewCenter414)
    
    scaleAboutPoint415 = NXOpen.Point3d(-15.605637287191295, -10.403758191460897, 0.0)
    viewCenter415 = NXOpen.Point3d(15.605637287191243, 10.403758191460897, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint415, viewCenter415)
    
    scaleAboutPoint416 = NXOpen.Point3d(-19.701146575247712, -13.004697739326122, 0.0)
    viewCenter416 = NXOpen.Point3d(19.701146575247648, 13.004697739326122, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint416, viewCenter416)
    
    scaleAboutPoint417 = NXOpen.Point3d(-24.626433219059603, -16.255872174157656, 0.0)
    viewCenter417 = NXOpen.Point3d(24.626433219059564, 16.255872174157656, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint417, viewCenter417)
    
    scaleAboutPoint418 = NXOpen.Point3d(-30.783041523824551, -20.623121414975891, 0.0)
    viewCenter418 = NXOpen.Point3d(30.783041523824448, 20.623121414975891, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint418, viewCenter418)
    
    scaleAboutPoint419 = NXOpen.Point3d(-32.792279455798322, -69.37557387758487, 0.0)
    viewCenter419 = NXOpen.Point3d(32.792279455798202, 69.37557387758487, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint419, viewCenter419)
    
    scaleAboutPoint420 = NXOpen.Point3d(-40.990349319747899, -87.193344217729248, 0.0)
    viewCenter420 = NXOpen.Point3d(40.990349319747743, 87.193344217729248, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint420, viewCenter420)
    
    scaleAboutPoint421 = NXOpen.Point3d(-51.237936649684869, -108.99168027216155, 0.0)
    viewCenter421 = NXOpen.Point3d(51.237936649684677, 108.99168027216155, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint421, viewCenter421)
    
    rotMatrix43 = NXOpen.Matrix3x3()
    
    rotMatrix43.Xx = 0.94530446295528159
    rotMatrix43.Xy = -0.32572952022499979
    rotMatrix43.Xz = 0.017313346609276345
    rotMatrix43.Yx = 0.15352975349028367
    rotMatrix43.Yy = 0.49113639140770693
    rotMatrix43.Yz = 0.85744600986197539
    rotMatrix43.Zx = -0.2877986919880538
    rotMatrix43.Zy = -0.80788942602871183
    rotMatrix43.Zz = 0.51428259566211054
    translation43 = NXOpen.Point3d(-34.51735423803644, -95.441587382853257, 10.715234718032299)
    modelingView3.SetRotationTranslationScale(rotMatrix43, translation43, 0.55833772371164914)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Components->Create New Component...
    # ----------------------------------------------
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create New Component")
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew3 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId95, "New Component File Dialog")
    
    theSession.UndoToMark(markId95, None)
    
    theSession.DeleteUndoMark(markId95, None)
    
    exists1 = theSession.DoesUndoMarkExist(markId94, "Create New Component")
    
    theSession.UndoToMark(markId94, "Create New Component")
    
    theSession.DeleteUndoMark(markId94, "Create New Component")
    
    # ----------------------------------------------
    #   Menu: Assemblies->Components->Add Component...
    # ----------------------------------------------
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder5 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner12 = workPart.ComponentAssembly.Positioner
    
    componentPositioner12.ClearNetwork()
    
    componentPositioner12.PrimaryArrangement = arrangement2
    
    componentPositioner12.BeginAssemblyConstraints()
    
    allowInterpartPositioning12 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression137 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression138 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression139 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression140 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression141 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression142 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression143 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression144 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network12 = componentPositioner12.EstablishNetwork()
    
    componentNetwork12 = network12
    componentNetwork12.MoveObjectsState = True
    
    componentNetwork12.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    theSession.SetUndoMarkName(markId96, "Add Component Dialog")
    
    componentNetwork12.MoveObjectsState = True
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    addComponentBuilder5.SetComponentAnchor(NXOpen.Assemblies.ProductInterface.InterfaceObject.Null)
    
    addComponentBuilder5.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder5.SetCount(4)
    
    addComponentBuilder5.SetScatterOption(True)
    
    addComponentBuilder5.ReferenceSet = "Unknown"
    
    addComponentBuilder5.Layer = -1
    
    addComponentBuilder5.ReferenceSet = "Use Model"
    
    addComponentBuilder5.Layer = -1
    
    partstouse8 = [NXOpen.BasePart.Null] * 1 
    partstouse8[0] = part4
    addComponentBuilder5.SetPartsToAdd(partstouse8)
    
    productinterfaceobjects8 = addComponentBuilder5.GetAllProductInterfaceObjects()
    
    addComponentBuilder5.SetCount(3)
    
    addComponentBuilder5.SetCount(2)
    
    addComponentBuilder5.SetCount(1)
    
    componentPositioner12.ClearNetwork()
    
    addComponentBuilder5.RemoveAddedComponents()
    
    addComponentBuilder5.Destroy()
    
    componentPositioner12.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner12.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId97, None)
    
    theSession.UndoToMark(markId96, None)
    
    theSession.DeleteUndoMark(markId96, None)
    
    rotMatrix44 = NXOpen.Matrix3x3()
    
    rotMatrix44.Xx = 0.91341310195224734
    rotMatrix44.Xy = 0.2667389673405467
    rotMatrix44.Xz = -0.30745215641473028
    rotMatrix44.Yx = 0.15014648781252832
    rotMatrix44.Yy = 0.48127419237615482
    rotMatrix44.Yz = 0.86361518279279714
    rotMatrix44.Zx = 0.3783286103105758
    rotMatrix44.Zy = -0.83500028446388741
    rotMatrix44.Zz = 0.39955223383894312
    translation44 = NXOpen.Point3d(-51.676680285817682, -95.294526879181589, 35.031819115804304)
    modelingView3.SetRotationTranslationScale(rotMatrix44, translation44, 0.55833772371164914)
    
    scaleAboutPoint422 = NXOpen.Point3d(-168.93710442185082, -133.63327755108523, 0.0)
    viewCenter422 = NXOpen.Point3d(168.93710442185065, 133.63327755108523, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint422, viewCenter422)
    
    scaleAboutPoint423 = NXOpen.Point3d(-135.14968353748066, -106.90662204086819, 0.0)
    viewCenter423 = NXOpen.Point3d(135.14968353748051, 106.90662204086819, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint423, viewCenter423)
    
    scaleAboutPoint424 = NXOpen.Point3d(-108.11974682998452, -84.918735238136492, 0.0)
    viewCenter424 = NXOpen.Point3d(108.11974682998442, 84.918735238136492, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint424, viewCenter424)
    
    scaleAboutPoint425 = NXOpen.Point3d(-86.4957974639876, -67.207113317039358, 0.0)
    viewCenter425 = NXOpen.Point3d(86.4957974639875, 67.207113317039358, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint425, viewCenter425)
    
    scaleAboutPoint426 = NXOpen.Point3d(-59.879839590777422, -43.284292475667264, 0.0)
    viewCenter426 = NXOpen.Point3d(59.879839590777323, 43.284292475667264, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint426, viewCenter426)
    
    scaleAboutPoint427 = NXOpen.Point3d(-47.903871672621932, -34.627433980533809, 0.0)
    viewCenter427 = NXOpen.Point3d(47.903871672621854, 34.627433980533809, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint427, viewCenter427)
    
    scaleAboutPoint428 = NXOpen.Point3d(-38.32309733809754, -27.701947184427045, 0.0)
    viewCenter428 = NXOpen.Point3d(38.323097338097497, 27.701947184427045, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint428, viewCenter428)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner13 = workPart.ComponentAssembly.Positioner
    
    componentPositioner13.ClearNetwork()
    
    componentPositioner13.PrimaryArrangement = arrangement2
    
    componentPositioner13.BeginAssemblyConstraints()
    
    allowInterpartPositioning13 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression145 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression146 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression147 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression148 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression149 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression150 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression151 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression152 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network13 = componentPositioner13.EstablishNetwork()
    
    componentNetwork13 = network13
    componentNetwork13.MoveObjectsState = True
    
    componentNetwork13.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork13.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId99, "Assembly Constraints Dialog")
    
    componentNetwork13.MoveObjectsState = True
    
    componentNetwork13.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    face9 = component9.FindObject("PROTO#.Features|EXTRUDE(2)|FACE 150 {(0,-1.5,-1.5) EXTRUDE(2)}")
    line17 = workPart.Lines.CreateFaceAxis(face9, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects25 = [NXOpen.TaggedObject.Null] * 1 
    objects25[0] = line17
    nErrs51 = theSession.UpdateManager.AddObjectsToDeleteList(objects25)
    
    scaleAboutPoint429 = NXOpen.Point3d(28.472135850541129, -4.2733048571493004, 0.0)
    viewCenter429 = NXOpen.Point3d(-28.472135850541193, 4.2733048571493004, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint429, viewCenter429)
    
    scaleAboutPoint430 = NXOpen.Point3d(22.777708680432912, -3.2596371933604131, 0.0)
    viewCenter430 = NXOpen.Point3d(-22.777708680432944, 3.2596371933604131, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint430, viewCenter430)
    
    scaleAboutPoint431 = NXOpen.Point3d(19.112604421556963, -2.0352856621957924, 0.0)
    viewCenter431 = NXOpen.Point3d(-19.112604421557002, 2.0352856621957924, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint431, viewCenter431)
    
    scaleAboutPoint432 = NXOpen.Point3d(16.307726368343438, -0.8649964064332053, 0.0)
    viewCenter432 = NXOpen.Point3d(-16.307726368343452, 0.8649964064332053, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint432, viewCenter432)
    
    scaleAboutPoint433 = NXOpen.Point3d(20.384657960429305, -1.0812455080415067, 0.0)
    viewCenter433 = NXOpen.Point3d(-20.38465796042933, 1.0812455080415067, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint433, viewCenter433)
    
    scaleAboutPoint434 = NXOpen.Point3d(25.480822450536628, -1.3515568850518831, 0.0)
    viewCenter434 = NXOpen.Point3d(-25.480822450536653, 1.3515568850518831, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint434, viewCenter434)
    
    scaleAboutPoint435 = NXOpen.Point3d(31.851028063170787, -1.689446106314854, 0.0)
    viewCenter435 = NXOpen.Point3d(-31.851028063170819, 1.689446106314854, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint435, viewCenter435)
    
    scaleAboutPoint436 = NXOpen.Point3d(50.372823243431199, 3.9751673089759918, 0.0)
    viewCenter436 = NXOpen.Point3d(-50.372823243431235, -3.9751673089759918, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint436, viewCenter436)
    
    scaleAboutPoint437 = NXOpen.Point3d(63.8977088923303, 5.2795190822339189, 0.0)
    viewCenter437 = NXOpen.Point3d(-63.897708892330321, -5.2795190822339189, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint437, viewCenter437)
    
    scaleAboutPoint438 = NXOpen.Point3d(81.036735912964375, 7.1816987515679998, 0.0)
    viewCenter438 = NXOpen.Point3d(-81.036735912964403, -7.1816987515679998, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint438, viewCenter438)
    
    scaleAboutPoint439 = NXOpen.Point3d(103.72216946943801, 10.43287318639965, 0.0)
    viewCenter439 = NXOpen.Point3d(-103.72216946943801, -10.43287318639965, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint439, viewCenter439)
    
    rotMatrix45 = NXOpen.Matrix3x3()
    
    rotMatrix45.Xx = 0.32961953458395482
    rotMatrix45.Xy = 0.74128888441698304
    rotMatrix45.Xz = -0.58467234607126395
    rotMatrix45.Yx = -0.12403630541549557
    rotMatrix45.Yy = 0.64791553834772431
    rotMatrix45.Yz = 0.75154537461582904
    rotMatrix45.Zx = 0.9359305301995049
    rotMatrix45.Zy = -0.17520343891430357
    rotMatrix45.Zz = 0.30551235266854693
    translation45 = NXOpen.Point3d(129.85715619717692, -1.3837221556465575, 31.171671259372921)
    modelingView3.SetRotationTranslationScale(rotMatrix45, translation45, 0.87240269329945219)
    
    scaleAboutPoint440 = NXOpen.Point3d(158.76770677558716, 51.557803537439803, 0.0)
    viewCenter440 = NXOpen.Point3d(-158.7677067755871, -51.557803537439803, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint440, viewCenter440)
    
    scaleAboutPoint441 = NXOpen.Point3d(130.65353978781837, 43.672492408184368, 0.0)
    viewCenter441 = NXOpen.Point3d(-130.65353978781835, -43.672492408184368, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint441, viewCenter441)
    
    scaleAboutPoint442 = NXOpen.Point3d(119.66262919842534, 40.566892948046885, 0.0)
    viewCenter442 = NXOpen.Point3d(-119.66262919842528, -40.566892948046885, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint442, viewCenter442)
    
    scaleAboutPoint443 = NXOpen.Point3d(149.57828649803164, 50.708616185058602, 0.0)
    viewCenter443 = NXOpen.Point3d(-149.57828649803162, -50.708616185058602, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint443, viewCenter443)
    
    scaleAboutPoint444 = NXOpen.Point3d(186.97285812253952, 63.385770231323249, 0.0)
    viewCenter444 = NXOpen.Point3d(-186.97285812253946, -63.385770231323249, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint444, viewCenter444)
    
    scaleAboutPoint445 = NXOpen.Point3d(233.71607265317436, 79.232212789154048, 0.0)
    viewCenter445 = NXOpen.Point3d(-233.71607265317436, -79.232212789154048, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint445, viewCenter445)
    
    scaleAboutPoint446 = NXOpen.Point3d(294.98835204095911, 97.618635374196813, 0.0)
    viewCenter446 = NXOpen.Point3d(-294.98835204095911, -97.618635374196813, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint446, viewCenter446)
    
    scaleAboutPoint447 = NXOpen.Point3d(374.0665548471199, 120.8386020408748, 0.0)
    viewCenter447 = NXOpen.Point3d(-374.0665548471199, -120.8386020408748, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint447, viewCenter447)
    
    scaleAboutPoint448 = NXOpen.Point3d(516.45174585484199, 168.0782025936185, 0.0)
    viewCenter448 = NXOpen.Point3d(-516.45174585484187, -168.0782025936185, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint448, viewCenter448)
    
    scaleAboutPoint449 = NXOpen.Point3d(645.56468231855251, 210.09775324202312, 0.0)
    viewCenter449 = NXOpen.Point3d(-645.5646823185524, -210.09775324202312, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint449, viewCenter449)
    
    scaleAboutPoint450 = NXOpen.Point3d(806.95585289819053, 262.62219155252888, 0.0)
    viewCenter450 = NXOpen.Point3d(-806.95585289819041, -262.62219155252888, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint450, viewCenter450)
    
    scaleAboutPoint451 = NXOpen.Point3d(921.9253695745457, 274.76991406927647, 0.0)
    viewCenter451 = NXOpen.Point3d(-921.9253695745457, -274.76991406927647, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint451, viewCenter451)
    
    scaleAboutPoint452 = NXOpen.Point3d(732.91259184373291, 219.81593125542119, 0.0)
    viewCenter452 = NXOpen.Point3d(-732.91259184373291, -219.81593125542119, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint452, viewCenter452)
    
    scaleAboutPoint453 = NXOpen.Point3d(627.97940781811872, 148.0865221089158, 0.0)
    viewCenter453 = NXOpen.Point3d(-627.97940781811872, -148.0865221089158, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint453, viewCenter453)
    
    # ----------------------------------------------
    #   Menu: Fit
    # ----------------------------------------------
    modelingView3.Fit()
    
    scaleAboutPoint454 = NXOpen.Point3d(70.585379354189271, 63.575745838646306, 0.0)
    viewCenter454 = NXOpen.Point3d(-70.585379354189271, -63.575745838646306, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint454, viewCenter454)
    
    scaleAboutPoint455 = NXOpen.Point3d(56.46830348335137, 48.513184516874794, 0.0)
    viewCenter455 = NXOpen.Point3d(-56.468303483351455, -48.513184516874794, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint455, viewCenter455)
    
    scaleAboutPoint456 = NXOpen.Point3d(25.143392405519961, 31.716146436838507, 0.0)
    viewCenter456 = NXOpen.Point3d(-25.143392405520032, -31.716146436838507, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint456, viewCenter456)
    
    scaleAboutPoint457 = NXOpen.Point3d(20.11471392441597, 25.539844235980574, 0.0)
    viewCenter457 = NXOpen.Point3d(-20.114713924416026, -25.539844235980574, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint457, viewCenter457)
    
    scaleAboutPoint458 = NXOpen.Point3d(16.091771139532778, 20.431875388784459, 0.0)
    viewCenter458 = NXOpen.Point3d(-16.091771139532831, -20.431875388784459, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint458, viewCenter458)
    
    scaleAboutPoint459 = NXOpen.Point3d(12.873416911626222, 16.345500311027571, 0.0)
    viewCenter459 = NXOpen.Point3d(-12.873416911626258, -16.345500311027571, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint459, viewCenter459)
    
    scaleAboutPoint460 = NXOpen.Point3d(17.990733675666881, 15.127600287852864, 0.0)
    viewCenter460 = NXOpen.Point3d(-17.990733675666874, -15.127600287852864, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint460, viewCenter460)
    
    scaleAboutPoint461 = NXOpen.Point3d(14.939573617608433, 12.170453564916695, 0.0)
    viewCenter461 = NXOpen.Point3d(-14.939573617608399, -12.170453564916695, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint461, viewCenter461)
    
    scaleAboutPoint462 = NXOpen.Point3d(12.061056229501757, 9.7910615196408823, 0.0)
    viewCenter462 = NXOpen.Point3d(-12.061056229501695, -9.7910615196408823, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint462, viewCenter462)
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint7 = componentPositioner13.CreateConstraint(True)
    
    componentConstraint7 = constraint7
    componentConstraint7.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge8 = component9.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 130 * 150 {(-0.75,-3,-1.2990381056767)(1.5,-3,0)(-0.75,-3,1.2990381056767) EXTRUDE(2)}")
    constraintReference13 = componentConstraint7.CreateConstraintReference(component9, edge8, False, False, False)
    
    helpPoint13 = NXOpen.Point3d(-111.74162076582327, -35.950143111867689, -1.1210656531081751)
    constraintReference13.HelpPoint = helpPoint13
    
    edge9 = component12.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 120 * 140 {(-0.75,0,-1.2990381056767)(1.5,0,0)(-0.75,0,1.2990381056767) EXTRUDE(2)}")
    constraintReference14 = componentConstraint7.CreateConstraintReference(component12, edge9, False, False, False)
    
    helpPoint14 = NXOpen.Point3d(-52.39955928289961, 134.96139933814229, 3.1761550755589689)
    constraintReference14.HelpPoint = helpPoint14
    
    constraintReference14.SetFixHint(True)
    
    componentNetwork13.Solve()
    
    scaleAboutPoint463 = NXOpen.Point3d(-4.3102550153502515, -8.1391617548746478, 0.0)
    viewCenter463 = NXOpen.Point3d(4.3102550153503021, 8.1391617548746478, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint463, viewCenter463)
    
    scaleAboutPoint464 = NXOpen.Point3d(-5.387818769187807, -10.119253525885792, 0.0)
    viewCenter464 = NXOpen.Point3d(5.3878187691878656, 10.119253525885792, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint464, viewCenter464)
    
    scaleAboutPoint465 = NXOpen.Point3d(-6.734773461484771, -12.649066907357243, 0.0)
    viewCenter465 = NXOpen.Point3d(6.7347734614848216, 12.649066907357243, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint465, viewCenter465)
    
    scaleAboutPoint466 = NXOpen.Point3d(-8.7603335000277927, -14.614800278095199, 0.0)
    viewCenter466 = NXOpen.Point3d(8.7603335000278335, 14.614800278095199, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint466, viewCenter466)
    
    scaleAboutPoint467 = NXOpen.Point3d(-10.95041687503474, -18.268500347619, 0.0)
    viewCenter467 = NXOpen.Point3d(10.950416875034794, 18.268500347619, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint467, viewCenter467)
    
    scaleAboutPoint468 = NXOpen.Point3d(-13.688021093793408, -22.835625434523756, 0.0)
    viewCenter468 = NXOpen.Point3d(13.688021093793484, 22.835625434523756, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint468, viewCenter468)
    
    scaleAboutPoint469 = NXOpen.Point3d(-17.110026367241797, -28.544531793154686, 0.0)
    viewCenter469 = NXOpen.Point3d(17.110026367241879, 28.544531793154686, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint469, viewCenter469)
    
    scaleAboutPoint470 = NXOpen.Point3d(-22.222168391600597, -38.393229897225467, 0.0)
    viewCenter470 = NXOpen.Point3d(22.2221683916007, 38.393229897225467, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint470, viewCenter470)
    
    scaleAboutPoint471 = NXOpen.Point3d(-28.03853406217215, -48.513184516874858, 0.0)
    viewCenter471 = NXOpen.Point3d(28.038534062172261, 48.513184516874858, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint471, viewCenter471)
    
    scaleAboutPoint472 = NXOpen.Point3d(-35.048167577715219, -60.641480646093576, 0.0)
    viewCenter472 = NXOpen.Point3d(35.048167577715326, 60.641480646093576, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint472, viewCenter472)
    
    rotMatrix46 = NXOpen.Matrix3x3()
    
    rotMatrix46.Xx = 0.10451635101161756
    rotMatrix46.Xy = -0.99452094158500359
    rotMatrix46.Xz = 0.0021045474785989175
    rotMatrix46.Yx = 0.43219950612874347
    rotMatrix46.Yy = 0.047326438870991243
    rotMatrix46.Yz = 0.9005352825324795
    rotMatrix46.Zx = -0.89570079785231915
    rotMatrix46.Zy = -0.093211077306636358
    rotMatrix46.Zz = 0.43477784648490275
    translation46 = NXOpen.Point3d(-62.031054347746739, -114.51815160995758, -36.435762460491695)
    modelingView3.SetRotationTranslationScale(rotMatrix46, translation46, 0.64922557266972569)
    
    rotMatrix47 = NXOpen.Matrix3x3()
    
    rotMatrix47.Xx = 0.33285059145778428
    rotMatrix47.Xy = -0.87867418541413733
    rotMatrix47.Xz = 0.34226036821840605
    rotMatrix47.Yx = -0.059902916000344537
    rotMatrix47.Yy = 0.34252073772869573
    rotMatrix47.Yz = 0.93759862674837435
    rotMatrix47.Zx = -0.94107498342101026
    rotMatrix47.Zy = -0.33258265155083849
    rotMatrix47.Zz = 0.06137308421901861
    translation47 = NXOpen.Point3d(-63.822609782830057, -141.51758151126947, -23.825888128188755)
    modelingView3.SetRotationTranslationScale(rotMatrix47, translation47, 0.64922557266972569)
    
    scaleAboutPoint473 = NXOpen.Point3d(-83.748819037447447, -104.3294290685477, 0.0)
    viewCenter473 = NXOpen.Point3d(83.748819037447575, 104.3294290685477, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint473, viewCenter473)
    
    scaleAboutPoint474 = NXOpen.Point3d(-102.13891859494048, -130.41178633568464, 0.0)
    viewCenter474 = NXOpen.Point3d(102.13891859494055, 130.41178633568464, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint474, viewCenter474)
    
    scaleAboutPoint475 = NXOpen.Point3d(-126.40009564274119, -163.01473291960579, 0.0)
    viewCenter475 = NXOpen.Point3d(126.40009564274131, 163.01473291960579, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint475, viewCenter475)
    
    scaleAboutPoint476 = NXOpen.Point3d(-151.63235654875444, -203.7684161495072, 0.0)
    viewCenter476 = NXOpen.Point3d(151.63235654875444, 203.7684161495072, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint476, viewCenter476)
    
    scaleAboutPoint477 = NXOpen.Point3d(-135.81244533402213, -343.26222447060604, 0.0)
    viewCenter477 = NXOpen.Point3d(135.81244533402213, 343.26222447060604, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint477, viewCenter477)
    
    scaleAboutPoint478 = NXOpen.Point3d(-172.25296409122762, -430.32148430010653, 0.0)
    viewCenter478 = NXOpen.Point3d(172.25296409122762, 430.32148430010653, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint478, viewCenter478)
    
    rotMatrix48 = NXOpen.Matrix3x3()
    
    rotMatrix48.Xx = -0.084429701617209488
    rotMatrix48.Xy = 0.84248036537810367
    rotMatrix48.Xz = -0.53206997607194328
    rotMatrix48.Yx = 0.77751466701802996
    rotMatrix48.Yy = 0.38965327813591905
    rotMatrix48.Yz = 0.49360030936960231
    rotMatrix48.Zx = 0.62317137936258349
    rotMatrix48.Zy = -0.37201768343763281
    rotMatrix48.Zz = -0.68793915076336853
    translation48 = NXOpen.Point3d(-318.24847882198003, -453.1066468100716, 39.615843489154891)
    modelingView3.SetRotationTranslationScale(rotMatrix48, translation48, 0.17019058852193264)
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    theSession.DeleteUndoMark(markId102, None)
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs52 = theSession.UpdateManager.DoUpdate(markId100)
    
    componentNetwork13.Solve()
    
    componentPositioner13.ClearNetwork()
    
    nErrs53 = theSession.UpdateManager.AddToDeleteList(componentNetwork13)
    
    componentPositioner13.DeleteNonPersistentConstraints()
    
    nErrs54 = theSession.UpdateManager.DoUpdate(markId100)
    
    theSession.DeleteUndoMark(markId103, None)
    
    theSession.SetUndoMarkName(markId99, "Assembly Constraints")
    
    componentPositioner13.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner13.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId100, None)
    
    theSession.DeleteUndoMark(markId101, None)
    
    theSession.DeleteUndoMark(markId98, None)
    
    rotMatrix49 = NXOpen.Matrix3x3()
    
    rotMatrix49.Xx = 0.89482814034128699
    rotMatrix49.Xy = 0.39571781755266527
    rotMatrix49.Xz = 0.20661560474635851
    rotMatrix49.Yx = -0.42057287750473676
    rotMatrix49.Yy = 0.59212646107401112
    rotMatrix49.Yz = 0.68738977938528145
    rotMatrix49.Zx = 0.14966981646522504
    rotMatrix49.Zy = -0.70199263740249951
    rotMatrix49.Zz = 0.69627960121774413
    translation49 = NXOpen.Point3d(-287.73677705026779, -494.70522602641603, 18.089832413228088)
    modelingView3.SetRotationTranslationScale(rotMatrix49, translation49, 0.17019058852193264)
    
    # ----------------------------------------------
    #   Menu: Fit
    # ----------------------------------------------
    modelingView3.Fit()
    
    # ----------------------------------------------
    #   Menu: Snap View
    # ----------------------------------------------
    modelingView3.SnapToClosestCannedOrientation()
    
    rotMatrix50 = NXOpen.Matrix3x3()
    
    rotMatrix50.Xx = -0.21008114499649844
    rotMatrix50.Xy = -0.9758582695379967
    rotMatrix50.Xz = 0.059720601899717021
    rotMatrix50.Yx = 0.18616723938450913
    rotMatrix50.Yy = 0.020037889041760917
    rotMatrix50.Yz = 0.98231371871856665
    rotMatrix50.Zx = -0.95979564048650945
    rotMatrix50.Zy = 0.21748361036421654
    rotMatrix50.Zz = 0.17746325739722743
    translation50 = NXOpen.Point3d(27.525211759219772, -9.9166193721704516, -28.878824765092993)
    modelingView3.SetRotationTranslationScale(rotMatrix50, translation50, 0.73820178148200288)
    
    scaleAboutPoint479 = NXOpen.Point3d(29.927736409658031, -64.156464878189212, 0.0)
    viewCenter479 = NXOpen.Point3d(-29.927736409658031, 64.156464878189212, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint479, viewCenter479)
    
    scaleAboutPoint480 = NXOpen.Point3d(37.409670512072537, -80.643601103868775, 0.0)
    viewCenter480 = NXOpen.Point3d(-37.409670512072537, 80.643601103868775, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint480, viewCenter480)
    
    scaleAboutPoint481 = NXOpen.Point3d(45.642038124759146, -101.36452638750205, 0.0)
    viewCenter481 = NXOpen.Point3d(-45.642038124759146, 101.36452638750205, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint481, viewCenter481)
    
    scaleAboutPoint482 = NXOpen.Point3d(57.052547655948864, -128.10572050354179, 0.0)
    viewCenter482 = NXOpen.Point3d(-57.052547655948864, 128.10572050354179, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint482, viewCenter482)
    
    scaleAboutPoint483 = NXOpen.Point3d(63.440332899636488, -154.0068771080831, 0.0)
    viewCenter483 = NXOpen.Point3d(-63.440332899636488, 154.0068771080831, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint483, viewCenter483)
    
    scaleAboutPoint484 = NXOpen.Point3d(79.30041612454562, -192.50859638510391, 0.0)
    viewCenter484 = NXOpen.Point3d(-79.30041612454562, 192.50859638510391, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint484, viewCenter484)
    
    scaleAboutPoint485 = NXOpen.Point3d(99.125520155682139, -240.63574548137987, 0.0)
    viewCenter485 = NXOpen.Point3d(-99.125520155682139, 240.63574548137987, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint485, viewCenter485)
    
    scaleAboutPoint486 = NXOpen.Point3d(123.90690019460253, -300.79468185172482, 0.0)
    viewCenter486 = NXOpen.Point3d(-123.90690019460253, 300.79468185172482, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint486, viewCenter486)
    
    scaleAboutPoint487 = NXOpen.Point3d(210.42809774428167, -450.7647576045016, 0.0)
    viewCenter487 = NXOpen.Point3d(-210.42809774428167, 450.7647576045016, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint487, viewCenter487)
    
    scaleAboutPoint488 = NXOpen.Point3d(168.34247819542534, -360.61180608360127, 0.0)
    viewCenter488 = NXOpen.Point3d(-168.34247819542534, 360.61180608360127, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint488, viewCenter488)
    
    scaleAboutPoint489 = NXOpen.Point3d(136.04123111021158, -288.489444866881, 0.0)
    viewCenter489 = NXOpen.Point3d(-136.04123111021204, 288.489444866881, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint489, viewCenter489)
    
    scaleAboutPoint490 = NXOpen.Point3d(109.92678373126616, -229.69775705040843, 0.0)
    viewCenter490 = NXOpen.Point3d(-109.9267837312667, 229.69775705040843, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint490, viewCenter490)
    
    scaleAboutPoint491 = NXOpen.Point3d(86.191348836057486, -166.25742415077141, 0.0)
    viewCenter491 = NXOpen.Point3d(-86.191348836058069, 166.25742415077141, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint491, viewCenter491)
    
    scaleAboutPoint492 = NXOpen.Point3d(16.450734600181381, -45.502031872843048, 0.0)
    viewCenter492 = NXOpen.Point3d(-16.450734600181843, 45.502031872843048, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint492, viewCenter492)
    
    scaleAboutPoint493 = NXOpen.Point3d(12.600562672479223, -34.161525467610907, 0.0)
    viewCenter493 = NXOpen.Point3d(-12.600562672479683, 34.161525467610907, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint493, viewCenter493)
    
    scaleAboutPoint494 = NXOpen.Point3d(8.2883701134529968, -21.056940288232315, 0.0)
    viewCenter494 = NXOpen.Point3d(-8.2883701134534391, 21.056940288232315, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint494, viewCenter494)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Components->Add Component...
    # ----------------------------------------------
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder6 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner14 = workPart.ComponentAssembly.Positioner
    
    componentPositioner14.ClearNetwork()
    
    componentPositioner14.PrimaryArrangement = arrangement2
    
    componentPositioner14.BeginAssemblyConstraints()
    
    allowInterpartPositioning14 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression153 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression154 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression155 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression156 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression157 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression158 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression159 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression160 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network14 = componentPositioner14.EstablishNetwork()
    
    componentNetwork14 = network14
    componentNetwork14.MoveObjectsState = True
    
    componentNetwork14.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    theSession.SetUndoMarkName(markId104, "Add Component Dialog")
    
    componentNetwork14.MoveObjectsState = True
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    addComponentBuilder6.SetComponentAnchor(NXOpen.Assemblies.ProductInterface.InterfaceObject.Null)
    
    addComponentBuilder6.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder6.SetCount(4)
    
    addComponentBuilder6.SetScatterOption(True)
    
    addComponentBuilder6.ReferenceSet = "Unknown"
    
    addComponentBuilder6.Layer = -1
    
    addComponentBuilder6.SetCount(3)
    
    addComponentBuilder6.SetCount(2)
    
    addComponentBuilder6.SetCount(1)
    
    addComponentBuilder6.ReferenceSet = "Use Model"
    
    addComponentBuilder6.Layer = -1
    
    partstouse9 = [NXOpen.BasePart.Null] * 1 
    partstouse9[0] = part4
    addComponentBuilder6.SetPartsToAdd(partstouse9)
    
    productinterfaceobjects9 = addComponentBuilder6.GetAllProductInterfaceObjects()
    
    coordinates3 = NXOpen.Point3d(-82.493603536192921, 72.295314117283752, 0.0)
    point15 = workPart.Points.CreatePoint(coordinates3)
    
    coordinates4 = NXOpen.Point3d(-82.493603536192921, 72.295314117283752, 0.0)
    point16 = workPart.Points.CreatePoint(coordinates4)
    
    origin5 = NXOpen.Point3d(-82.493603536192921, 72.295314117283752, 0.0)
    vector3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction13 = workPart.Directions.CreateDirection(origin5, vector3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin6 = NXOpen.Point3d(-82.493603536192921, 72.295314117283752, 0.0)
    vector4 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction14 = workPart.Directions.CreateDirection(origin6, vector4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin7 = NXOpen.Point3d(-82.493603536192921, 72.295314117283752, 0.0)
    matrix2 = NXOpen.Matrix3x3()
    
    matrix2.Xx = 1.0
    matrix2.Xy = 0.0
    matrix2.Xz = 0.0
    matrix2.Yx = 0.0
    matrix2.Yy = 1.0
    matrix2.Yz = 0.0
    matrix2.Zx = 0.0
    matrix2.Zy = 0.0
    matrix2.Zz = 1.0
    plane3 = workPart.Planes.CreateFixedTypePlane(origin7, matrix2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform9 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane3, direction14, point16, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point17 = NXOpen.Point3d(-82.493603536192921, 72.295314117283752, 0.0)
    orientation2 = NXOpen.Matrix3x3()
    
    orientation2.Xx = 1.0
    orientation2.Xy = 0.0
    orientation2.Xz = 0.0
    orientation2.Yx = 0.0
    orientation2.Yy = 1.0
    orientation2.Yz = 0.0
    orientation2.Zx = 0.0
    orientation2.Zy = 0.0
    orientation2.Zz = 1.0
    addComponentBuilder6.SetInitialLocationAndOrientation(point17, orientation2)
    
    movableObjects8 = [NXOpen.NXObject.Null] * 1 
    component18 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT 桿子 1")
    movableObjects8[0] = component18
    componentNetwork14.SetMovingGroup(movableObjects8)
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Add Component")
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "AddComponent on_apply")
    
    componentNetwork14.Solve()
    
    componentPositioner14.ClearNetwork()
    
    nErrs55 = theSession.UpdateManager.AddToDeleteList(componentNetwork14)
    
    nErrs56 = theSession.UpdateManager.DoUpdate(markId105)
    
    componentPositioner14.EndAssemblyConstraints()
    
    logicalobjects2 = addComponentBuilder6.GetLogicalObjectsHavingUnassignedRequiredAttributes()
    
    addComponentBuilder6.ComponentName = "桿子"
    
    nXObject11 = addComponentBuilder6.Commit()
    
    errorList2 = addComponentBuilder6.GetOperationFailures()
    
    errorList2.Dispose()
    theSession.DeleteUndoMark(markId106, None)
    
    theSession.SetUndoMarkName(markId104, "Add Component")
    
    addComponentBuilder6.Destroy()
    
    workPart.Points.DeletePoint(point15)
    
    componentPositioner14.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    theSession.DeleteUndoMark(markId105, None)
    
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder7 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner15 = workPart.ComponentAssembly.Positioner
    
    componentPositioner15.ClearNetwork()
    
    componentPositioner15.PrimaryArrangement = arrangement2
    
    componentPositioner15.BeginAssemblyConstraints()
    
    allowInterpartPositioning15 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression161 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression162 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression163 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression164 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression165 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression166 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression167 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression168 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network15 = componentPositioner15.EstablishNetwork()
    
    componentNetwork15 = network15
    componentNetwork15.MoveObjectsState = True
    
    componentNetwork15.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    theSession.SetUndoMarkName(markId108, "Add Component Dialog")
    
    componentNetwork15.MoveObjectsState = True
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    addComponentBuilder7.SetComponentAnchor(NXOpen.Assemblies.ProductInterface.InterfaceObject.Null)
    
    addComponentBuilder7.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder7.SetCount(1)
    
    addComponentBuilder7.SetScatterOption(True)
    
    addComponentBuilder7.ReferenceSet = "Unknown"
    
    addComponentBuilder7.Layer = -1
    
    # ----------------------------------------------
    #   Dialog Begin Add Component
    # ----------------------------------------------
    componentPositioner15.ClearNetwork()
    
    addComponentBuilder7.RemoveAddedComponents()
    
    addComponentBuilder7.Destroy()
    
    componentPositioner15.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner15.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId109, None)
    
    theSession.UndoToMark(markId108, None)
    
    theSession.DeleteUndoMark(markId108, None)
    
    rotMatrix51 = NXOpen.Matrix3x3()
    
    rotMatrix51.Xx = 0.61545347582764987
    rotMatrix51.Xy = -0.69885113102027774
    rotMatrix51.Xz = -0.36445042977521752
    rotMatrix51.Yx = 0.55932266796160912
    rotMatrix51.Yy = 0.061468926945553747
    rotMatrix51.Yz = 0.82666784389164871
    rotMatrix51.Zx = -0.55531538083864518
    rotMatrix51.Zy = -0.71262098459969492
    rotMatrix51.Zz = 0.42871454385428731
    translation51 = NXOpen.Point3d(-5.8131480630004475, -7.2056045615918656, 50.62047740938074)
    modelingView3.SetRotationTranslationScale(rotMatrix51, translation51, 0.73820178148200288)
    
    scaleAboutPoint495 = NXOpen.Point3d(-67.561416924797015, -53.762400735912678, 0.0)
    viewCenter495 = NXOpen.Point3d(67.561416924796546, 53.762400735912678, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint495, viewCenter495)
    
    scaleAboutPoint496 = NXOpen.Point3d(-54.049133539837648, -43.296653392654783, 0.0)
    viewCenter496 = NXOpen.Point3d(54.049133539837179, 43.296653392654783, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint496, viewCenter496)
    
    scaleAboutPoint497 = NXOpen.Point3d(-43.468693075010073, -34.637322714123833, 0.0)
    viewCenter497 = NXOpen.Point3d(43.468693075009618, 34.637322714123833, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint497, viewCenter497)
    
    scaleAboutPoint498 = NXOpen.Point3d(-34.774954460008111, -28.076876160323096, 0.0)
    viewCenter498 = NXOpen.Point3d(34.774954460007628, 28.076876160323096, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint498, viewCenter498)
    
    scaleAboutPoint499 = NXOpen.Point3d(-28.407192350444639, -20.112585798505819, 0.0)
    viewCenter499 = NXOpen.Point3d(28.407192350444191, 20.112585798505819, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint499, viewCenter499)
    
    scaleAboutPoint500 = NXOpen.Point3d(-22.490862367380508, -14.798165317440674, 0.0)
    viewCenter500 = NXOpen.Point3d(22.490862367380064, 14.798165317440983, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint500, viewCenter500)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner16 = workPart.ComponentAssembly.Positioner
    
    componentPositioner16.ClearNetwork()
    
    componentPositioner16.PrimaryArrangement = arrangement2
    
    componentPositioner16.BeginAssemblyConstraints()
    
    allowInterpartPositioning16 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression169 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression170 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression171 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression172 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression173 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression174 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression175 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression176 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network16 = componentPositioner16.EstablishNetwork()
    
    componentNetwork16 = network16
    componentNetwork16.MoveObjectsState = True
    
    componentNetwork16.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork16.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId111, "Assembly Constraints Dialog")
    
    componentNetwork16.MoveObjectsState = True
    
    componentNetwork16.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    scaleAboutPoint501 = NXOpen.Point3d(55.105548943993675, -2.3489151297524522, 0.0)
    viewCenter501 = NXOpen.Point3d(-55.105548943994123, 2.3489151297527004, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint501, viewCenter501)
    
    scaleAboutPoint502 = NXOpen.Point3d(44.309935007651113, -1.7288015354977175, 0.0)
    viewCenter502 = NXOpen.Point3d(-44.309935007651553, 1.7288015354979156, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint502, viewCenter502)
    
    scaleAboutPoint503 = NXOpen.Point3d(55.387418759563957, -2.161001919372147, 0.0)
    viewCenter503 = NXOpen.Point3d(-55.387418759564412, 2.1610019193723948, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint503, viewCenter503)
    
    scaleAboutPoint504 = NXOpen.Point3d(69.234273449454989, -2.7012523992153388, 0.0)
    viewCenter504 = NXOpen.Point3d(-69.234273449455458, 2.7012523992156487, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint504, viewCenter504)
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint8 = componentPositioner16.CreateConstraint(True)
    
    componentConstraint8 = constraint8
    componentConstraint8.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    component19 = nXObject11
    edge10 = component19.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 130 * 140 {(-0.75,-56,-1.2990381056767)(1.5,-56,0)(-0.75,-56,1.2990381056767) EXTRUDE(2)}")
    constraintReference15 = componentConstraint8.CreateConstraintReference(component19, edge10, False, False, False)
    
    helpPoint15 = NXOpen.Point3d(-83.17027321946189, 16.295314117283752, -1.3387001679781272)
    constraintReference15.HelpPoint = helpPoint15
    
    edge11 = component1.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 130 * 150 {(-0.75,-3,-1.2990381056767)(1.5,-3,0)(-0.75,-3,1.2990381056767) EXTRUDE(2)}")
    constraintReference16 = componentConstraint8.CreateConstraintReference(component1, edge11, False, False, False)
    
    helpPoint16 = NXOpen.Point3d(-5.4212292666832456, -35.950143111867703, 1.1453203263135328)
    constraintReference16.HelpPoint = helpPoint16
    
    constraintReference16.SetFixHint(True)
    
    componentNetwork16.Solve()
    
    rotMatrix52 = NXOpen.Matrix3x3()
    
    rotMatrix52.Xx = -0.45753380809258337
    rotMatrix52.Xy = -0.5886663650631927
    rotMatrix52.Xz = 0.66643433667210095
    rotMatrix52.Yx = 0.83107441840983864
    rotMatrix52.Yy = -0.016587654477492584
    rotMatrix52.Yz = 0.55591380697341941
    rotMatrix52.Zx = -0.31619317753083043
    rotMatrix52.Zy = 0.80820588983390851
    rotMatrix52.Zz = 0.49681496970273858
    translation52 = NXOpen.Point3d(27.955348173920946, 44.529258568913917, 1.996490991103677)
    modelingView3.SetRotationTranslationScale(rotMatrix52, translation52, 1.802250443071296)
    
    scaleAboutPoint505 = NXOpen.Point3d(53.217608408455057, 31.269932664830236, 0.0)
    viewCenter505 = NXOpen.Point3d(-53.217608408455511, -31.269932664830236, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint505, viewCenter505)
    
    scaleAboutPoint506 = NXOpen.Point3d(42.456640970276382, 25.250837644839422, 0.0)
    viewCenter506 = NXOpen.Point3d(-42.456640970276858, -25.250837644839113, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint506, viewCenter506)
    
    scaleAboutPoint507 = NXOpen.Point3d(33.871356171030982, 20.482539931441995, 0.0)
    viewCenter507 = NXOpen.Point3d(-33.871356171031429, -20.482539931441746, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint507, viewCenter507)
    
    face10 = component19.FindObject("PROTO#.Features|EXTRUDE(2)|FACE 140 {(0,-28,-1.5) EXTRUDE(2)}")
    line18 = workPart.Lines.CreateFaceAxis(face10, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint508 = NXOpen.Point3d(25.668944537935193, 22.0985935407117, 0.0)
    viewCenter508 = NXOpen.Point3d(-25.668944537935651, -22.098593540711502, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint508, viewCenter508)
    
    scaleAboutPoint509 = NXOpen.Point3d(20.655420084991444, 17.678874832569363, 0.0)
    viewCenter509 = NXOpen.Point3d(-20.655420084991903, -17.678874832569203, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint509, viewCenter509)
    
    scaleAboutPoint510 = NXOpen.Point3d(16.572441849850442, 14.191205647912849, 0.0)
    viewCenter510 = NXOpen.Point3d(-16.572441849850904, -14.191205647912721, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint510, viewCenter510)
    
    scaleAboutPoint511 = NXOpen.Point3d(13.334922730852034, 11.468418394787884, 0.0)
    viewCenter511 = NXOpen.Point3d(-13.334922730852494, -11.468418394787681, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint511, viewCenter511)
    
    scaleAboutPoint512 = NXOpen.Point3d(10.729513585458973, 9.2363101166077275, 0.0)
    viewCenter512 = NXOpen.Point3d(-10.729513585459424, -9.2363101166075658, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint512, viewCenter512)
    
    scaleAboutPoint513 = NXOpen.Point3d(8.5097203874342675, 7.4629385742190193, 0.0)
    viewCenter513 = NXOpen.Point3d(-8.5097203874347223, -7.4629385742188887, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint513, viewCenter513)
    
    scaleAboutPoint514 = NXOpen.Point3d(6.8077763099473669, 5.9703508593752401, 0.0)
    viewCenter514 = NXOpen.Point3d(-6.8077763099478252, -5.9703508593750838, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint514, viewCenter514)
    
    scaleAboutPoint515 = NXOpen.Point3d(5.4146944427598322, 4.8393338978962692, 0.0)
    viewCenter515 = NXOpen.Point3d(-5.4146944427602852, -4.8393338978961031, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint515, viewCenter515)
    
    scaleAboutPoint516 = NXOpen.Point3d(3.4868425349008638, 4.3002289490101022, 0.0)
    viewCenter516 = NXOpen.Point3d(-3.4868425349013168, -4.3002289490099361, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint516, viewCenter516)
    
    scaleAboutPoint517 = NXOpen.Point3d(4.3585531686261394, 5.2807063706685549, 0.0)
    viewCenter517 = NXOpen.Point3d(-4.3585531686265915, -5.2807063706683888, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint517, viewCenter517)
    
    scaleAboutPoint518 = NXOpen.Point3d(5.4284873325339609, 6.3447292961017361, 0.0)
    viewCenter518 = NXOpen.Point3d(-5.4284873325344165, -6.3447292961015798, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint518, viewCenter518)
    
    objects26 = [NXOpen.TaggedObject.Null] * 1 
    objects26[0] = line18
    nErrs57 = theSession.UpdateManager.AddObjectsToDeleteList(objects26)
    
    scaleAboutPoint519 = NXOpen.Point3d(-2.1797691875196263, 0.29556192373151086, 0.0)
    viewCenter519 = NXOpen.Point3d(2.1797691875191716, -0.2955619237313809, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint519, viewCenter519)
    
    scaleAboutPoint520 = NXOpen.Point3d(-3.1865269902298583, 0.15393850194354597, 0.0)
    viewCenter520 = NXOpen.Point3d(3.1865269902294013, -0.15393850194338354, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint520, viewCenter520)
    
    scaleAboutPoint521 = NXOpen.Point3d(-4.3295203671600495, -0.038484625485784962, 0.0)
    viewCenter521 = NXOpen.Point3d(4.3295203671595992, 0.038484625485988001, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint521, viewCenter521)
    
    scaleAboutPoint522 = NXOpen.Point3d(-5.6043235863793326, -0.19242312742924209, 0.0)
    viewCenter522 = NXOpen.Point3d(5.6043235863788725, 0.19242312742936898, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint522, viewCenter522)
    
    scaleAboutPoint523 = NXOpen.Point3d(-8.9897679845890224, -1.5033056830415683, 0.0)
    viewCenter523 = NXOpen.Point3d(8.9897679845885605, 1.5033056830417268, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint523, viewCenter523)
    
    scaleAboutPoint524 = NXOpen.Point3d(-11.537871117344546, -2.3301238087143945, 0.0)
    viewCenter524 = NXOpen.Point3d(11.537871117344087, 2.330123808714593, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint524, viewCenter524)
    
    scaleAboutPoint525 = NXOpen.Point3d(-14.892121922631128, -3.2884811816533559, 0.0)
    viewCenter525 = NXOpen.Point3d(14.892121922630663, 3.2884811816536037, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint525, viewCenter525)
    
    scaleAboutPoint526 = NXOpen.Point3d(-19.202381185726974, -4.4629387465296109, 0.0)
    viewCenter526 = NXOpen.Point3d(19.202381185726509, 4.4629387465299208, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint526, viewCenter526)
    
    scaleAboutPoint527 = NXOpen.Point3d(-24.443398068987243, -5.8722878243812406, 0.0)
    viewCenter527 = NXOpen.Point3d(24.443398068986795, 5.8722878243812406, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint527, viewCenter527)
    
    scaleAboutPoint528 = NXOpen.Point3d(-30.737756580745934, -7.8908867640123592, 0.0)
    viewCenter528 = NXOpen.Point3d(30.737756580745451, 7.8908867640123592, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint528, viewCenter528)
    
    rotMatrix53 = NXOpen.Matrix3x3()
    
    rotMatrix53.Xx = -0.33085085493169103
    rotMatrix53.Xy = -0.7042940946850933
    rotMatrix53.Xz = 0.62809835215726362
    rotMatrix53.Yx = 0.26364841295102837
    rotMatrix53.Yy = 0.57009265652083496
    rotMatrix53.Yz = 0.77812844526428793
    rotMatrix53.Zx = -0.90610552704382485
    rotMatrix53.Zy = 0.42304159508577605
    rotMatrix53.Zz = -0.0029296224856921183
    translation53 = NXOpen.Point3d(-39.444852946637724, -30.811339269404016, 7.6233555592414746)
    modelingView3.SetRotationTranslationScale(rotMatrix53, translation53, 1.1534402835656301)
    
    face11 = component16.FindObject("PROTO#.Features|EXTRUDE(6)|FACE 160 {(0,-1.4999999999999,2.5) EXTRUDE(2)}")
    line19 = workPart.Lines.CreateFaceAxis(face11, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint529 = NXOpen.Point3d(-115.03720093465671, 35.325481443543538, 0.0)
    viewCenter529 = NXOpen.Point3d(115.03720093465625, -35.325481443543538, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint529, viewCenter529)
    
    scaleAboutPoint530 = NXOpen.Point3d(-92.029760747725419, 28.260385154834829, 0.0)
    viewCenter530 = NXOpen.Point3d(92.029760747724936, -28.260385154834829, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint530, viewCenter530)
    
    scaleAboutPoint531 = NXOpen.Point3d(-73.477001402570821, 22.608308123867864, 0.0)
    viewCenter531 = NXOpen.Point3d(73.477001402570394, -22.608308123867864, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint531, viewCenter531)
    
    scaleAboutPoint532 = NXOpen.Point3d(-58.66415536556908, 18.086646499094286, 0.0)
    viewCenter532 = NXOpen.Point3d(58.664155365568639, -18.086646499094286, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint532, viewCenter532)
    
    scaleAboutPoint533 = NXOpen.Point3d(-46.931324292455315, 14.469317199275432, 0.0)
    viewCenter533 = NXOpen.Point3d(46.931324292454846, -14.469317199275183, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint533, viewCenter533)
    
    scaleAboutPoint534 = NXOpen.Point3d(-36.718241308291404, 10.523139781291329, 0.0)
    viewCenter534 = NXOpen.Point3d(36.718241308290956, -10.523139781291132, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint534, viewCenter534)
    
    scaleAboutPoint535 = NXOpen.Point3d(-29.374593046633176, 8.4185118250330646, 0.0)
    viewCenter535 = NXOpen.Point3d(29.374593046632718, -8.4185118250329065, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint535, viewCenter535)
    
    scaleAboutPoint536 = NXOpen.Point3d(-23.403462873591931, 6.7348094600264536, 0.0)
    viewCenter536 = NXOpen.Point3d(23.403462873591469, -6.7348094600263266, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint536, viewCenter536)
    
    scaleAboutPoint537 = NXOpen.Point3d(-18.684285673387723, 5.5802706954504941, 0.0)
    viewCenter537 = NXOpen.Point3d(18.684285673387265, -5.5802706954503929, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint537, viewCenter537)
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint9 = componentPositioner16.CreateConstraint(True)
    
    componentConstraint9 = constraint9
    componentConstraint9.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge12 = component1.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 120 * 150 {(-0.75,0,-1.2990381056767)(1.5,0,0)(-0.75,0,1.2990381056767) EXTRUDE(2)}")
    constraintReference17 = componentConstraint9.CreateConstraintReference(component1, edge12, False, False, False)
    
    helpPoint17 = NXOpen.Point3d(-7.8885464894786921, -32.950143111867703, -0.062708765785898526)
    constraintReference17.HelpPoint = helpPoint17
    
    edge13 = component16.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 150 EXTRUDE(6) 160 {(-25,-0.7499999999999,2.7009618943233)(-25,-2.9999999999999,4)(-25,-0.7499999999999,5.2990381056767) EXTRUDE(2)}")
    constraintReference18 = componentConstraint9.CreateConstraintReference(component16, edge13, False, False, False)
    
    helpPoint18 = NXOpen.Point3d(-105.39955928289965, 159.49453587742877, 4.8961666938824013)
    constraintReference18.HelpPoint = helpPoint18
    
    constraintReference18.SetFixHint(True)
    
    objects27 = [NXOpen.TaggedObject.Null] * 1 
    objects27[0] = line19
    nErrs58 = theSession.UpdateManager.AddObjectsToDeleteList(objects27)
    
    componentNetwork16.Solve()
    
    scaleAboutPoint538 = NXOpen.Point3d(-0.16933235213803252, -1.5393850194345255, 0.0)
    viewCenter538 = NXOpen.Point3d(0.16933235213757569, 1.5393850194346881, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint538, viewCenter538)
    
    scaleAboutPoint539 = NXOpen.Point3d(-0.21166544017247715, -1.9242312742932073, 0.0)
    viewCenter539 = NXOpen.Point3d(0.21166544017204572, 1.9242312742933088, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint539, viewCenter539)
    
    scaleAboutPoint540 = NXOpen.Point3d(-0.26458180021554895, -2.4052890928665098, 0.0)
    viewCenter540 = NXOpen.Point3d(0.26458180021509686, 2.4052890928666368, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint540, viewCenter540)
    
    scaleAboutPoint541 = NXOpen.Point3d(-0.33072725026937677, -3.0066113660831379, 0.0)
    viewCenter541 = NXOpen.Point3d(0.33072725026892069, 3.0066113660832965, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint541, viewCenter541)
    
    scaleAboutPoint542 = NXOpen.Point3d(-0.037582642076259318, -3.6079336392997776, 0.0)
    viewCenter542 = NXOpen.Point3d(0.037582642075813188, 3.6079336392999761, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint542, viewCenter542)
    
    scaleAboutPoint543 = NXOpen.Point3d(-0.046978302595277667, -4.9797000750752369, 0.0)
    viewCenter543 = NXOpen.Point3d(0.046978302594812955, 4.9797000750754847, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint543, viewCenter543)
    
    scaleAboutPoint544 = NXOpen.Point3d(-0.058722878244019637, -6.4595166068194283, 0.0)
    viewCenter544 = NXOpen.Point3d(0.058722878243574285, 6.4595166068197374, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint544, viewCenter544)
    
    scaleAboutPoint545 = NXOpen.Point3d(-0.073403597804951926, -8.0743957585242843, 0.0)
    viewCenter545 = NXOpen.Point3d(0.073403597804540463, 8.0743957585242843, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint545, viewCenter545)
    
    line20 = workPart.Lines.CreateFaceAxis(face8, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    rotMatrix54 = NXOpen.Matrix3x3()
    
    rotMatrix54.Xx = -0.77218857129273089
    rotMatrix54.Xy = -0.34907282265634854
    rotMatrix54.Xz = 0.53091710732242825
    rotMatrix54.Yx = 0.3580067321819046
    rotMatrix54.Yy = 0.45128723858818492
    rotMatrix54.Yz = 0.81741727899517813
    rotMatrix54.Zx = -0.52493427214968447
    rotMatrix54.Zy = 0.82127217946925168
    rotMatrix54.Zz = -0.22350842747534058
    translation54 = NXOpen.Point3d(36.381023529338712, -62.709078979749322, 6.8471920474223111)
    modelingView3.SetRotationTranslationScale(rotMatrix54, translation54, 1.4418003544570386)
    
    componentPositioner16.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner16.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId112, None)
    
    objects28 = [NXOpen.TaggedObject.Null] * 1 
    objects28[0] = line20
    nErrs59 = theSession.UpdateManager.AddObjectsToDeleteList(objects28)
    
    theSession.UndoToMark(markId111, None)
    
    theSession.DeleteUndoMark(markId111, None)
    
    theSession.DeleteUndoMark(markId110, None)
    
    scaleAboutPoint546 = NXOpen.Point3d(69.825172411783342, -54.86918935906251, 0.0)
    viewCenter546 = NXOpen.Point3d(-69.825172411783768, 54.86918935906251, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint546, viewCenter546)
    
    scaleAboutPoint547 = NXOpen.Point3d(87.281465514729248, -68.586486698828139, 0.0)
    viewCenter547 = NXOpen.Point3d(-87.281465514729632, 68.586486698828139, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint547, viewCenter547)
    
    scaleAboutPoint548 = NXOpen.Point3d(109.38856469733648, -86.880039589234499, 0.0)
    viewCenter548 = NXOpen.Point3d(-109.38856469733686, 86.880039589234499, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint548, viewCenter548)
    
    scaleAboutPoint549 = NXOpen.Point3d(133.50996182751578, -106.09113745220054, 0.0)
    viewCenter549 = NXOpen.Point3d(-133.50996182751621, 106.09113745220054, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint549, viewCenter549)
    
    scaleAboutPoint550 = NXOpen.Point3d(166.88745228439487, -132.61392181525068, 0.0)
    viewCenter550 = NXOpen.Point3d(-166.88745228439518, 132.61392181525068, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint550, viewCenter550)
    
    scaleAboutPoint551 = NXOpen.Point3d(207.48926534016206, -168.00750229972681, 0.0)
    viewCenter551 = NXOpen.Point3d(-207.48926534016243, 168.00750229972681, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint551, viewCenter551)
    
    rotMatrix55 = NXOpen.Matrix3x3()
    
    rotMatrix55.Xx = -0.3154211627867386
    rotMatrix55.Xy = 0.88243092426810066
    rotMatrix55.Xz = -0.34903460281411208
    rotMatrix55.Yx = 0.35800673218190471
    rotMatrix55.Yy = 0.45128723858818559
    rotMatrix55.Yz = 0.81741727899517991
    rotMatrix55.Zx = 0.87882914709213789
    rotMatrix55.Zy = 0.13287397105074228
    rotMatrix55.Zz = -0.45826175711978223
    translation55 = NXOpen.Point3d(211.55125081018471, -216.97114828332414, 71.690212791204729)
    modelingView3.SetRotationTranslationScale(rotMatrix55, translation55, 0.37795931211878603)
    
    scaleAboutPoint552 = NXOpen.Point3d(336.3650202292439, -276.51234753496698, 0.0)
    viewCenter552 = NXOpen.Point3d(-336.36502022924435, 276.51234753496698, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint552, viewCenter552)
    
    scaleAboutPoint553 = NXOpen.Point3d(265.17184112973484, -194.88870266768248, 0.0)
    viewCenter553 = NXOpen.Point3d(-265.17184112973524, 194.88870266768248, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint553, viewCenter553)
    
    scaleAboutPoint554 = NXOpen.Point3d(212.13747290378782, -155.46294212801374, 0.0)
    viewCenter554 = NXOpen.Point3d(-212.13747290378825, 155.46294212801374, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint554, viewCenter554)
    
    scaleAboutPoint555 = NXOpen.Point3d(169.70997832303016, -124.01193769750469, 0.0)
    viewCenter555 = NXOpen.Point3d(-169.70997832303064, 124.01193769750469, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint555, viewCenter555)
    
    scaleAboutPoint556 = NXOpen.Point3d(135.48124985449925, -97.775886138379377, 0.0)
    viewCenter556 = NXOpen.Point3d(-135.48124985449962, 97.775886138379377, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint556, viewCenter556)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Move Component...
    # ----------------------------------------------
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner17 = workPart.ComponentAssembly.Positioner
    
    componentPositioner17.ClearNetwork()
    
    componentPositioner17.PrimaryArrangement = arrangement2
    
    componentPositioner17.BeginMoveComponent()
    
    allowInterpartPositioning17 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression177 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression178 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression179 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression180 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression181 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression182 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression183 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression184 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network17 = componentPositioner17.EstablishNetwork()
    
    componentNetwork17 = network17
    componentNetwork17.MoveObjectsState = True
    
    componentNetwork17.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork17.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    expression185 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression186 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression187 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression188 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression189 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    componentNetwork17.RemoveAllConstraints()
    
    movableObjects9 = []
    componentNetwork17.SetMovingGroup(movableObjects9)
    
    componentNetwork17.Solve()
    
    theSession.SetUndoMarkName(markId115, "Move Component Dialog")
    
    componentNetwork17.MoveObjectsState = True
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Move Component Update")
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    componentPositioner17.EndMoveComponent()
    
    componentPositioner17.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    theSession.DeleteUndoMarksUpToMark(markId116, None, False)
    
    theSession.UndoToMark(markId115, None)
    
    theSession.DeleteUndoMark(markId115, None)
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner18 = workPart.ComponentAssembly.Positioner
    
    componentPositioner18.ClearNetwork()
    
    componentPositioner18.PrimaryArrangement = arrangement2
    
    componentPositioner18.BeginAssemblyConstraints()
    
    allowInterpartPositioning18 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression190 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression191 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression192 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression193 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression194 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression195 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression196 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression197 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network18 = componentPositioner18.EstablishNetwork()
    
    componentNetwork18 = network18
    componentNetwork18.MoveObjectsState = True
    
    componentNetwork18.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork18.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId118, "Assembly Constraints Dialog")
    
    componentNetwork18.MoveObjectsState = True
    
    componentNetwork18.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    componentPositioner18.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner18.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId119, None)
    
    theSession.UndoToMark(markId118, None)
    
    theSession.DeleteUndoMark(markId118, None)
    
    theSession.DeleteUndoMark(markId117, None)
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner19 = workPart.ComponentAssembly.Positioner
    
    componentPositioner19.ClearNetwork()
    
    componentPositioner19.PrimaryArrangement = arrangement2
    
    componentPositioner19.BeginAssemblyConstraints()
    
    allowInterpartPositioning19 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression198 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression199 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression200 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression201 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression202 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression203 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression204 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression205 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network19 = componentPositioner19.EstablishNetwork()
    
    componentNetwork19 = network19
    componentNetwork19.MoveObjectsState = True
    
    componentNetwork19.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork19.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId121, "Assembly Constraints Dialog")
    
    componentNetwork19.MoveObjectsState = True
    
    componentNetwork19.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    componentPositioner19.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner19.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId122, None)
    
    theSession.UndoToMark(markId121, None)
    
    theSession.DeleteUndoMark(markId121, None)
    
    theSession.DeleteUndoMark(markId120, None)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner20 = workPart.ComponentAssembly.Positioner
    
    componentPositioner20.ClearNetwork()
    
    componentPositioner20.PrimaryArrangement = arrangement2
    
    componentPositioner20.BeginAssemblyConstraints()
    
    allowInterpartPositioning20 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression206 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression207 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression208 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression209 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression210 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression211 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression212 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression213 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network20 = componentPositioner20.EstablishNetwork()
    
    componentNetwork20 = network20
    componentNetwork20.MoveObjectsState = True
    
    componentNetwork20.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork20.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId124, "Assembly Constraints Dialog")
    
    componentNetwork20.MoveObjectsState = True
    
    componentNetwork20.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    scaleAboutPoint557 = NXOpen.Point3d(10.437074062864928, -71.797894102786543, 0.0)
    viewCenter557 = NXOpen.Point3d(-10.437074062865344, 71.797894102786543, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint557, viewCenter557)
    
    scaleAboutPoint558 = NXOpen.Point3d(8.3496592502919142, -57.438315282229247, 0.0)
    viewCenter558 = NXOpen.Point3d(-8.349659250292353, 57.438315282229247, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint558, viewCenter558)
    
    scaleAboutPoint559 = NXOpen.Point3d(6.8265345958429986, -46.097459421393005, 0.0)
    viewCenter559 = NXOpen.Point3d(-6.8265345958434338, 46.097459421393005, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint559, viewCenter559)
    
    scaleAboutPoint560 = NXOpen.Point3d(8.9001862338276592, -58.355860254788837, 0.0)
    viewCenter560 = NXOpen.Point3d(-8.9001862338280979, 58.355860254788837, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint560, viewCenter560)
    
    scaleAboutPoint561 = NXOpen.Point3d(11.125232792284613, -73.403597804765795, 0.0)
    viewCenter561 = NXOpen.Point3d(-11.125232792285068, 73.403597804765795, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint561, viewCenter561)
    
    scaleAboutPoint562 = NXOpen.Point3d(1.5770304215866027, -87.453505197084496, 0.0)
    viewCenter562 = NXOpen.Point3d(-1.5770304215870281, 87.453505197084496, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint562, viewCenter562)
    
    rotMatrix56 = NXOpen.Matrix3x3()
    
    rotMatrix56.Xx = -0.78902538154802271
    rotMatrix56.Xy = 0.60550087171851719
    rotMatrix56.Xz = -0.10395980771967278
    rotMatrix56.Yx = 0.02884929294849824
    rotMatrix56.Yy = 0.20554652290948841
    rotMatrix56.Yz = 0.97822203267775032
    rotMatrix56.Zx = 0.61368287051975623
    rotMatrix56.Zy = 0.76884284562446992
    rotMatrix56.Zz = -0.17964969569330644
    translation56 = NXOpen.Point3d(-15.193241118435015, -90.083813391395495, 37.999593154507124)
    modelingView3.SetRotationTranslationScale(rotMatrix56, translation56, 0.7382017814820041)
    
    scaleAboutPoint563 = NXOpen.Point3d(-35.3039764832494, -111.82579353069815, 0.0)
    viewCenter563 = NXOpen.Point3d(35.303976483248924, 111.82579353069815, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint563, viewCenter563)
    
    scaleAboutPoint564 = NXOpen.Point3d(-28.243181186599564, -89.173902020633491, 0.0)
    viewCenter564 = NXOpen.Point3d(28.243181186599092, 89.173902020633491, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint564, viewCenter564)
    
    scaleAboutPoint565 = NXOpen.Point3d(-21.676999976720118, -71.109735373366775, 0.0)
    viewCenter565 = NXOpen.Point3d(21.676999976719664, 71.109735373366775, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint565, viewCenter565)
    
    scaleAboutPoint566 = NXOpen.Point3d(-14.038438080161674, -49.547428518216883, 0.0)
    viewCenter566 = NXOpen.Point3d(14.038438080161235, 49.547428518216883, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint566, viewCenter566)
    
    scaleAboutPoint567 = NXOpen.Point3d(-11.083943268519846, -39.19752122774505, 0.0)
    viewCenter567 = NXOpen.Point3d(11.083943268519398, 39.19752122774505, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint567, viewCenter567)
    
    face12 = component1.FindObject("PROTO#.Features|EXTRUDE(2)|FACE 150 {(0,-1.5,-1.5) EXTRUDE(2)}")
    line21 = workPart.Lines.CreateFaceAxis(face12, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects29 = [NXOpen.TaggedObject.Null] * 1 
    objects29[0] = line21
    nErrs60 = theSession.UpdateManager.AddObjectsToDeleteList(objects29)
    
    scaleAboutPoint568 = NXOpen.Point3d(45.392784882466955, -34.763943920337056, 0.0)
    viewCenter568 = NXOpen.Point3d(-45.392784882467424, 34.763943920337056, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint568, viewCenter568)
    
    scaleAboutPoint569 = NXOpen.Point3d(56.740981103083769, -43.45492990042132, 0.0)
    viewCenter569 = NXOpen.Point3d(-56.740981103084202, 43.45492990042132, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint569, viewCenter569)
    
    scaleAboutPoint570 = NXOpen.Point3d(86.524490912367511, -51.749536452359877, 0.0)
    viewCenter570 = NXOpen.Point3d(-86.524490912367938, 51.749536452359877, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint570, viewCenter570)
    
    scaleAboutPoint571 = NXOpen.Point3d(108.15561364045945, -64.916306808589866, 0.0)
    viewCenter571 = NXOpen.Point3d(-108.15561364045983, 64.916306808589866, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint571, viewCenter571)
    
    scaleAboutPoint572 = NXOpen.Point3d(173.61671277650649, -74.837261824390168, 0.0)
    viewCenter572 = NXOpen.Point3d(-173.61671277650686, 74.837261824390168, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint572, viewCenter572)
    
    rotMatrix57 = NXOpen.Matrix3x3()
    
    rotMatrix57.Xx = -0.94393334284458486
    rotMatrix57.Xy = 0.32650360207207413
    rotMatrix57.Xz = -0.04883894040831141
    rotMatrix57.Yx = -0.074072963968659686
    rotMatrix57.Yy = -0.065296937300181102
    rotMatrix57.Yz = 0.99511281068435242
    rotMatrix57.Zx = 0.32171888392685916
    rotMatrix57.Zy = 0.94293780696988361
    rotMatrix57.Zz = 0.085821045855196315
    translation57 = NXOpen.Point3d(129.46859518917074, -78.706508910065367, 20.167832127643695)
    modelingView3.SetRotationTranslationScale(rotMatrix57, translation57, 0.73820178148200433)
    
    rotMatrix58 = NXOpen.Matrix3x3()
    
    rotMatrix58.Xx = -0.9201359155028066
    rotMatrix58.Xy = 0.38920835004787124
    rotMatrix58.Xz = -0.043205986330878583
    rotMatrix58.Yx = -0.065659348260219838
    rotMatrix58.Yy = -0.044566861845645747
    rotMatrix58.Yz = 0.99684634965037233
    rotMatrix58.Zx = 0.38605536777495264
    rotMatrix58.Zy = 0.92007100545460163
    rotMatrix58.Zz = 0.066562736827009861
    translation58 = NXOpen.Point3d(131.04575186564995, -78.135294420872867, 26.250727441868513)
    modelingView3.SetRotationTranslationScale(rotMatrix58, translation58, 0.73820178148200433)
    
    scaleAboutPoint573 = NXOpen.Point3d(240.3179312895285, -98.564401349172826, 0.0)
    viewCenter573 = NXOpen.Point3d(-240.31793128952899, 98.564401349172826, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint573, viewCenter573)
    
    scaleAboutPoint574 = NXOpen.Point3d(193.11454344339742, -77.991322667563566, 0.0)
    viewCenter574 = NXOpen.Point3d(-193.11454344339779, 77.991322667563566, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint574, viewCenter574)
    
    scaleAboutPoint575 = NXOpen.Point3d(156.32672469983697, -60.328581945791861, 0.0)
    viewCenter575 = NXOpen.Point3d(-156.32672469983737, 60.328581945791861, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint575, viewCenter575)
    
    scaleAboutPoint576 = NXOpen.Point3d(128.36454166108396, -46.794793600538313, 0.0)
    viewCenter576 = NXOpen.Point3d(-128.36454166108439, 46.794793600538313, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint576, viewCenter576)
    
    scaleAboutPoint577 = NXOpen.Point3d(103.27886211130526, -36.995413293601999, 0.0)
    viewCenter577 = NXOpen.Point3d(-103.27886211130568, 36.995413293601999, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint577, viewCenter577)
    
    scaleAboutPoint578 = NXOpen.Point3d(82.740535445531833, -29.361439121906383, 0.0)
    viewCenter578 = NXOpen.Point3d(-82.740535445532231, 29.361439121906383, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint578, viewCenter578)
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint10 = componentPositioner20.CreateConstraint(True)
    
    componentConstraint10 = constraint10
    componentConstraint10.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    constraintReference19 = componentConstraint10.CreateConstraintReference(component1, edge12, False, False, False)
    
    helpPoint19 = NXOpen.Point3d(-6.4462411387391763, -32.950143111867703, 1.4989399340140772)
    constraintReference19.HelpPoint = helpPoint19
    
    edge14 = component16.FindObject("PROTO#.Features|EXTRUDE(6)|EDGE * 160 EXTRUDE(2) 170 {(25,-0.7499999999999,2.7009618943233)(25,-2.9999999999999,4)(25,-0.7499999999999,5.2990381056767) EXTRUDE(2)}")
    constraintReference20 = componentConstraint10.CreateConstraintReference(component16, edge14, False, False, False)
    
    helpPoint20 = NXOpen.Point3d(-55.399559282899673, 162.19550903718579, 3.9246790362078721)
    constraintReference20.HelpPoint = helpPoint20
    
    constraintReference20.SetFixHint(True)
    
    componentNetwork20.Solve()
    
    scaleAboutPoint579 = NXOpen.Point3d(58.863813151597604, -22.079802219673564, 0.0)
    viewCenter579 = NXOpen.Point3d(-58.863813151598009, 22.079802219673564, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint579, viewCenter579)
    
    scaleAboutPoint580 = NXOpen.Point3d(72.992537657058918, -27.599752774591952, 0.0)
    viewCenter580 = NXOpen.Point3d(-72.992537657059316, 27.599752774591952, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint580, viewCenter580)
    
    scaleAboutPoint581 = NXOpen.Point3d(91.093864875714132, -34.499690968239932, 0.0)
    viewCenter581 = NXOpen.Point3d(-91.093864875714573, 34.499690968239932, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint581, viewCenter581)
    
    scaleAboutPoint582 = NXOpen.Point3d(113.86733109464278, -43.124613710299919, 0.0)
    viewCenter582 = NXOpen.Point3d(-113.86733109464315, 43.124613710299919, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint582, viewCenter582)
    
    scaleAboutPoint583 = NXOpen.Point3d(142.33416386830351, -53.905767137874903, 0.0)
    viewCenter583 = NXOpen.Point3d(-142.33416386830388, 53.905767137874903, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint583, viewCenter583)
    
    rotMatrix59 = NXOpen.Matrix3x3()
    
    rotMatrix59.Xx = -0.9985277669465431
    rotMatrix59.Xy = 0.051796648552604768
    rotMatrix59.Xz = 0.016106080698434191
    rotMatrix59.Yx = 0.0075455932679869674
    rotMatrix59.Yy = -0.16139976028453634
    rotMatrix59.Yz = 0.98686026437501506
    rotMatrix59.Zx = 0.053715571848214294
    rotMatrix59.Zy = 0.98552890600875109
    rotMatrix59.Zz = 0.1607713057800034
    translation59 = NXOpen.Point3d(14.959523314439394, -22.957249935826631, 13.775495451249913)
    modelingView3.SetRotationTranslationScale(rotMatrix59, translation59, 1.4418003544570401)
    
    face13 = component16.FindObject("PROTO#.Features|EXTRUDE(4)|FACE 140 {(0,7.5152151497102,11.8858010883882) EXTRUDE(2)}")
    line22 = workPart.Lines.CreateFaceAxis(face13, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    componentPositioner20.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner20.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId125, None)
    
    objects30 = [NXOpen.TaggedObject.Null] * 1 
    objects30[0] = line22
    nErrs61 = theSession.UpdateManager.AddObjectsToDeleteList(objects30)
    
    theSession.UndoToMark(markId124, None)
    
    theSession.DeleteUndoMark(markId124, None)
    
    theSession.DeleteUndoMark(markId123, None)
    
    scaleAboutPoint584 = NXOpen.Point3d(-32.93986451488886, 8.9919407310837354, 0.0)
    viewCenter584 = NXOpen.Point3d(32.93986451488847, -8.9919407310837354, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint584, viewCenter584)
    
    scaleAboutPoint585 = NXOpen.Point3d(-41.174830643611031, 11.239925913854668, 0.0)
    viewCenter585 = NXOpen.Point3d(41.174830643610633, -11.239925913854668, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint585, viewCenter585)
    
    scaleAboutPoint586 = NXOpen.Point3d(-46.88081344171588, 0.28673280392502609, 0.0)
    viewCenter586 = NXOpen.Point3d(46.880813441715503, -0.28673280392502609, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint586, viewCenter586)
    
    scaleAboutPoint587 = NXOpen.Point3d(-57.16735278252051, -3.2257440441546521, 0.0)
    viewCenter587 = NXOpen.Point3d(57.167352782520098, 3.2257440441546521, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint587, viewCenter587)
    
    scaleAboutPoint588 = NXOpen.Point3d(-68.771070941354836, -10.304460141049711, 0.0)
    viewCenter588 = NXOpen.Point3d(68.771070941354495, 10.304460141049711, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint588, viewCenter588)
    
    scaleAboutPoint589 = NXOpen.Point3d(-80.923613607701753, -22.961025314296162, 0.0)
    viewCenter589 = NXOpen.Point3d(80.923613607701384, 22.961025314296162, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint589, viewCenter589)
    
    rotMatrix60 = NXOpen.Matrix3x3()
    
    rotMatrix60.Xx = 0.018829307921517536
    rotMatrix60.Xy = 0.98653198312184476
    rotMatrix60.Xz = 0.16248108640967257
    rotMatrix60.Yx = -0.97604925263246445
    rotMatrix60.Yy = -0.017090305403441156
    rotMatrix60.Yz = 0.21687733375532522
    rotMatrix60.Zx = 0.2167332775528451
    rotMatrix60.Zy = -0.16267319305554845
    rotMatrix60.Zz = 0.96258200620118961
    translation60 = NXOpen.Point3d(-75.561742201799376, -46.388853338197578, 46.724949796759319)
    modelingView3.SetRotationTranslationScale(rotMatrix60, translation60, 0.37795931211878608)
    
    scaleAboutPoint590 = NXOpen.Point3d(-69.653110328428326, -35.701594238691413, 0.0)
    viewCenter590 = NXOpen.Point3d(69.653110328427985, 35.701594238691413, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint590, viewCenter590)
    
    scaleAboutPoint591 = NXOpen.Point3d(-90.566544208446587, -31.501406681198915, 0.0)
    viewCenter591 = NXOpen.Point3d(90.566544208446018, 31.501406681198915, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint591, viewCenter591)
    
    scaleAboutPoint592 = NXOpen.Point3d(-72.453235366757283, -21.700969047048066, 0.0)
    viewCenter592 = NXOpen.Point3d(72.453235366756815, 21.700969047048066, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint592, viewCenter592)
    
    scaleAboutPoint593 = NXOpen.Point3d(-57.962588293405823, -15.680700214640993, 0.0)
    viewCenter593 = NXOpen.Point3d(57.96258829340541, 15.680700214640993, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint593, viewCenter593)
    
    scaleAboutPoint594 = NXOpen.Point3d(-46.370070634724726, -12.544560171712792, 0.0)
    viewCenter594 = NXOpen.Point3d(46.37007063472425, 12.544560171712792, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint594, viewCenter594)
    
    scaleAboutPoint595 = NXOpen.Point3d(-37.096056507779842, -10.035648137370234, 0.0)
    viewCenter595 = NXOpen.Point3d(37.096056507779366, 10.035648137370234, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint595, viewCenter595)
    
    scaleAboutPoint596 = NXOpen.Point3d(-29.676845206223874, -8.0285185098961875, 0.0)
    viewCenter596 = NXOpen.Point3d(29.676845206223497, 8.0285185098961875, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint596, viewCenter596)
    
    rotMatrix61 = NXOpen.Matrix3x3()
    
    rotMatrix61.Xx = 0.079501291333477553
    rotMatrix61.Xy = 0.98028068728522733
    rotMatrix61.Xz = 0.18091246173744341
    rotMatrix61.Yx = -0.51296854284834681
    rotMatrix61.Yy = -0.11538091785756255
    rotMatrix61.Yz = 0.85061772720910445
    rotMatrix61.Zx = 0.85471797613268108
    rotMatrix61.Zy = -0.16042760962483524
    rotMatrix61.Zz = 0.4936802237741641
    translation61 = NXOpen.Point3d(-24.608865999325758, -29.257157058463935, 70.46167396137605)
    modelingView3.SetRotationTranslationScale(rotMatrix61, translation61, 1.1534402835656314)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner21 = workPart.ComponentAssembly.Positioner
    
    componentPositioner21.ClearNetwork()
    
    componentPositioner21.PrimaryArrangement = arrangement2
    
    componentPositioner21.BeginAssemblyConstraints()
    
    allowInterpartPositioning21 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression214 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression215 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression216 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression217 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression218 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression219 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression220 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression221 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network21 = componentPositioner21.EstablishNetwork()
    
    componentNetwork21 = network21
    componentNetwork21.MoveObjectsState = True
    
    componentNetwork21.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork21.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId128, "Assembly Constraints Dialog")
    
    componentNetwork21.MoveObjectsState = True
    
    componentNetwork21.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    face14 = component11.FindObject("PROTO#.Features|EXTRUDE(2)|FACE 140 {(0,-1.5,-10) EXTRUDE(2)}")
    line23 = workPart.Lines.CreateFaceAxis(face14, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint597 = NXOpen.Point3d(-143.48109508400339, -47.024179843678233, 0.0)
    viewCenter597 = NXOpen.Point3d(143.48109508400299, 47.024179843678233, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint597, viewCenter597)
    
    scaleAboutPoint598 = NXOpen.Point3d(-114.60136707269086, -37.619343874942587, 0.0)
    viewCenter598 = NXOpen.Point3d(114.60136707269044, 37.619343874942587, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint598, viewCenter598)
    
    scaleAboutPoint599 = NXOpen.Point3d(-143.2517088408635, -47.024179843678233, 0.0)
    viewCenter599 = NXOpen.Point3d(143.2517088408631, 47.024179843678233, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint599, viewCenter599)
    
    scaleAboutPoint600 = NXOpen.Point3d(-177.91770483537982, -59.066957608522436, 0.0)
    viewCenter600 = NXOpen.Point3d(177.91770483537948, 59.066957608522436, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint600, viewCenter600)
    
    rotMatrix62 = NXOpen.Matrix3x3()
    
    rotMatrix62.Xx = 0.75354039841908205
    rotMatrix62.Xy = 0.168108180474836
    rotMatrix62.Xz = 0.635544260935342
    rotMatrix62.Yx = -0.59638693159207934
    rotMatrix62.Yy = -0.23192862032995273
    rotMatrix62.Yz = 0.768460631976699
    rotMatrix62.Zx = 0.27658542220549914
    rotMatrix62.Zy = -0.9580964224592865
    rotMatrix62.Zz = -0.074510063039305921
    translation62 = NXOpen.Point3d(-65.163036019228329, -52.611937507617533, 92.042826108341885)
    modelingView3.SetRotationTranslationScale(rotMatrix62, translation62, 0.73820178148200422)
    
    scaleAboutPoint601 = NXOpen.Point3d(-54.300024743271763, -53.403984731006297, 0.0)
    viewCenter601 = NXOpen.Point3d(54.300024743271408, 53.403984731006297, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint601, viewCenter601)
    
    scaleAboutPoint602 = NXOpen.Point3d(-43.440019794617413, -42.723187784805035, 0.0)
    viewCenter602 = NXOpen.Point3d(43.440019794617129, 42.723187784805035, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint602, viewCenter602)
    
    scaleAboutPoint603 = NXOpen.Point3d(-34.752015835693967, -34.178550227844028, 0.0)
    viewCenter603 = NXOpen.Point3d(34.752015835693662, 34.178550227844028, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint603, viewCenter603)
    
    scaleAboutPoint604 = NXOpen.Point3d(-27.801612668555236, -27.342840182275225, 0.0)
    viewCenter604 = NXOpen.Point3d(27.801612668554874, 27.342840182275225, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint604, viewCenter604)
    
    scaleAboutPoint605 = NXOpen.Point3d(-19.158339027044036, -21.580657754601145, 0.0)
    viewCenter605 = NXOpen.Point3d(19.158339027043699, 21.580657754601145, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint605, viewCenter605)
    
    scaleAboutPoint606 = NXOpen.Point3d(-15.326671221635271, -17.147080447193229, 0.0)
    viewCenter606 = NXOpen.Point3d(15.326671221634923, 17.147080447193229, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint606, viewCenter606)
    
    scaleAboutPoint607 = NXOpen.Point3d(-12.261336977308249, -13.623707752564554, 0.0)
    viewCenter607 = NXOpen.Point3d(12.261336977307909, 13.623707752564554, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint607, viewCenter607)
    
    objects31 = [NXOpen.TaggedObject.Null] * 1 
    objects31[0] = line23
    nErrs62 = theSession.UpdateManager.AddObjectsToDeleteList(objects31)
    
    rotMatrix63 = NXOpen.Matrix3x3()
    
    rotMatrix63.Xx = 0.25358156303089507
    rotMatrix63.Xy = 0.85388368245374646
    rotMatrix63.Xz = 0.45450967836783973
    rotMatrix63.Yx = -0.59638693159207934
    rotMatrix63.Yy = -0.23192862032995273
    rotMatrix63.Yz = 0.768460631976699
    rotMatrix63.Zx = 0.76158979688346129
    rotMatrix63.Zy = -0.46593108064506028
    rotMatrix63.Zz = 0.45043224726026709
    translation63 = NXOpen.Point3d(-58.492885284401268, -10.611935731559841, 79.486550656357053)
    modelingView3.SetRotationTranslationScale(rotMatrix63, translation63, 3.520020396623631)
    
    scaleAboutPoint608 = NXOpen.Point3d(1.5408883251174723, -16.386031945153476, 0.0)
    viewCenter608 = NXOpen.Point3d(-1.5408883251178194, 16.386031945153476, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint608, viewCenter608)
    
    scaleAboutPoint609 = NXOpen.Point3d(2.301936827157296, -20.670453141822026, 0.0)
    viewCenter609 = NXOpen.Point3d(-2.301936827157621, 20.670453141822026, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint609, viewCenter609)
    
    scaleAboutPoint610 = NXOpen.Point3d(2.8774210339466779, -25.838066427277536, 0.0)
    viewCenter610 = NXOpen.Point3d(-2.8774210339469879, 25.838066427277536, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint610, viewCenter610)
    
    rotMatrix64 = NXOpen.Matrix3x3()
    
    rotMatrix64.Xx = -0.35387614905298614
    rotMatrix64.Xy = 0.93392920588441153
    rotMatrix64.Xz = 0.050476821686204786
    rotMatrix64.Yx = -0.51124729580849615
    rotMatrix64.Yy = -0.23834576087558951
    rotMatrix64.Yz = 0.82572241146836678
    rotMatrix64.Zx = 0.7831972124949933
    rotMatrix64.Zy = 0.26639732856909087
    rotMatrix64.Zz = 0.56181366098674013
    translation64 = NXOpen.Point3d(-69.568598214409775, -24.727422918561508, 52.433063417974886)
    modelingView3.SetRotationTranslationScale(rotMatrix64, translation64, 1.8022504430712993)
    
    scaleAboutPoint611 = NXOpen.Point3d(74.064230185008569, -40.812400379449841, 0.0)
    viewCenter611 = NXOpen.Point3d(-74.06423018500891, 40.812400379449841, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint611, viewCenter611)
    
    scaleAboutPoint612 = NXOpen.Point3d(97.168012594058609, -49.54742851821689, 0.0)
    viewCenter612 = NXOpen.Point3d(-97.168012594058965, 49.54742851821689, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint612, viewCenter612)
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint11 = componentPositioner21.CreateConstraint(True)
    
    componentConstraint11 = constraint11
    componentConstraint11.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge15 = component11.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 130 * 150 {(-0.75,-3,-1.2990381056767)(1.5,-3,0)(-0.75,-3,1.2990381056767) EXTRUDE(2)}")
    constraintReference21 = componentConstraint11.CreateConstraintReference(component11, edge15, False, False, False)
    
    helpPoint21 = NXOpen.Point3d(46.614947629709896, -126.32436510022019, -1.2512794631382085)
    constraintReference21.HelpPoint = helpPoint21
    
    constraintReference22 = componentConstraint11.CreateConstraintReference(component16, edge14, False, False, False)
    
    helpPoint22 = NXOpen.Point3d(-55.399559282899681, 159.43172386361169, 4.8050221073923014)
    constraintReference22.HelpPoint = helpPoint22
    
    constraintReference22.SetFixHint(True)
    
    componentNetwork21.Solve()
    
    scaleAboutPoint613 = NXOpen.Point3d(86.983263398647267, -44.92300185651667, 0.0)
    viewCenter613 = NXOpen.Point3d(-86.983263398647679, 44.92300185651667, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint613, viewCenter613)
    
    scaleAboutPoint614 = NXOpen.Point3d(106.89398930319007, -56.887788298693437, 0.0)
    viewCenter614 = NXOpen.Point3d(-106.89398930319044, 56.887788298693437, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint614, viewCenter614)
    
    scaleAboutPoint615 = NXOpen.Point3d(120.54247077001367, -72.486052832206298, 0.0)
    viewCenter615 = NXOpen.Point3d(-120.54247077001405, 72.486052832206298, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint615, viewCenter615)
    
    scaleAboutPoint616 = NXOpen.Point3d(149.81789005074262, -92.901428471656985, 0.0)
    viewCenter616 = NXOpen.Point3d(-149.8178900507429, 92.901428471656985, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint616, viewCenter616)
    
    rotMatrix65 = NXOpen.Matrix3x3()
    
    rotMatrix65.Xx = -0.71738996920271125
    rotMatrix65.Xy = -0.5348527987034577
    rotMatrix65.Xz = -0.44641249512800413
    rotMatrix65.Yx = -0.29844069893648367
    rotMatrix65.Yy = -0.34307231707605068
    rotMatrix65.Yz = 0.89063715085009287
    rotMatrix65.Zx = -0.62951154183671187
    rotMatrix65.Zy = 0.77216181527912053
    rotMatrix65.Zz = 0.086494795908296368
    translation65 = NXOpen.Point3d(95.512555346866137, -83.485108899747374, 4.4777135309860014)
    modelingView3.SetRotationTranslationScale(rotMatrix65, translation65, 0.73820178148200433)
    
    scaleAboutPoint617 = NXOpen.Point3d(115.58916158221166, -82.435681128399096, 0.0)
    viewCenter617 = NXOpen.Point3d(-115.58916158221201, 82.435681128399096, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint617, viewCenter617)
    
    scaleAboutPoint618 = NXOpen.Point3d(92.471329265769327, -65.948544902719277, 0.0)
    viewCenter618 = NXOpen.Point3d(-92.471329265769612, 65.948544902719277, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint618, viewCenter618)
    
    scaleAboutPoint619 = NXOpen.Point3d(73.977063412615422, -52.758835922175422, 0.0)
    viewCenter619 = NXOpen.Point3d(-73.977063412615735, 52.758835922175422, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint619, viewCenter619)
    
    scaleAboutPoint620 = NXOpen.Point3d(59.181650730092336, -42.207068737740329, 0.0)
    viewCenter620 = NXOpen.Point3d(-59.181650730092606, 42.207068737740329, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint620, viewCenter620)
    
    scaleAboutPoint621 = NXOpen.Point3d(56.006945125036211, -39.931557205792537, 0.0)
    viewCenter621 = NXOpen.Point3d(-56.006945125036452, 39.931557205792537, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint621, viewCenter621)
    
    scaleAboutPoint622 = NXOpen.Point3d(44.80555610002893, -31.945245764634031, 0.0)
    viewCenter622 = NXOpen.Point3d(-44.8055561000292, 31.945245764634031, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint622, viewCenter622)
    
    scaleAboutPoint623 = NXOpen.Point3d(35.844444880023133, -25.368283401327044, 0.0)
    viewCenter623 = NXOpen.Point3d(-35.844444880023374, 25.368283401327044, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint623, viewCenter623)
    
    scaleAboutPoint624 = NXOpen.Point3d(28.675555904018466, -20.069130868605466, 0.0)
    viewCenter624 = NXOpen.Point3d(-28.67555590401874, 20.069130868605466, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint624, viewCenter624)
    
    line24 = workPart.Lines.CreateFaceAxis(face10, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects32 = [NXOpen.TaggedObject.Null] * 1 
    objects32[0] = line24
    nErrs63 = theSession.UpdateManager.AddObjectsToDeleteList(objects32)
    
    scaleAboutPoint625 = NXOpen.Point3d(13.259156124426811, -19.001783833645888, 0.0)
    viewCenter625 = NXOpen.Point3d(-13.259156124427088, 19.001783833645888, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint625, viewCenter625)
    
    scaleAboutPoint626 = NXOpen.Point3d(16.573945155533568, -23.97772564451363, 0.0)
    viewCenter626 = NXOpen.Point3d(-16.573945155533835, 23.97772564451363, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint626, viewCenter626)
    
    scaleAboutPoint627 = NXOpen.Point3d(20.717431444416988, -30.066113660832062, 0.0)
    viewCenter627 = NXOpen.Point3d(-20.717431444417251, 30.066113660832062, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint627, viewCenter627)
    
    scaleAboutPoint628 = NXOpen.Point3d(25.896789305521253, -37.582642076040074, 0.0)
    viewCenter628 = NXOpen.Point3d(-25.896789305521533, 37.582642076040074, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint628, viewCenter628)
    
    scaleAboutPoint629 = NXOpen.Point3d(26.645506003129846, -47.712338573097774, 0.0)
    viewCenter629 = NXOpen.Point3d(-26.645506003130109, 47.712338573097774, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint629, viewCenter629)
    
    scaleAboutPoint630 = NXOpen.Point3d(33.306882503912362, -59.27340522734842, 0.0)
    viewCenter630 = NXOpen.Point3d(-33.306882503912604, 59.27340522734842, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint630, viewCenter630)
    
    scaleAboutPoint631 = NXOpen.Point3d(41.633603129890481, -74.091756534185507, 0.0)
    viewCenter631 = NXOpen.Point3d(-41.633603129890709, 74.091756534185507, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint631, viewCenter631)
    
    scaleAboutPoint632 = NXOpen.Point3d(52.042003912363107, -92.614695667731894, 0.0)
    viewCenter632 = NXOpen.Point3d(-52.042003912363342, 92.614695667731894, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint632, viewCenter632)
    
    scaleAboutPoint633 = NXOpen.Point3d(65.052504890454003, -116.12678558957116, 0.0)
    viewCenter633 = NXOpen.Point3d(-65.052504890454188, 116.12678558957116, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint633, viewCenter633)
    
    rotMatrix66 = NXOpen.Matrix3x3()
    
    rotMatrix66.Xx = -0.31065932098731508
    rotMatrix66.Xy = 0.90377086023935149
    rotMatrix66.Xz = -0.29442998907366952
    rotMatrix66.Yx = -0.19529416945252986
    rotMatrix66.Yy = 0.24245906484526158
    rotMatrix66.Yz = 0.95030194635821241
    rotMatrix66.Zx = 0.93024242736049423
    rotMatrix66.Zy = 0.35272061756662537
    rotMatrix66.Zz = 0.10117901107379516
    translation66 = NXOpen.Point3d(25.424041663942383, -155.39485223157078, 60.151745719202069)
    modelingView3.SetRotationTranslationScale(rotMatrix66, translation66, 0.59056142518560384)
    
    scaleAboutPoint634 = NXOpen.Point3d(187.04835256036188, -111.10896152088603, 0.0)
    viewCenter634 = NXOpen.Point3d(-187.04835256036219, 111.10896152088603, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint634, viewCenter634)
    
    scaleAboutPoint635 = NXOpen.Point3d(149.28026604338348, -88.170337206896264, 0.0)
    viewCenter635 = NXOpen.Point3d(-149.2802660433837, 88.170337206896264, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint635, viewCenter635)
    
    scaleAboutPoint636 = NXOpen.Point3d(119.42421283470674, -69.676071353742699, 0.0)
    viewCenter636 = NXOpen.Point3d(-119.42421283470702, 69.676071353742699, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint636, viewCenter636)
    
    scaleAboutPoint637 = NXOpen.Point3d(95.539370267765335, -55.052698353574392, 0.0)
    viewCenter637 = NXOpen.Point3d(-95.539370267765648, 55.052698353574392, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint637, viewCenter637)
    
    scaleAboutPoint638 = NXOpen.Point3d(76.43149621421226, -43.675140693835729, 0.0)
    viewCenter638 = NXOpen.Point3d(-76.431496214212558, 43.675140693835729, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint638, viewCenter638)
    
    scaleAboutPoint639 = NXOpen.Point3d(60.998389775760266, -34.206076577020909, 0.0)
    viewCenter639 = NXOpen.Point3d(-60.998389775760508, 34.206076577020909, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint639, viewCenter639)
    
    scaleAboutPoint640 = NXOpen.Point3d(48.563820307632952, -26.425295209715667, 0.0)
    viewCenter640 = NXOpen.Point3d(-48.563820307633179, 26.425295209715667, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint640, viewCenter640)
    
    scaleAboutPoint641 = NXOpen.Point3d(38.851056246106346, -20.952322957392351, 0.0)
    viewCenter641 = NXOpen.Point3d(-38.851056246106559, 20.952322957392351, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint641, viewCenter641)
    
    scaleAboutPoint642 = NXOpen.Point3d(31.080844996885038, -16.68669308176176, 0.0)
    viewCenter642 = NXOpen.Point3d(-31.080844996885283, 16.68669308176176, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint642, viewCenter642)
    
    scaleAboutPoint643 = NXOpen.Point3d(24.804543770186338, -13.22909001076609, 0.0)
    viewCenter643 = NXOpen.Point3d(-24.804543770186566, 13.22909001076609, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint643, viewCenter643)
    
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint12 = componentPositioner21.CreateConstraint(True)
    
    componentConstraint12 = constraint12
    componentConstraint12.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge16 = component19.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 120 * 140 {(-0.75,0,-1.2990381056767)(1.5,0,0)(-0.75,0,1.2990381056767) EXTRUDE(2)}")
    constraintReference23 = componentConstraint12.CreateConstraintReference(component19, edge16, False, False, False)
    
    helpPoint23 = NXOpen.Point3d(-83.740998578207282, 72.295314117283752, -0.83306999055181485)
    constraintReference23.HelpPoint = helpPoint23
    
    edge17 = component11.FindObject("PROTO#.Features|EXTRUDE(2)|EDGE * 120 * 150 {(-0.75,0,-1.2990381056767)(1.5,0,0)(-0.75,0,1.2990381056767) EXTRUDE(2)}")
    constraintReference24 = componentConstraint12.CreateConstraintReference(component11, edge17, False, False, False)
    
    helpPoint24 = NXOpen.Point3d(-52.399559282899673, 159.70974930339875, 2.871043177367206)
    constraintReference24.HelpPoint = helpPoint24
    
    constraintReference24.SetFixHint(True)
    
    componentNetwork21.Solve()
    
    componentPositioner21.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner21.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId129, None)
    
    theSession.UndoToMark(markId128, None)
    
    theSession.DeleteUndoMark(markId128, None)
    
    theSession.DeleteUndoMark(markId127, None)
    
    scaleAboutPoint644 = NXOpen.Point3d(6.0372756230949678, -9.0919927710355939, 0.0)
    viewCenter644 = NXOpen.Point3d(-6.0372756230951943, 9.0919927710355939, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint644, viewCenter644)
    
    scaleAboutPoint645 = NXOpen.Point3d(6.8250078010087645, -11.66565210040282, 0.0)
    viewCenter645 = NXOpen.Point3d(-6.8250078010090025, 11.66565210040282, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint645, viewCenter645)
    
    scaleAboutPoint646 = NXOpen.Point3d(7.9299374780443408, -14.657230409655646, 0.0)
    viewCenter646 = NXOpen.Point3d(-7.9299374780445699, 14.657230409655646, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint646, viewCenter646)
    
    scaleAboutPoint647 = NXOpen.Point3d(8.0332897437534445, -18.791321038020069, 0.0)
    viewCenter647 = NXOpen.Point3d(-8.0332897437536772, 18.791321038020069, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint647, viewCenter647)
    
    scaleAboutPoint648 = NXOpen.Point3d(-7.8101428064271854, -26.190403696740415, 0.0)
    viewCenter648 = NXOpen.Point3d(7.8101428064269536, 26.190403696740415, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint648, viewCenter648)
    
    scaleAboutPoint649 = NXOpen.Point3d(-11.964786442176933, -33.178426207754171, 0.0)
    viewCenter649 = NXOpen.Point3d(11.964786442176717, 33.178426207754171, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint649, viewCenter649)
    
    scaleAboutPoint650 = NXOpen.Point3d(-17.158090986864078, -41.840050748716507, 0.0)
    viewCenter650 = NXOpen.Point3d(17.158090986863897, 41.840050748716507, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint650, viewCenter650)
    
    scaleAboutPoint651 = NXOpen.Point3d(-23.970862408118894, -52.758835922175386, 0.0)
    viewCenter651 = NXOpen.Point3d(23.970862408118723, 52.758835922175386, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint651, viewCenter651)
    
    scaleAboutPoint652 = NXOpen.Point3d(-66.665376912531542, -75.697460236164801, 0.0)
    viewCenter652 = NXOpen.Point3d(66.665376912531258, 75.697460236164801, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint652, viewCenter652)
    
    scaleAboutPoint653 = NXOpen.Point3d(-85.123801165194777, -95.338657305018089, 0.0)
    viewCenter653 = NXOpen.Point3d(85.12380116519455, 95.338657305018089, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint653, viewCenter653)
    
    scaleAboutPoint654 = NXOpen.Point3d(-106.85277146262605, -120.51738164967055, 0.0)
    viewCenter654 = NXOpen.Point3d(106.85277146262573, 120.51738164967055, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint654, viewCenter654)
    
    scaleAboutPoint655 = NXOpen.Point3d(-135.24603935127988, -150.64672706208822, 0.0)
    viewCenter655 = NXOpen.Point3d(135.24603935127951, 150.64672706208822, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint655, viewCenter655)
    
    scaleAboutPoint656 = NXOpen.Point3d(-173.95776800617506, -198.10884646176086, 0.0)
    viewCenter656 = NXOpen.Point3d(173.95776800617483, 198.10884646176086, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint656, viewCenter656)
    
    rotMatrix67 = NXOpen.Matrix3x3()
    
    rotMatrix67.Xx = 0.99032101060828526
    rotMatrix67.Xy = 0.13549770393871927
    rotMatrix67.Xz = -0.030077702291184779
    rotMatrix67.Yx = 0.0020133726285164995
    rotMatrix67.Yy = 0.20265754915674916
    rotMatrix67.Yz = 0.97924760101847452
    rotMatrix67.Zx = 0.1387812749561019
    rotMatrix67.Zy = -0.96983003149887703
    rotMatrix67.Zz = 0.20042322151997344
    translation67 = NXOpen.Point3d(-233.47833809159167, -265.51246293126439, 84.709560508812558)
    modelingView3.SetRotationTranslationScale(rotMatrix67, translation67, 0.30236744969502932)
    
    scaleAboutPoint657 = NXOpen.Point3d(-199.0713894436862, -313.26398866303123, 0.0)
    viewCenter657 = NXOpen.Point3d(199.07138944368592, 313.26398866303123, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint657, viewCenter657)
    
    scaleAboutPoint658 = NXOpen.Point3d(-159.25711155494898, -250.61119093042498, 0.0)
    viewCenter658 = NXOpen.Point3d(159.25711155494872, 250.61119093042498, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint658, viewCenter658)
    
    scaleAboutPoint659 = NXOpen.Point3d(-127.40568924395929, -199.92892773667469, 0.0)
    viewCenter659 = NXOpen.Point3d(127.405689243959, 199.92892773667469, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint659, viewCenter659)
    
    scaleAboutPoint660 = NXOpen.Point3d(-101.47653138903476, -158.15106216480893, 0.0)
    viewCenter660 = NXOpen.Point3d(101.47653138903458, 158.15106216480893, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint660, viewCenter660)
    
    scaleAboutPoint661 = NXOpen.Point3d(-80.822809106321785, -122.21985767297411, 0.0)
    viewCenter661 = NXOpen.Point3d(80.822809106321557, 122.21985767297411, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint661, viewCenter661)
    
    scaleAboutPoint662 = NXOpen.Point3d(-64.658247285057442, -96.915687726604986, 0.0)
    viewCenter662 = NXOpen.Point3d(64.658247285057229, 96.915687726604986, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint662, viewCenter662)
    
    scaleAboutPoint663 = NXOpen.Point3d(-51.726597828045982, -76.156232722444457, 0.0)
    viewCenter663 = NXOpen.Point3d(51.726597828045755, 76.156232722444457, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint663, viewCenter663)
    
    scaleAboutPoint664 = NXOpen.Point3d(-41.381278262436815, -59.640423216372177, 0.0)
    viewCenter664 = NXOpen.Point3d(41.381278262436538, 59.640423216372177, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint664, viewCenter664)
    
    scaleAboutPoint665 = NXOpen.Point3d(-35.747552130921058, -41.252821966278439, 0.0)
    viewCenter665 = NXOpen.Point3d(35.747552130920766, 41.252821966278439, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint665, viewCenter665)
    
    scaleAboutPoint666 = NXOpen.Point3d(-29.067824730687384, -32.415028790584607, 0.0)
    viewCenter666 = NXOpen.Point3d(29.067824730687065, 32.415028790584607, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint666, viewCenter666)
    
    scaleAboutPoint667 = NXOpen.Point3d(-24.193825836450944, -24.992456980566658, 0.0)
    viewCenter667 = NXOpen.Point3d(24.193825836450632, 24.992456980566658, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint667, viewCenter667)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner22 = workPart.ComponentAssembly.Positioner
    
    componentPositioner22.ClearNetwork()
    
    componentPositioner22.PrimaryArrangement = arrangement2
    
    componentPositioner22.BeginAssemblyConstraints()
    
    allowInterpartPositioning22 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression222 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression223 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression224 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression225 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression226 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression227 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression228 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression229 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network22 = componentPositioner22.EstablishNetwork()
    
    componentNetwork22 = network22
    componentNetwork22.MoveObjectsState = True
    
    componentNetwork22.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork22.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId133, "Assembly Constraints Dialog")
    
    componentNetwork22.MoveObjectsState = True
    
    componentNetwork22.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    face15 = component11.FindObject("PROTO#.Features|EXTRUDE(2)|FACE 150 {(0,-1.5,-1.5) EXTRUDE(2)}")
    line25 = workPart.Lines.CreateFaceAxis(face15, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects33 = [NXOpen.TaggedObject.Null] * 1 
    objects33[0] = line25
    nErrs64 = theSession.UpdateManager.AddObjectsToDeleteList(objects33)
    
    scaleAboutPoint668 = NXOpen.Point3d(3.2696898606153453, -10.89896620205163, 0.0)
    viewCenter668 = NXOpen.Point3d(-3.2696898606156428, 10.89896620205163, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint668, viewCenter668)
    
    scaleAboutPoint669 = NXOpen.Point3d(4.0871123257692279, -13.623707752564538, 0.0)
    viewCenter669 = NXOpen.Point3d(-4.0871123257695068, 13.623707752564538, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint669, viewCenter669)
    
    scaleAboutPoint670 = NXOpen.Point3d(4.5216616247734311, -17.381971960168588, 0.0)
    viewCenter670 = NXOpen.Point3d(-4.5216616247737118, 17.381971960168588, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint670, viewCenter670)
    
    scaleAboutPoint671 = NXOpen.Point3d(5.6520770309668125, -21.727464950210734, 0.0)
    viewCenter671 = NXOpen.Point3d(-5.6520770309671029, 21.727464950210734, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint671, viewCenter671)
    
    scaleAboutPoint672 = NXOpen.Point3d(7.0650962887085447, -27.15933118776341, 0.0)
    viewCenter672 = NXOpen.Point3d(-7.0650962887088467, 27.15933118776341, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint672, viewCenter672)
    
    scaleAboutPoint673 = NXOpen.Point3d(12.272164007984134, -26.379417961087828, 0.0)
    viewCenter673 = NXOpen.Point3d(-12.272164007984436, 26.379417961087828, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint673, viewCenter673)
    
    rotMatrix68 = NXOpen.Matrix3x3()
    
    rotMatrix68.Xx = -0.85641805700932905
    rotMatrix68.Xy = 0.28441925826507036
    rotMatrix68.Xz = -0.4308756168040983
    rotMatrix68.Yx = -0.42517120337812042
    rotMatrix68.Yy = 0.084900446304700297
    rotMatrix68.Yz = 0.90112227918038967
    rotMatrix68.Zx = 0.29287806241909575
    rotMatrix68.Zy = 0.95493329596637599
    rotMatrix68.Zz = 0.04821660303697653
    translation68 = NXOpen.Point3d(-89.145075331847011, -25.588343059353146, 22.83940671729248)
    modelingView3.SetRotationTranslationScale(rotMatrix68, translation68, 0.92275222685250657)
    
    scaleAboutPoint674 = NXOpen.Point3d(1.290297617661764, -1.7203968235493969, 0.0)
    viewCenter674 = NXOpen.Point3d(-1.2902976176620478, 1.7203968235493969, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint674, viewCenter674)
    
    scaleAboutPoint675 = NXOpen.Point3d(3.5554867686681986, 2.2938624313989942, 0.0)
    viewCenter675 = NXOpen.Point3d(-3.5554867686685014, -2.2938624313989942, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint675, viewCenter675)
    
    scaleAboutPoint676 = NXOpen.Point3d(5.5970243326132625, 4.0371978792621821, 0.0)
    viewCenter676 = NXOpen.Point3d(-5.5970243326135041, -4.0371978792621821, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint676, viewCenter676)
    
    rotMatrix69 = NXOpen.Matrix3x3()
    
    rotMatrix69.Xx = -0.78199644927428869
    rotMatrix69.Xy = 0.53772534576811126
    rotMatrix69.Xz = -0.31517139121590476
    rotMatrix69.Yx = -0.54985203036324193
    rotMatrix69.Yy = -0.35705298188483109
    rotMatrix69.Yz = 0.75509993565922418
    rotMatrix69.Zx = 0.29350348895340572
    rotMatrix69.Zy = 0.76378309790523047
    rotMatrix69.Zz = 0.57488353718510898
    translation69 = NXOpen.Point3d(-99.987757514578817, -11.938693538887691, 21.729552578779643)
    modelingView3.SetRotationTranslationScale(rotMatrix69, translation69, 1.8022504430713018)
    
    rotMatrix70 = NXOpen.Matrix3x3()
    
    rotMatrix70.Xx = -0.54375784435847929
    rotMatrix70.Xy = 0.82757546980129781
    rotMatrix70.Xz = -0.13944980631674753
    rotMatrix70.Yx = -0.21171936408421782
    rotMatrix70.Yy = 0.025517939491316172
    rotMatrix70.Yz = 0.97699731096655873
    rotMatrix70.Zx = 0.81209748033742235
    rotMatrix70.Zy = 0.56077417607025515
    rotMatrix70.Zz = 0.1613381724277623
    translation70 = NXOpen.Point3d(-106.62777528106641, -19.929245401009574, 48.768753332158454)
    modelingView3.SetRotationTranslationScale(rotMatrix70, translation70, 1.8022504430713018)
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint13 = componentPositioner22.CreateConstraint(True)
    
    componentConstraint13 = constraint13
    componentConstraint13.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    constraintReference25 = componentConstraint13.CreateConstraintReference(component11, edge15, False, False, False)
    
    helpPoint25 = NXOpen.Point3d(47.259534604561011, -126.32436510022019, -0.2894342265468014)
    constraintReference25.HelpPoint = helpPoint25
    
    constraintReference26 = componentConstraint13.CreateConstraintReference(component16, edge14, False, False, False)
    
    helpPoint26 = NXOpen.Point3d(-55.399559282899681, 159.46817149377773, 4.8596476317863697)
    constraintReference26.HelpPoint = helpPoint26
    
    constraintReference26.SetFixHint(True)
    
    componentNetwork22.Solve()
    
    scaleAboutPoint677 = NXOpen.Point3d(22.975326112891572, -29.067824730687324, 0.0)
    viewCenter677 = NXOpen.Point3d(-22.975326112891818, 29.067824730687324, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint677, viewCenter677)
    
    scaleAboutPoint678 = NXOpen.Point3d(28.719157641114496, -36.334780913359154, 0.0)
    viewCenter678 = NXOpen.Point3d(-28.719157641114709, 36.334780913359154, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint678, viewCenter678)
    
    scaleAboutPoint679 = NXOpen.Point3d(35.669560808253294, -45.418476141698946, 0.0)
    viewCenter679 = NXOpen.Point3d(-35.669560808253465, 45.418476141698946, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint679, viewCenter679)
    
    scaleAboutPoint680 = NXOpen.Point3d(7.5984193040088757, -68.815872941967939, 0.0)
    viewCenter680 = NXOpen.Point3d(-7.5984193040090648, 68.815872941967939, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint680, viewCenter680)
    
    rotMatrix71 = NXOpen.Matrix3x3()
    
    rotMatrix71.Xx = -0.55230850291674483
    rotMatrix71.Xy = 0.82127257805227205
    rotMatrix71.Xz = -0.1430617703834125
    rotMatrix71.Yx = -0.47474542454386226
    rotMatrix71.Yy = -0.16880076926240431
    rotMatrix71.Yz = 0.86378416411224024
    rotMatrix71.Zx = 0.68525331044842674
    rotMatrix71.Zy = 0.54499325944069232
    rotMatrix71.Zz = 0.4831254988961739
    translation71 = NXOpen.Point3d(-83.474884204419141, -82.999196154534133, 54.623706996663074)
    modelingView3.SetRotationTranslationScale(rotMatrix71, translation71, 0.73820178148200533)
    
    scaleAboutPoint681 = NXOpen.Point3d(50.357448689304555, -86.019841177459938, 0.0)
    viewCenter681 = NXOpen.Point3d(-50.357448689304675, 86.019841177459938, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint681, viewCenter681)
    
    scaleAboutPoint682 = NXOpen.Point3d(34.838035676871236, -63.94141527524517, 0.0)
    viewCenter682 = NXOpen.Point3d(-34.838035676871328, 63.94141527524517, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint682, viewCenter682)
    
    scaleAboutPoint683 = NXOpen.Point3d(24.200248651258704, -46.106634871118409, 0.0)
    viewCenter683 = NXOpen.Point3d(-24.200248651258704, 46.106634871118409, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint683, viewCenter683)
    
    scaleAboutPoint684 = NXOpen.Point3d(21.195288866126131, -36.88530789689473, 0.0)
    viewCenter684 = NXOpen.Point3d(-21.195288866126131, 36.88530789689473, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint684, viewCenter684)
    
    scaleAboutPoint685 = NXOpen.Point3d(16.956231092900879, -29.508246317515788, 0.0)
    viewCenter685 = NXOpen.Point3d(-16.956231092900929, 29.508246317515788, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint685, viewCenter685)
    
    line26 = workPart.Lines.CreateFaceAxis(face14, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects34 = [NXOpen.TaggedObject.Null] * 1 
    objects34[0] = line26
    nErrs65 = theSession.UpdateManager.AddObjectsToDeleteList(objects34)
    
    line27 = workPart.Lines.CreateFaceAxis(face10, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint14 = componentPositioner22.CreateConstraint(True)
    
    componentConstraint14 = constraint14
    componentConstraint14.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    constraintReference27 = componentConstraint14.CreateConstraintReference(component11, edge17, False, False, False)
    
    helpPoint27 = NXOpen.Point3d(-52.399559282899673, 161.59120036598648, 2.7953742268286765)
    constraintReference27.HelpPoint = helpPoint27
    
    constraintReference28 = componentConstraint14.CreateConstraintReference(component19, edge16, False, False, False)
    
    helpPoint28 = NXOpen.Point3d(-81.417013321425429, 72.295314117283752, 1.0444871992833977)
    constraintReference28.HelpPoint = helpPoint28
    
    constraintReference28.SetFixHint(True)
    
    objects35 = [NXOpen.TaggedObject.Null] * 1 
    objects35[0] = line27
    nErrs66 = theSession.UpdateManager.AddObjectsToDeleteList(objects35)
    
    componentNetwork22.Solve()
    
    line28 = workPart.Lines.CreateFaceAxis(face13, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint686 = NXOpen.Point3d(9.2194918842785736, -27.482307018104244, 0.0)
    viewCenter686 = NXOpen.Point3d(-9.2194918842786215, 27.482307018104244, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint686, viewCenter686)
    
    scaleAboutPoint687 = NXOpen.Point3d(10.496714486081482, -35.233726946287589, 0.0)
    viewCenter687 = NXOpen.Point3d(-10.49671448608153, 35.233726946287589, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint687, viewCenter687)
    
    rotMatrix72 = NXOpen.Matrix3x3()
    
    rotMatrix72.Xx = 0.56701634796414813
    rotMatrix72.Xy = 0.76396828825403451
    rotMatrix72.Xz = 0.30796901740855692
    rotMatrix72.Yx = -0.42018508638761193
    rotMatrix72.Yy = -0.053311642772387736
    rotMatrix72.Yz = 0.90587105148709546
    rotMatrix72.Zx = 0.70847509082453186
    rotMatrix72.Zy = -0.64304768352518149
    rotMatrix72.Zz = 0.29077950820865145
    translation72 = NXOpen.Point3d(-47.826130065633443, -48.972834181048015, 113.2954065670893)
    modelingView3.SetRotationTranslationScale(rotMatrix72, translation72, 1.4418003544570419)
    
    line29 = workPart.Lines.CreateFaceAxis(face10, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects36 = [NXOpen.TaggedObject.Null] * 1 
    objects36[0] = line29
    nErrs67 = theSession.UpdateManager.AddObjectsToDeleteList(objects36)
    
    objects37 = [NXOpen.TaggedObject.Null] * 1 
    objects37[0] = line28
    nErrs68 = theSession.UpdateManager.AddObjectsToDeleteList(objects37)
    
    rotMatrix73 = NXOpen.Matrix3x3()
    
    rotMatrix73.Xx = -0.89740818935627309
    rotMatrix73.Xy = 0.34161609809272059
    rotMatrix73.Xz = -0.27920777782897582
    rotMatrix73.Yx = -0.3264527190322557
    rotMatrix73.Yy = -0.088426068239606526
    rotMatrix73.Yz = 0.94106825081506362
    rotMatrix73.Zx = 0.29679481786704892
    rotMatrix73.Zy = 0.9356704932718467
    rotMatrix73.Zz = 0.19087578187835949
    translation73 = NXOpen.Point3d(-103.69968329345055, -42.496044221159622, 18.365391053969912)
    modelingView3.SetRotationTranslationScale(rotMatrix73, translation73, 1.4418003544570419)
    
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint15 = componentPositioner22.CreateConstraint(True)
    
    componentConstraint15 = constraint15
    componentConstraint15.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    constraintReference29 = componentConstraint15.CreateConstraintReference(component19, edge10, False, False, False)
    
    helpPoint29 = NXOpen.Point3d(-81.196367915227029, 16.295314117283752, 0.75311336709503496)
    constraintReference29.HelpPoint = helpPoint29
    
    constraintReference30 = componentConstraint15.CreateConstraintReference(component16, edge13, False, False, False)
    
    helpPoint30 = NXOpen.Point3d(-81.077688395464918, 125.29531411728372, 0.49516089734249341)
    constraintReference30.HelpPoint = helpPoint30
    
    constraintReference30.SetFixHint(True)
    
    componentNetwork22.Solve()
    
    rotMatrix74 = NXOpen.Matrix3x3()
    
    rotMatrix74.Xx = 0.030080503201697185
    rotMatrix74.Xy = 0.99798283844657731
    rotMatrix74.Xz = -0.055905433485876864
    rotMatrix74.Yx = -0.10516611715577447
    rotMatrix74.Yy = 0.05878023487244461
    rotMatrix74.Yz = 0.99271595725601103
    rotMatrix74.Zx = 0.99399962330451097
    rotMatrix74.Zy = -0.023982038162995538
    rotMatrix74.Zz = 0.1067221191508021
    translation74 = NXOpen.Point3d(-84.335941834882036, -37.421176383608412, 103.28867204320468)
    modelingView3.SetRotationTranslationScale(rotMatrix74, translation74, 1.4418003544570419)
    
    modelingView3.Fit()
    
    componentPositioner22.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner22.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId134, None)
    
    theSession.UndoToMark(markId133, None)
    
    theSession.DeleteUndoMark(markId133, None)
    
    theSession.DeleteUndoMark(markId132, None)
    
    scaleAboutPoint688 = NXOpen.Point3d(17.228528466764903, -23.906687709582521, 0.0)
    viewCenter688 = NXOpen.Point3d(-17.228528466764903, 23.906687709582521, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint688, viewCenter688)
    
    scaleAboutPoint689 = NXOpen.Point3d(21.675958046540512, -29.883359636978142, 0.0)
    viewCenter689 = NXOpen.Point3d(-21.675958046540512, 29.883359636978142, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint689, viewCenter689)
    
    scaleAboutPoint690 = NXOpen.Point3d(27.445691215886683, -37.354199546222695, 0.0)
    viewCenter690 = NXOpen.Point3d(-27.445691215886683, 37.354199546222695, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint690, viewCenter690)
    
    scaleAboutPoint691 = NXOpen.Point3d(35.40318795020525, -54.803696517345671, 0.0)
    viewCenter691 = NXOpen.Point3d(-35.40318795020525, 54.803696517345671, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint691, viewCenter691)
    
    scaleAboutPoint692 = NXOpen.Point3d(44.25398493775657, -68.504620646682085, 0.0)
    viewCenter692 = NXOpen.Point3d(-44.25398493775652, 68.504620646682085, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint692, viewCenter692)
    
    rotMatrix75 = NXOpen.Matrix3x3()
    
    rotMatrix75.Xx = 0.88464790328623266
    rotMatrix75.Xy = 0.4617833097112517
    rotMatrix75.Xz = -0.064453565327236159
    rotMatrix75.Yx = -0.012684302328768516
    rotMatrix75.Yy = 0.16201941974519946
    rotMatrix75.Yz = 0.98670604340900925
    rotMatrix75.Zx = 0.46608711169233524
    rotMatrix75.Zy = -0.87206988395285645
    rotMatrix75.Zz = 0.1491875390799999
    translation75 = NXOpen.Point3d(33.736888355538674, -76.189249171081983, 72.979247551640483)
    modelingView3.SetRotationTranslationScale(rotMatrix75, translation75, 0.77245397707679619)
    
    scaleAboutPoint693 = NXOpen.Point3d(13.872185680953157, -101.04431545385604, 0.0)
    viewCenter693 = NXOpen.Point3d(-13.872185680953129, 101.04431545385604, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint693, viewCenter693)
    
    scaleAboutPoint694 = NXOpen.Point3d(11.371767027349202, -80.287415397911431, 0.0)
    viewCenter694 = NXOpen.Point3d(-11.371767027349202, 80.287415397911431, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint694, viewCenter694)
    
    scaleAboutPoint695 = NXOpen.Point3d(9.5358431940181525, -64.229932318329134, 0.0)
    viewCenter695 = NXOpen.Point3d(-9.5358431940181525, 64.229932318329134, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint695, viewCenter695)
    
    scaleAboutPoint696 = NXOpen.Point3d(7.8040463840700092, -51.033202196952111, 0.0)
    viewCenter696 = NXOpen.Point3d(-7.8040463840700092, 51.033202196952111, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint696, viewCenter696)
    
    scaleAboutPoint697 = NXOpen.Point3d(9.7506736843661077, -36.477340401945135, 0.0)
    viewCenter697 = NXOpen.Point3d(-9.7506736843661539, 36.477340401945135, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint697, viewCenter697)
    
    scaleAboutPoint698 = NXOpen.Point3d(7.8005389474928863, -28.845158410153644, 0.0)
    viewCenter698 = NXOpen.Point3d(-7.8005389474929236, 28.845158410153644, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint698, viewCenter698)
    
    scaleAboutPoint699 = NXOpen.Point3d(6.240431157994295, -23.076126728122919, 0.0)
    viewCenter699 = NXOpen.Point3d(-6.2404311579943545, 23.076126728122919, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint699, viewCenter699)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner23 = workPart.ComponentAssembly.Positioner
    
    componentPositioner23.ClearNetwork()
    
    componentPositioner23.PrimaryArrangement = arrangement2
    
    componentPositioner23.BeginAssemblyConstraints()
    
    allowInterpartPositioning23 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression230 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression231 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression232 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression233 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression234 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression235 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression236 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression237 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network23 = componentPositioner23.EstablishNetwork()
    
    componentNetwork23 = network23
    componentNetwork23.MoveObjectsState = True
    
    componentNetwork23.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork23.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId139, "Assembly Constraints Dialog")
    
    componentNetwork23.MoveObjectsState = True
    
    componentNetwork23.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    line30 = workPart.Lines.CreateFaceAxis(face15, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects38 = [NXOpen.TaggedObject.Null] * 1 
    objects38[0] = line30
    nErrs69 = theSession.UpdateManager.AddObjectsToDeleteList(objects38)
    
    scaleAboutPoint700 = NXOpen.Point3d(28.266010482541141, -7.0395655077231183, 0.0)
    viewCenter700 = NXOpen.Point3d(-28.266010482541212, 7.0395655077231183, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint700, viewCenter700)
    
    scaleAboutPoint701 = NXOpen.Point3d(35.332513103176424, -8.7994568846538961, 0.0)
    viewCenter701 = NXOpen.Point3d(-35.332513103176495, 8.7994568846538961, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint701, viewCenter701)
    
    scaleAboutPoint702 = NXOpen.Point3d(44.165641378970548, -10.999321105817371, 0.0)
    viewCenter702 = NXOpen.Point3d(-44.165641378970626, 10.999321105817371, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint702, viewCenter702)
    
    rotMatrix76 = NXOpen.Matrix3x3()
    
    rotMatrix76.Xx = 0.99309919743363351
    rotMatrix76.Xy = 0.11148742863016223
    rotMatrix76.Xz = -0.036394193411924201
    rotMatrix76.Yx = 0.025469843771294468
    rotMatrix76.Yy = 0.097889578169887692
    rotMatrix76.Yz = 0.99487130702618365
    rotMatrix76.Zx = 0.11447825607920513
    rotMatrix76.Zy = -0.9889328509778369
    rotMatrix76.Zz = 0.094374494127959063
    translation76 = NXOpen.Point3d(62.248118972545115, -2.7463976923965223, 68.693266193132274)
    modelingView3.SetRotationTranslationScale(rotMatrix76, translation76, 1.885873967472647)
    
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint16 = componentPositioner23.CreateConstraint(True)
    
    componentConstraint16 = constraint16
    componentConstraint16.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    constraintReference31 = componentConstraint16.CreateConstraintReference(component11, edge15, False, False, False)
    
    helpPoint31 = NXOpen.Point3d(44.858448559123715, -126.32436510022019, 1.1774752743683694)
    constraintReference31.HelpPoint = helpPoint31
    
    constraintReference32 = componentConstraint16.CreateConstraintReference(component19, edge10, False, False, False)
    
    helpPoint32 = NXOpen.Point3d(-83.398395976035033, 16.295314117283752, 1.196390672315931)
    constraintReference32.HelpPoint = helpPoint32
    
    constraintReference32.SetFixHint(True)
    
    componentNetwork23.Solve()
    
    scaleAboutPoint703 = NXOpen.Point3d(19.852091026443219, -23.008783945842389, 0.0)
    viewCenter703 = NXOpen.Point3d(-19.852091026443311, 23.008783945842389, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint703, viewCenter703)
    
    scaleAboutPoint704 = NXOpen.Point3d(24.815113783054024, -28.93635176115836, 0.0)
    viewCenter704 = NXOpen.Point3d(-24.815113783054137, 28.93635176115836, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint704, viewCenter704)
    
    rotMatrix77 = NXOpen.Matrix3x3()
    
    rotMatrix77.Xx = 0.29691776578380125
    rotMatrix77.Xy = 0.91976181086909559
    rotMatrix77.Xz = -0.25666720014203742
    rotMatrix77.Yx = -0.35276106316031869
    rotMatrix77.Yy = 0.35542623698987402
    rotMatrix77.Yz = 0.86558178260475072
    rotMatrix77.Zx = 0.88735532492905822
    rotMatrix77.Zy = -0.1664644145936757
    rotMatrix77.Zz = 0.42998851844442082
    translation77 = NXOpen.Point3d(29.762893927790437, -32.869252401586301, 54.844878890758068)
    modelingView3.SetRotationTranslationScale(rotMatrix77, translation77, 1.2069593391824942)
    
    scaleAboutPoint705 = NXOpen.Point3d(4.4939031144222685, -46.692749432778363, 0.0)
    viewCenter705 = NXOpen.Point3d(-4.4939031144224133, 46.692749432778363, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint705, viewCenter705)
    
    scaleAboutPoint706 = NXOpen.Point3d(46.720151281037047, -14.522979577096697, 0.0)
    viewCenter706 = NXOpen.Point3d(-46.720151281037133, 14.522979577096697, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint706, viewCenter706)
    
    scaleAboutPoint707 = NXOpen.Point3d(36.937691452690849, -14.248961094509962, 0.0)
    viewCenter707 = NXOpen.Point3d(-36.937691452690991, 14.248961094509962, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint707, viewCenter707)
    
    scaleAboutPoint708 = NXOpen.Point3d(24.113626467632013, -13.328258993018451, 0.0)
    viewCenter708 = NXOpen.Point3d(-24.11362646763213, 13.328258993018451, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint708, viewCenter708)
    
    scaleAboutPoint709 = NXOpen.Point3d(18.028224006345937, -9.5402274897394559, 0.0)
    viewCenter709 = NXOpen.Point3d(-18.028224006346075, 9.5402274897394559, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint709, viewCenter709)
    
    scaleAboutPoint710 = NXOpen.Point3d(14.42257920507673, -7.6321819917915628, 0.0)
    viewCenter710 = NXOpen.Point3d(-14.422579205076877, 7.6321819917915628, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint710, viewCenter710)
    
    rotMatrix78 = NXOpen.Matrix3x3()
    
    rotMatrix78.Xx = -0.096278351878400698
    rotMatrix78.Xy = 0.89476322329159652
    rotMatrix78.Xz = -0.4360381327411707
    rotMatrix78.Yx = -0.59730503880210983
    rotMatrix78.Yy = 0.29849101785590071
    rotMatrix78.Yz = 0.74439895411060064
    rotMatrix78.Zx = 0.79621427366079345
    rotMatrix78.Zy = 0.33211727823793807
    rotMatrix78.Zz = 0.50570835855721752
    translation78 = NXOpen.Point3d(2.5651179765924681, -38.720025215672322, 33.643533093782551)
    modelingView3.SetRotationTranslationScale(rotMatrix78, translation78, 1.8858739674726472)
    
    scaleAboutPoint711 = NXOpen.Point3d(65.4487665288747, -22.447594093504826, 0.0)
    viewCenter711 = NXOpen.Point3d(-65.448766528874842, 22.447594093504826, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint711, viewCenter711)
    
    scaleAboutPoint712 = NXOpen.Point3d(81.810958161093396, -28.76097993230298, 0.0)
    viewCenter712 = NXOpen.Point3d(-81.810958161093509, 28.76097993230298, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint712, viewCenter712)
    
    scaleAboutPoint713 = NXOpen.Point3d(102.26369770136678, -36.828084059656163, 0.0)
    viewCenter713 = NXOpen.Point3d(-102.26369770136689, 36.828084059656163, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint713, viewCenter713)
    
    scaleAboutPoint714 = NXOpen.Point3d(154.40941493762102, -58.639955273559814, 0.0)
    viewCenter714 = NXOpen.Point3d(-154.40941493762119, 58.639955273559814, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint714, viewCenter714)
    
    scaleAboutPoint715 = NXOpen.Point3d(193.69681487849309, -73.984990298416506, 0.0)
    viewCenter715 = NXOpen.Point3d(-193.6968148784932, 73.984990298416506, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint715, viewCenter715)
    
    rotMatrix79 = NXOpen.Matrix3x3()
    
    rotMatrix79.Xx = -0.001887767418882684
    rotMatrix79.Xy = -0.67475384005521477
    rotMatrix79.Xz = -0.73804044039937988
    rotMatrix79.Yx = -0.31374543221300422
    rotMatrix79.Yy = -0.70037613454809955
    rotMatrix79.Yz = 0.64112173096919156
    rotMatrix79.Zx = -0.94950526070140417
    rotMatrix79.Zy = 0.23276710567904149
    rotMatrix79.Zz = -0.21037878793774648
    translation79 = NXOpen.Point3d(214.60381644005889, -49.480598127230721, 1.9827097769032527)
    modelingView3.SetRotationTranslationScale(rotMatrix79, translation79, 0.61796318166143727)
    
    scaleAboutPoint716 = NXOpen.Point3d(129.516548410133, -148.56939602749162, 0.0)
    viewCenter716 = NXOpen.Point3d(-129.51654841013314, 148.56939602749162, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint716, viewCenter716)
    
    scaleAboutPoint717 = NXOpen.Point3d(103.95576183133981, -117.1429013058262, 0.0)
    viewCenter717 = NXOpen.Point3d(-103.95576183133996, 117.1429013058262, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint717, viewCenter717)
    
    scaleAboutPoint718 = NXOpen.Point3d(82.890590982485065, -92.618247114314158, 0.0)
    viewCenter718 = NXOpen.Point3d(-82.89059098248525, 92.618247114314158, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint718, viewCenter718)
    
    scaleAboutPoint719 = NXOpen.Point3d(47.460001184021138, -58.311133094455698, 0.0)
    viewCenter719 = NXOpen.Point3d(-47.460001184021323, 58.311133094455698, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint719, viewCenter719)
    
    scaleAboutPoint720 = NXOpen.Point3d(37.79262911836144, -46.64890647556458, 0.0)
    viewCenter720 = NXOpen.Point3d(-37.792629118361646, 46.64890647556458, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint720, viewCenter720)
    
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint17 = componentPositioner23.CreateConstraint(True)
    
    componentConstraint17 = constraint17
    componentConstraint17.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    constraintReference33 = componentConstraint17.CreateConstraintReference(component11, edge17, False, False, False)
    
    helpPoint33 = NXOpen.Point3d(-81.019826301937627, 19.295314117283766, -0.27925018136221352)
    constraintReference33.HelpPoint = helpPoint33
    
    constraintReference34 = componentConstraint17.CreateConstraintReference(component16, edge13, False, False, False)
    
    helpPoint34 = NXOpen.Point3d(-105.39955928289965, 160.86095603806902, 5.4910566226674922)
    constraintReference34.HelpPoint = helpPoint34
    
    constraintReference34.SetFixHint(True)
    
    componentNetwork23.Solve()
    
    componentPositioner23.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner23.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId140, None)
    
    theSession.UndoToMark(markId139, None)
    
    theSession.DeleteUndoMark(markId139, None)
    
    theSession.DeleteUndoMark(markId138, None)
    
    scaleAboutPoint721 = NXOpen.Point3d(9.7506736843660153, -6.8745756911357638, 0.0)
    viewCenter721 = NXOpen.Point3d(-9.7506736843662249, 6.8745756911357638, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint721, viewCenter721)
    
    scaleAboutPoint722 = NXOpen.Point3d(12.539085763168552, -8.5932196139197039, 0.0)
    viewCenter722 = NXOpen.Point3d(-12.539085763168783, 8.5932196139197039, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint722, viewCenter722)
    
    scaleAboutPoint723 = NXOpen.Point3d(89.768454895411907, -32.005358766129675, 0.0)
    viewCenter723 = NXOpen.Point3d(-89.768454895412134, 32.005358766129675, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint723, viewCenter723)
    
    scaleAboutPoint724 = NXOpen.Point3d(112.2105686192649, -40.006698457662097, 0.0)
    viewCenter724 = NXOpen.Point3d(-112.21056861926517, 40.006698457662097, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint724, viewCenter724)
    
    rotMatrix80 = NXOpen.Matrix3x3()
    
    rotMatrix80.Xx = -0.21351538898792385
    rotMatrix80.Xy = -0.56518154387406006
    rotMatrix80.Xz = -0.79685695148468461
    rotMatrix80.Yx = -0.47566783835412746
    rotMatrix80.Yy = -0.65230903330272016
    rotMatrix80.Yz = 0.59011272874525911
    rotMatrix80.Zx = -0.85331781079550906
    rotMatrix80.Zy = 0.50503737241495039
    rotMatrix80.Zz = -0.12956066626625684
    translation80 = NXOpen.Point3d(181.78023405102641, 16.109842355824775, -6.3475731274315983)
    modelingView3.SetRotationTranslationScale(rotMatrix80, translation80, 0.77245397707679619)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner24 = workPart.ComponentAssembly.Positioner
    
    componentPositioner24.ClearNetwork()
    
    componentPositioner24.PrimaryArrangement = arrangement2
    
    componentPositioner24.BeginAssemblyConstraints()
    
    allowInterpartPositioning24 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression238 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression239 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression240 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression241 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression242 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression243 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression244 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression245 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network24 = componentPositioner24.EstablishNetwork()
    
    componentNetwork24 = network24
    componentNetwork24.MoveObjectsState = True
    
    componentNetwork24.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork24.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId144, "Assembly Constraints Dialog")
    
    componentNetwork24.MoveObjectsState = True
    
    componentNetwork24.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    scaleAboutPoint725 = NXOpen.Point3d(126.56228664474477, -18.153724471370868, 0.0)
    viewCenter725 = NXOpen.Point3d(-126.562286644745, 18.153724471370868, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint725, viewCenter725)
    
    scaleAboutPoint726 = NXOpen.Point3d(229.2764022268635, -11.13200085508579, 0.0)
    viewCenter726 = NXOpen.Point3d(-229.27640222686364, 11.13200085508579, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint726, viewCenter726)
    
    scaleAboutPoint727 = NXOpen.Point3d(184.44869109119108, -4.4528003420345419, 0.0)
    viewCenter727 = NXOpen.Point3d(-184.44869109119108, 4.4528003420345419, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint727, viewCenter727)
    
    scaleAboutPoint728 = NXOpen.Point3d(164.82211727591672, 26.579792810912547, 0.0)
    viewCenter728 = NXOpen.Point3d(-164.82211727591678, -26.579792810912547, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint728, viewCenter728)
    
    scaleAboutPoint729 = NXOpen.Point3d(132.95376775108025, 23.017552537285201, 0.0)
    viewCenter729 = NXOpen.Point3d(-132.95376775108033, -23.017552537285201, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint729, viewCenter729)
    
    scaleAboutPoint730 = NXOpen.Point3d(106.71375785857519, 19.290901174105713, 0.0)
    viewCenter730 = NXOpen.Point3d(-106.71375785857525, -19.290901174105713, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint730, viewCenter730)
    
    scaleAboutPoint731 = NXOpen.Point3d(85.371006286860208, 16.134208254706618, 0.0)
    viewCenter731 = NXOpen.Point3d(-85.371006286860251, -16.134208254706987, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint731, viewCenter731)
    
    scaleAboutPoint732 = NXOpen.Point3d(70.092612556968518, 7.5199440213239743, 0.0)
    viewCenter732 = NXOpen.Point3d(-70.092612556968547, -7.5199440213242701, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint732, viewCenter732)
    
    rotMatrix81 = NXOpen.Matrix3x3()
    
    rotMatrix81.Xx = 0.95649675168256265
    rotMatrix81.Xy = -0.27354491155250249
    rotMatrix81.Xz = -0.10142556573385317
    rotMatrix81.Yx = 0.074319873961085914
    rotMatrix81.Yy = -0.10772097941841707
    rotMatrix81.Yz = 0.9913993882021217
    rotMatrix81.Zx = -0.28211791923787177
    rotMatrix81.Zy = -0.95580822969718293
    rotMatrix81.Zz = -0.082704943552502144
    translation81 = NXOpen.Point3d(28.697320399469177, -14.669781013965355, 59.742810099270756)
    modelingView3.SetRotationTranslationScale(rotMatrix81, translation81, 2.9466780741760115)
    
    rotMatrix82 = NXOpen.Matrix3x3()
    
    rotMatrix82.Xx = -0.63976186861894269
    rotMatrix82.Xy = -0.33702226994136175
    rotMatrix82.Xz = -0.69073927137869506
    rotMatrix82.Yx = -0.5726210050460343
    rotMatrix82.Yy = -0.39045280215797884
    rotMatrix82.Yz = 0.72086877714813768
    rotMatrix82.Zx = -0.51264991567469109
    rotMatrix82.Zy = 0.8567161716989784
    rotMatrix82.Zz = 0.056810783379372481
    translation82 = NXOpen.Point3d(-2.2046056282826179, -17.611164125256359, -12.643835339055727)
    modelingView3.SetRotationTranslationScale(rotMatrix82, translation82, 2.9466780741760115)
    
    scaleAboutPoint733 = NXOpen.Point3d(9.2035135783369348, -8.0811338736618143, 0.0)
    viewCenter733 = NXOpen.Point3d(-9.2035135783369633, 8.0811338736615763, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint733, viewCenter733)
    
    rotMatrix83 = NXOpen.Matrix3x3()
    
    rotMatrix83.Xx = -0.33729906321834757
    rotMatrix83.Xy = -0.77097716979607478
    rotMatrix83.Xz = -0.54020694701684357
    rotMatrix83.Yx = -0.48698496065721258
    rotMatrix83.Yy = -0.34819246159002309
    rotMatrix83.Yz = 0.80100415591029983
    rotMatrix83.Zx = -0.80565190376844298
    rotMatrix83.Zy = 0.53325061026229781
    rotMatrix83.Zz = -0.25800929558674618
    translation83 = NXOpen.Point3d(21.172700285992789, -20.078302848027967, -4.1667271657718388)
    modelingView3.SetRotationTranslationScale(rotMatrix83, translation83, 2.3573424593408094)
    
    scaleAboutPoint734 = NXOpen.Point3d(-38.104790973724292, -31.42663173090677, 0.0)
    viewCenter734 = NXOpen.Point3d(38.104790973724256, 31.426631730906475, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint734, viewCenter734)
    
    scaleAboutPoint735 = NXOpen.Point3d(-32.638801811955886, -24.2434016209852, 0.0)
    viewCenter735 = NXOpen.Point3d(32.638801811955851, 24.243401620984962, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint735, viewCenter735)
    
    scaleAboutPoint736 = NXOpen.Point3d(-29.343494999029396, -18.317236780299996, 0.0)
    viewCenter736 = NXOpen.Point3d(29.34349499902935, 18.317236780299808, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint736, viewCenter736)
    
    scaleAboutPoint737 = NXOpen.Point3d(-36.679368748786743, -22.896545975374998, 0.0)
    viewCenter737 = NXOpen.Point3d(36.679368748786686, 22.89654597537476, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint737, viewCenter737)
    
    scaleAboutPoint738 = NXOpen.Point3d(-45.849210935983443, -26.937112912205851, 0.0)
    viewCenter738 = NXOpen.Point3d(45.849210935983372, 26.937112912205553, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint738, viewCenter738)
    
    scaleAboutPoint739 = NXOpen.Point3d(-57.311513669979277, -33.250498751003867, 0.0)
    viewCenter739 = NXOpen.Point3d(57.311513669979234, 33.250498751003867, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint739, viewCenter739)
    
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint18 = componentPositioner24.CreateConstraint(True)
    
    componentConstraint18 = constraint18
    componentConstraint18.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    constraintReference35 = componentConstraint18.CreateConstraintReference(component1, edge11, False, False, False)
    
    helpPoint35 = NXOpen.Point3d(-5.6614063255126652, -35.950143111867703, 1.3112430602865877)
    constraintReference35.HelpPoint = helpPoint35
    
    constraintReference36 = componentConstraint18.CreateConstraintReference(component16, edge13, False, False, False)
    
    helpPoint36 = NXOpen.Point3d(-105.39955928289965, 162.18392760365052, 4.2005980758879975)
    constraintReference36.HelpPoint = helpPoint36
    
    constraintReference36.SetFixHint(True)
    
    componentNetwork24.Solve()
    
    rotMatrix84 = NXOpen.Matrix3x3()
    
    rotMatrix84.Xx = -0.23161554287557992
    rotMatrix84.Xy = -0.8714082901872463
    rotMatrix84.Xz = -0.43243708454685931
    rotMatrix84.Yx = -0.58939253125890945
    rotMatrix84.Yy = -0.22794718277456577
    rotMatrix84.Yz = 0.77502033906301637
    rotMatrix84.Zx = -0.77393196367294692
    rotMatrix84.Zy = 0.43438194444299255
    rotMatrix84.Zz = -0.4608054274281706
    translation84 = NXOpen.Point3d(-2.2519949593256854, -40.85988667161935, 3.2131982174643987)
    modelingView3.SetRotationTranslationScale(rotMatrix84, translation84, 1.5086991739781181)
    
    scaleAboutPoint740 = NXOpen.Point3d(23.061395494498985, -59.801793639727386, 0.0)
    viewCenter740 = NXOpen.Point3d(-23.061395494499042, 59.801793639727386, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint740, viewCenter740)
    
    scaleAboutPoint741 = NXOpen.Point3d(33.649469661650144, -74.094597691451298, 0.0)
    viewCenter741 = NXOpen.Point3d(-33.649469661650215, 74.094597691451298, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint741, viewCenter741)
    
    rotMatrix85 = NXOpen.Matrix3x3()
    
    rotMatrix85.Xx = 0.66817488571310202
    rotMatrix85.Xy = -0.49506171974972346
    rotMatrix85.Xz = 0.55538834678153526
    rotMatrix85.Yx = -0.70124924822247992
    rotMatrix85.Yy = -0.16964645491135269
    rotMatrix85.Yz = 0.69243741392519698
    rotMatrix85.Zx = -0.24857959282629524
    rotMatrix85.Zy = -0.85213495056502231
    rotMatrix85.Zz = -0.46051515942024851
    translation85 = NXOpen.Point3d(7.4417409209796972, -78.103709036065567, 62.618399764392151)
    modelingView3.SetRotationTranslationScale(rotMatrix85, translation85, 0.96556747134599574)
    
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs70 = theSession.UpdateManager.DoUpdate(markId145)
    
    componentNetwork24.Solve()
    
    componentPositioner24.ClearNetwork()
    
    nErrs71 = theSession.UpdateManager.AddToDeleteList(componentNetwork24)
    
    componentPositioner24.DeleteNonPersistentConstraints()
    
    nErrs72 = theSession.UpdateManager.DoUpdate(markId145)
    
    theSession.DeleteUndoMark(markId147, None)
    
    theSession.SetUndoMarkName(markId144, "Assembly Constraints")
    
    componentPositioner24.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner24.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId145, None)
    
    theSession.DeleteUndoMark(markId146, None)
    
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner25 = workPart.ComponentAssembly.Positioner
    
    componentPositioner25.ClearNetwork()
    
    componentPositioner25.PrimaryArrangement = arrangement2
    
    componentPositioner25.BeginAssemblyConstraints()
    
    allowInterpartPositioning25 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression246 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression247 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression248 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression249 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression250 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression251 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression252 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression253 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network25 = componentPositioner25.EstablishNetwork()
    
    componentNetwork25 = network25
    componentNetwork25.MoveObjectsState = True
    
    componentNetwork25.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork25.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId148, "Assembly Constraints Dialog")
    
    componentNetwork25.MoveObjectsState = True
    
    componentNetwork25.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    # ----------------------------------------------
    #   Dialog Begin Assembly Constraints
    # ----------------------------------------------
    rotMatrix86 = NXOpen.Matrix3x3()
    
    rotMatrix86.Xx = 0.60954382380065486
    rotMatrix86.Xy = 0.35719876469310119
    rotMatrix86.Xz = 0.70771842520044392
    rotMatrix86.Yx = -0.68974898621992775
    rotMatrix86.Yy = -0.20109366383494717
    rotMatrix86.Yz = 0.69556284717774897
    rotMatrix86.Zx = 0.39077188086536485
    rotMatrix86.Zy = -0.91212410387356602
    rotMatrix86.Zz = 0.12380208503004067
    translation86 = NXOpen.Point3d(-26.586698243315212, -76.733685998657108, 72.798175175009845)
    modelingView3.SetRotationTranslationScale(rotMatrix86, translation86, 0.96556747134599574)
    
    scaleAboutPoint742 = NXOpen.Point3d(-40.691744664129089, -94.810394975007711, 0.0)
    viewCenter742 = NXOpen.Point3d(40.691744664128976, 94.810394975007711, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint742, viewCenter742)
    
    scaleAboutPoint743 = NXOpen.Point3d(-32.772610517372684, -74.971456835728731, 0.0)
    viewCenter743 = NXOpen.Point3d(32.77261051737252, 74.971456835728731, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint743, viewCenter743)
    
    line31 = workPart.Lines.CreateFaceAxis(face14, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint744 = NXOpen.Point3d(-27.094947558175715, -58.398819008883478, 0.0)
    viewCenter744 = NXOpen.Point3d(27.094947558175541, 58.398819008883478, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint744, viewCenter744)
    
    scaleAboutPoint745 = NXOpen.Point3d(-21.675958046540597, -46.438460280937818, 0.0)
    viewCenter745 = NXOpen.Point3d(21.675958046540398, 46.438460280937448, 0.0)
    modelingView3.ZoomAboutPoint(1.25, scaleAboutPoint745, viewCenter745)
    
    objects39 = [NXOpen.TaggedObject.Null] * 1 
    objects39[0] = line31
    nErrs73 = theSession.UpdateManager.AddObjectsToDeleteList(objects39)
    
    rotMatrix87 = NXOpen.Matrix3x3()
    
    rotMatrix87.Xx = 0.37040745214978577
    rotMatrix87.Xy = 0.71943167485458237
    rotMatrix87.Xz = 0.58755117616070851
    rotMatrix87.Yx = -0.63513702374480918
    rotMatrix87.Yy = -0.2653959545370172
    rotMatrix87.Yz = 0.72537297191442707
    rotMatrix87.Zx = 0.67778999731516154
    rotMatrix87.Zy = -0.64185905970961599
    rotMatrix87.Zz = 0.35863305342396723
    translation87 = NXOpen.Point3d(-19.464112183680182, -18.541744560997692, 67.248733517882599)
    modelingView3.SetRotationTranslationScale(rotMatrix87, translation87, 2.3573424593408099)
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint19 = componentPositioner25.CreateConstraint(True)
    
    componentConstraint19 = constraint19
    componentConstraint19.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    constraintReference37 = componentConstraint19.CreateConstraintReference(component11, edge15, False, False, False)
    
    helpPoint37 = NXOpen.Point3d(44.89809528832113, -126.32436510022019, -1.2077092303785311)
    constraintReference37.HelpPoint = helpPoint37
    
    constraintReference38 = componentConstraint19.CreateConstraintReference(component16, edge14, False, False, False)
    
    helpPoint38 = NXOpen.Point3d(-55.399559282899681, 160.10919464577702, 2.6201402548447192)
    constraintReference38.HelpPoint = helpPoint38
    
    constraintReference38.SetFixHint(True)
    
    componentNetwork25.Solve()
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs74 = theSession.UpdateManager.DoUpdate(markId149)
    
    componentNetwork25.Solve()
    
    componentPositioner25.ClearNetwork()
    
    nErrs75 = theSession.UpdateManager.AddToDeleteList(componentNetwork25)
    
    componentPositioner25.DeleteNonPersistentConstraints()
    
    nErrs76 = theSession.UpdateManager.DoUpdate(markId149)
    
    theSession.DeleteUndoMark(markId151, None)
    
    theSession.SetUndoMarkName(markId148, "Assembly Constraints")
    
    componentPositioner25.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner25.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId149, None)
    
    theSession.DeleteUndoMark(markId150, None)
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner26 = workPart.ComponentAssembly.Positioner
    
    componentPositioner26.ClearNetwork()
    
    componentPositioner26.PrimaryArrangement = arrangement2
    
    componentPositioner26.BeginAssemblyConstraints()
    
    allowInterpartPositioning26 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression254 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression255 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression256 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression257 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression258 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression259 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression260 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression261 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network26 = componentPositioner26.EstablishNetwork()
    
    componentNetwork26 = network26
    componentNetwork26.MoveObjectsState = True
    
    componentNetwork26.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork26.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId152, "Assembly Constraints Dialog")
    
    componentNetwork26.MoveObjectsState = True
    
    componentNetwork26.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    # ----------------------------------------------
    #   Dialog Begin Assembly Constraints
    # ----------------------------------------------
    rotMatrix88 = NXOpen.Matrix3x3()
    
    rotMatrix88.Xx = 0.60864670484315353
    rotMatrix88.Xy = 0.30056891641746586
    rotMatrix88.Xz = 0.73430750722514049
    rotMatrix88.Yx = -0.75050000605881606
    rotMatrix88.Yy = -0.082244667064122381
    rotMatrix88.Yz = 0.65573283862044407
    rotMatrix88.Zx = 0.25748578521791365
    rotMatrix88.Zy = -0.95020742010528325
    rotMatrix88.Zz = 0.17551902799290017
    translation88 = NXOpen.Point3d(41.907434954397644, -46.183728079203519, 69.484462912562847)
    modelingView3.SetRotationTranslationScale(rotMatrix88, translation88, 2.3573424593408099)
    
    rotMatrix89 = NXOpen.Matrix3x3()
    
    rotMatrix89.Xx = 0.056601202085681382
    rotMatrix89.Xy = 0.9556125619134348
    rotMatrix89.Xz = 0.28913826352749239
    rotMatrix89.Yx = -0.60595284503735258
    rotMatrix89.Yy = -0.19728345638378952
    rotMatrix89.Yz = 0.77064932844219125
    rotMatrix89.Zx = 0.79348437509102299
    rotMatrix89.Zy = -0.21882383176999468
    rotMatrix89.Zz = 0.56788966986194001
    translation89 = NXOpen.Point3d(-64.832426329786244, -24.235808608602852, 27.835678255316111)
    modelingView3.SetRotationTranslationScale(rotMatrix89, translation89, 2.3573424593408099)
    
    # ----------------------------------------------
    #   Menu: Fit
    # ----------------------------------------------
    modelingView3.Fit()
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint20 = componentPositioner26.CreateConstraint(True)
    
    componentConstraint20 = constraint20
    componentConstraint20.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    constraintReference39 = componentConstraint20.CreateConstraintReference(component19, edge10, False, False, False)
    
    helpPoint39 = NXOpen.Point3d(-83.822671141457022, 16.295314117283752, -0.69539866309731591)
    constraintReference39.HelpPoint = helpPoint39
    
    constraintReference40 = componentConstraint20.CreateConstraintReference(component11, edge17, False, False, False)
    
    helpPoint40 = NXOpen.Point3d(-52.399559282899673, 159.29700170055546, 3.4625235589636412)
    constraintReference40.HelpPoint = helpPoint40
    
    constraintReference40.SetFixHint(True)
    
    componentNetwork26.Solve()
    
    scaleAboutPoint746 = NXOpen.Point3d(11.005735736748269, -31.794347683939414, 0.0)
    viewCenter746 = NXOpen.Point3d(-11.005735736748269, 31.794347683939414, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint746, viewCenter746)
    
    scaleAboutPoint747 = NXOpen.Point3d(13.757169670935335, -39.742934604924265, 0.0)
    viewCenter747 = NXOpen.Point3d(-13.757169670935308, 39.742934604924265, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint747, viewCenter747)
    
    scaleAboutPoint748 = NXOpen.Point3d(16.391949242415642, -50.483181102408771, 0.0)
    viewCenter748 = NXOpen.Point3d(-16.391949242415574, 50.483181102408771, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint748, viewCenter748)
    
    rotMatrix90 = NXOpen.Matrix3x3()
    
    rotMatrix90.Xx = -0.23039605141485775
    rotMatrix90.Xy = -0.95405152423311002
    rotMatrix90.Xz = 0.1915811801845764
    rotMatrix90.Yx = 0.10721328968927249
    rotMatrix90.Yy = 0.17079157634202544
    rotMatrix90.Yz = 0.97945676166158913
    rotMatrix90.Zx = -0.96717266814485736
    rotMatrix90.Zy = 0.24620301898855468
    rotMatrix90.Zz = 0.062937297641973922
    translation90 = NXOpen.Point3d(89.093255383246543, -47.532861247168405, -94.681125038587638)
    modelingView3.SetRotationTranslationScale(rotMatrix90, translation90, 1.052396702687151)
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs77 = theSession.UpdateManager.DoUpdate(markId153)
    
    componentNetwork26.Solve()
    
    componentPositioner26.ClearNetwork()
    
    nErrs78 = theSession.UpdateManager.AddToDeleteList(componentNetwork26)
    
    componentPositioner26.DeleteNonPersistentConstraints()
    
    nErrs79 = theSession.UpdateManager.DoUpdate(markId153)
    
    theSession.DeleteUndoMark(markId155, None)
    
    theSession.SetUndoMarkName(markId152, "Assembly Constraints")
    
    componentPositioner26.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner26.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId153, None)
    
    theSession.DeleteUndoMark(markId154, None)
    
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner27 = workPart.ComponentAssembly.Positioner
    
    componentPositioner27.ClearNetwork()
    
    componentPositioner27.PrimaryArrangement = arrangement2
    
    componentPositioner27.BeginAssemblyConstraints()
    
    allowInterpartPositioning27 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression262 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression263 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression264 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit3)
    
    expression265 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit4)
    
    expression266 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression267 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit3)
    
    expression268 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit3)
    
    expression269 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit4)
    
    network27 = componentPositioner27.EstablishNetwork()
    
    componentNetwork27 = network27
    componentNetwork27.MoveObjectsState = True
    
    componentNetwork27.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork27.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId156, "Assembly Constraints Dialog")
    
    componentNetwork27.MoveObjectsState = True
    
    componentNetwork27.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    componentPositioner27.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner27.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId157, None)
    
    theSession.UndoToMark(markId156, None)
    
    theSession.DeleteUndoMark(markId156, None)
    
    theSession.DeleteUndoMark(markId143, None)
    
    scaleAboutPoint749 = NXOpen.Point3d(-124.82519630152376, -43.996796279489686, 0.0)
    viewCenter749 = NXOpen.Point3d(124.82519630152385, 43.996796279489686, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint749, viewCenter749)
    
    scaleAboutPoint750 = NXOpen.Point3d(-156.03149537690464, -55.310258179930059, 0.0)
    viewCenter750 = NXOpen.Point3d(156.03149537690473, 55.310258179930059, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint750, viewCenter750)
    
    scaleAboutPoint751 = NXOpen.Point3d(-194.64654068292114, -69.137822724912567, 0.0)
    viewCenter751 = NXOpen.Point3d(194.64654068292126, 69.137822724912567, 0.0)
    modelingView3.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint751, viewCenter751)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()